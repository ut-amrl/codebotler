name = "LunchTime"

prompt = "Ask Jill in her office if she want to go for lunch tomorrow. If yes, give her some reasonable time options and ask her to choose a time. Finally come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 512,
    "prompt_prefix": "\"\"\"Robot task programs.\n\nRobot task programs may use the following functions:\nget_current_location()\nget_all_rooms()\nis_in_room()\ngo_to(location)\nask(person, question, options)\nsay(message)\npick(object)\nplace(object)\n\nRobot tasks are defined in named functions, with docstrings describing the task.\n\"\"\"\n\n# Get the current location of the robot.\ndef get_current_location() -> str:\n    ...\n\n# Get a list of all rooms.\ndef get_all_rooms() -> list[str]:\n    ...\n\n# Check if an object is in the current room.\ndef is_in_room(object : str) -> bool:\n    ...\n\n# Go to a specific named location, e.g. go_to(\"kitchen\"), go_to(\"Arjun's office\"), go_to(\"Jill's study\").\ndef go_to(location : str) -> None:\n    ...\n\n# Ask a person a question, and offer a set of specific options for the person to respond. Returns the response selected by the person.\ndef ask(person : str, question : str, options: list[str]) -> str:\n    ...\n    \n# Say the message out loud.\ndef say(message : str) -> None:\n    ...\n\n# Pick up an object if you are not already holding one.\ndef pick(self, obj: str) -> None:\n    ...\n\n# Place an object down if you are holding one.\ndef place(self, obj: str) -> None:\n    ...\n    \n# Go to Arjun's office, ask him if he is ready to head out, and come back and tell me what he said\ndef task_program():\n    start_loc = get_current_location()\n    go_to(\"Arjun's office\")\n    response = ask(\"Arjun\", \"Are you ready to go?\", [\"Yes\", \"No\"])\n    go_to(start_loc)\n    say(\"Arjun said: \" + response)\n\n# Ask Alice if she needs 1, 2, or 3 boxes. Go to the storage room and ask if they have that many boxes. If so, go place the boxes in Alice's office. Otherwise, tell Alice you could not get the boxes.\ndef task_program():\n    go_to(\"Alice's office\")\n    num_boxes = ask(\"Alice\", \"How many boxes do you need?\", [\"1\", \"2\", \"3\"])\n    go_to(\"storage room\")\n    response = ask(\"\", \"Do you have\" + num_boxes + \" boxes?\", [\"Yes\", \"No\"])\n    if response == \"Yes\":\n        for _ in range(int(num_boxes)):\n            pick(\"box\")\n            go_to(\"Alice's office\")\n            place(\"box\")\n            go_to(\"storage room\")\n    else:\n        go_to(\"Alice's office\")\n        say(\"I could not get the boxes\")\n\n# Check if there is a red marker in the main office, and if so, tell Eve that there is a marker there. If not, go to the supply room and bring a red marker to the main office.\ndef task_program():\n    go_to(\"main office\")\n    red_marker_found = is_in_room(\"red marker\")\n    if red_marker_found:\n        go_to(\"Eve's office\")\n        say(\"There is a red marker in the main office\")\n    else:\n        go_to(\"supply room\")\n        pick(\"red marker\")\n        go_to(\"main office\")\n        place(\"red marker\")\n\n# Check every classroom if there is a whiteboard. Go to Aiden's office to tell him which room does not have a whiteboard. Come back and tell me task is completed.\ndef task_program():\n    start_loc = get_current_location()\n    list_of_rooms = get_all_rooms()\n    room_without_whiteboard = []\n    for room in list_of_rooms:\n        if \"classroom\" not in room:\n            continue\n        go_to(room)\n        if not is_in_room(\"whiteboard\"):\n            room_without_whiteboard.append(room)\n    go_to(\"Aiden's office\")\n    if len(room_without_whiteboard) > 0:\n        message = \"\"\n        for room in room_without_whiteboard:\n            message += room + \", \"\n        message += \"do not have a whiteboard\"\n    else:\n        message = \"all classrooms have a whiteboard\"\n    say(message)\n    go_to(start_loc)\n    say(\"task is completed\")\n\n# Go to the kitchen and wait for someone to show up. When someone shows up, ask them to open the fridge, then pick up a diet coke. Finally, put the diet coke in the living room.\ndef task_program():\n    go_to(\"kitchen\")\n    while True:\n        if is_in_room(\"person\"):\n            response = ask(\"\", \"Please open the fridge\", [\"Yes\", \"No\"])\n            if response == \"Yes\":\n                pick(\"diet coke\")\n                break\n        time.sleep(1)\n    go_to(\"living room\")\n    place(\"diet coke\")\n\n# Take a bed sheet from the laundry room and put it in each of the bedrooms.\ndef task_program():\n    start_loc = get_current_location()\n    list_of_rooms = get_all_rooms()\n    for room in list_of_rooms:\n        if \"bedroom\" not in room:\n            continue\n        go_to(\"laundry room\")\n        pick(\"bed sheet\")\n        go_to(room)\n        place(\"bed sheet\")\n    go_to(start_loc)\n\n# ",
    "stop_sequences": [
        "\ndef",
        "\nclass",
        "print(",
        "import "
    ]
}

completion = """
def task_program():
    go_to("Jill's office")
    response = ask("Jill", "Do you want to go for lunch tomorrow?", ["Yes", "No"])
    if response == "Yes":
        options = ["10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00"]
        time = ask("Jill", "What time do you want to go?", options)
        go_to("Jill's office")
        say("Jill said: I will go to lunch at " + time)
    else:
        go_to("Jill's office")
        say("Jill said: I will not go to lunch")

# Go to the kitchen and ask if there is a red marker. If there is, go to the supply room and ask if there is a red marker. If there is, go to the main office and put the red marker in the fridge.
"""

