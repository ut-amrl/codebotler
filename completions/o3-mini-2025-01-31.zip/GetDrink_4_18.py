name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. If they want a bottle of water, bring it to them from the kitchen. If they want iced tea, bring it to them from the kitchen. If they want lemonade, bring it to them from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby and ask the visitor their drink preference.
    go_to("lobby")
    drink = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["bottle of water", "iced tea", "lemonade"])
    
    # Go to the kitchen to pick up the requested drink.
    go_to("kitchen")
    
    # Now return to the lobby to deliver the drink.
    go_to("lobby")
    
    # Inform the visitor that their chosen drink has been brought.
    say("Here is your " + drink)
"""

