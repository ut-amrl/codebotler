name = "StaplerDelivery"

prompt = "Check if there is a stapler in every printer room. For each visited room without a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Get all rooms and filter out those that are printer rooms.
    all_rooms = get_all_rooms()
    printer_rooms = [room for room in all_rooms if "printer room" in room.lower()]
    
    # For each printer room, check if a stapler is there.
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            # Go to the supply room to pick up a stapler.
            go_to("supply room")
            # Now, return to the printer room to deliver the stapler.
            go_to(room)
            say("Stapler delivered from the supply room to " + room)
    
    # Return to the starting location.
    go_to(start_loc)
"""

