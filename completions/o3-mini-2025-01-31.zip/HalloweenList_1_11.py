name = "HalloweenList"

prompt = "Go to every office, and if there is a person there, ask them if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return later.
    start_loc = get_current_location()
    
    # Counters for each candy type.
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0
    
    # Get all rooms.
    all_rooms = get_all_rooms()
    
    # Iterate over all rooms to check for offices.
    for room in all_rooms:
        # Assuming that offices have the word "office" in their name.
        if "office" in room.lower():
            go_to(room)
            # Check if there is a person in the current room.
            if is_in_room("person"):
                # Ask the person which treat they would like.
                response = ask("person", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
                if response == "chocolate":
                    chocolate_count += 1
                elif response == "caramel":
                    caramel_count += 1
                elif response == "gummy":
                    gummy_count += 1
                    
    # Go back to the starting location.
    go_to(start_loc)
    
    # Communicate the final counts.
    message = ("We need to buy {} chocolates, {} caramels, and {} gummies."
               .format(chocolate_count, caramel_count, gummy_count))
    say(message)
"""

