name = "HalloweenList"

prompt = "Find every occupied office and ask their occupants whether they would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Dictionary to count candy choices from occupants
    candy_counts = {"chocolate": 0, "caramel": 0, "gummy": 0}

    # Get a list of all rooms
    rooms = get_all_rooms()

    # Loop through each room and check if it's an office
    for room in rooms:
        if "office" in room.lower():
            go_to(room)
            # Check if the office is occupied (i.e. there is a person in the room)
            if is_in_room("person"):
                # Ask the occupant which candy they'd like
                response = ask("occupant", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
                # Increment the counter for the selected candy option
                if response in candy_counts:
                    candy_counts[response] += 1
"""

