name = "HalloweenList"

prompt = "Go to every office with a person, and ask them if they would like a chocolate, caramel, or gummy, then come back and tell me how many of each people asked for."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the current location so we can return after visiting offices.
    start_loc = get_current_location()
    
    # Initialize counters for each candy type.
    counts = {"chocolate": 0, "caramel": 0, "gummy": 0}
    
    # Get a list of all the rooms.
    all_rooms = get_all_rooms()
    
    # Filter the rooms to only include offices.
    # Assuming that office rooms have the word "office" in their name.
    office_rooms = [room for room in all_rooms if "office" in room.lower()]
    
    # Visit each office that has a person.
    for room in office_rooms:
        go_to(room)
        if is_in_room("person"):
            # Ask the person which candy they'd like.
            response = ask("person", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
            if response in counts:
                counts[response] += 1
    
    # Return to the original starting location.
    go_to(start_loc)
    
    # Construct a message showing the counts for each candy type.
    message = (f"Chocolate: {counts['chocolate']}, "
               f"Caramel: {counts['caramel']}, "
               f"Gummy: {counts['gummy']}")
    
    # Announce the results.
    say(message)
"""

