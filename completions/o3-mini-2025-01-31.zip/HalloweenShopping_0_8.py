name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return later.
    start_loc = get_current_location()
    
    total_chocolate = 0
    total_caramel = 0
    total_gummy = 0

    # Retrieve all room names.
    rooms = get_all_rooms()
    
    # Iterate over each room to check if it's an office.
    for room in rooms:
        if "office" not in room.lower():
            continue
        
        # Go to the office.
        go_to(room)
        
        # Check if there's anyone in the room.
        if is_in_room("person"):
            # Ask for treat preferences.
            choco_response = ask("person", "How many chocolate treats would you like (0-4)?", ["0", "1", "2", "3", "4"])
            caramel_response = ask("person", "How many caramel treats would you like (0-4)?", ["0", "1", "2", "3", "4"])
            gummy_response = ask("person", "How many gummy treats would you like (0-4)?", ["0", "1", "2", "3", "4"])
            
            # Aggregate the numbers.
            total_chocolate += int(choco_response)
            total_caramel += int(caramel_response)
            total_gummy += int(gummy_response)

    # Return to the starting location.
    go_to(start_loc)
    
    # Inform about the total treats needed.
    message = ("We need to buy " + str(total_chocolate) + " chocolate, " +
               str(total_caramel) + " caramel, and " + str(total_gummy) +
               " gummy treats.")
    say(message)
"""

