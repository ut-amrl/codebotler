name = "StaplerDelivery"

prompt = "Make sure there is a stapler in each printer room. Otherwise, bring a stapler from the supply room to each printer room that currently lacks one."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    for room in rooms:
        # Identify printer rooms based on their names.
        if "printer" in room.lower():
            go_to(room)
            # Check if there is a stapler in the current printer room.
            if not is_in_room("stapler"):
                # Bring a stapler from the supply room.
                go_to("supply room")
                # (Assume the robot picks up a stapler here.)
                go_to(room)
                say("A stapler has been brought from the supply room to " + room)
    go_to(start_loc)
"""

