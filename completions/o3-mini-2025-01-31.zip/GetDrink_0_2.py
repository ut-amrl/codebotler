name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. Bring what they ask for from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby to interact with the visitor.
    go_to("lobby")
    
    # Ask the visitor for their beverage choice.
    choice = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["Bottle of water", "Iced tea", "Lemonade"])
    
    # Go to the kitchen to get the requested drink.
    go_to("kitchen")
    # (Assume the robot picks up the drink in the kitchen.)
    
    # Bring the drink back to the lobby.
    go_to("lobby")
    say("Here is your " + choice + ".")
"""

