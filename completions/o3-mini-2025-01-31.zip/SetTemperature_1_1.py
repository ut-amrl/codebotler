name = "SetTemperature"

prompt = "Ask Arjun in his office if he would like it to be warmer or colder. The thermostat is currently set to 72 degrees. Come back and tell me what temperature I should set the thermostat to based on what Arjun says."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 512,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Arjun's office")
    response = ask("Arjun", "Would you like it to be warmer or colder?", ["warmer", "colder"])
    # The thermostat is currently set to 72 degrees.
    if response == "warmer":
"""

