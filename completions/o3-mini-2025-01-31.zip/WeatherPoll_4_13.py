name = "WeatherPoll"

prompt = "Go to the main entrance, and if there is no one there, wait for someone to show up. Ask them if they feel it is hot out. Wait for the next person and ask the same question again. Do this 10 times. Come back and report the percentage of people who think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    yes_count = 0
    total = 10
    
    for i in range(total):
        # Wait until someone shows up at the main entrance.
        while not is_in_room("person"):
            time.sleep(1)
            
        # Ask the person if they feel it is hot out.
        response = ask("", "Do you feel it is hot out?", ["Yes", "No"])
        if response == "Yes":
            yes_count += 1
        
        # Wait until the current person leaves so we can ask the next person.
        while is_in_room("person"):
            time.sleep(1)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Compute and report the percentage of people who think it's hot out.
    percentage = (yes_count / total) * 100
    say("Percentage of people who think it's hot out: " + str(percentage) + "%")
"""

