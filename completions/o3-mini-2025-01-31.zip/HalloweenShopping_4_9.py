name = "HalloweenShopping"

prompt = "Go to every office and skip any office without a person in there. Otherwise, ask the person in the office to decide on how many, from zero to four, of the following they'd like: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy. "

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Initialize totals for each candy.
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0
    
    # Get a list of all rooms.
    rooms = get_all_rooms()
    
    # Loop through all rooms and process those that are offices.
    for room in rooms:
        if "office" not in room:
            continue
        
        # Go to the office.
        go_to(room)
        
        # Skip offices that don't have a person.
        if not is_in_room("person"):
            continue
        
        # Try to extract the person's name from the room name. 
        # Assume room names are in the format "Name's office".
        if "'s" in room:
            person = room.split("'s")[0]
        else:
            person = "person"
        
        # For each type of candy, ask the person how many they would like.
        response = ask(person, "How many gummy candies would you like? (choose from 0 to 4)", ["0", "1", "2", "3", "4"])
        total_gummy += int(response)
        
        response = ask(person, "How many caramel candies would you like? (choose from 0 to 4)", ["0", "1", "2", "3", "4"])
        total_caramel += int(response)
        
        response = ask(person, "How many chocolate candies would you like? (choose from 0 to 4)", ["0", "1", "2", "3", "4"])
        total_chocolate += int(response)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Report the totals.
    message = ("We need to buy {} gummy, {} caramel, and {} chocolate candies."
               .format(total_gummy, total_caramel, total_chocolate))
    say(message)
"""

