name = "LunchBreak"

prompt = "Ask Alice in her office if she is up for lunch, and if yes, tell her that we will meet in the lobby in 5 minutes. Do the same for Bob. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    joining_for_lunch = []
    start_loc = get_current_location()
    
    # Ask Alice about lunch
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("We will meet in the lobby in 5 minutes")
        joining_for_lunch.append("Alice")
        
    # Ask Bob about lunch
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("We will meet in the lobby in 5 minutes")
        joining_for_lunch.append("Bob")
        
    # Return to the starting location and report the outcome.
    go_to(start_loc)
    if joining_for_lunch:
        names = ", ".join(joining_for_lunch)
        say("Joining for lunch: " + names)
    else:
        say("No one is joining for lunch")
"""

