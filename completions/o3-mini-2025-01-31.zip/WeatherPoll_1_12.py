name = "WeatherPoll"

prompt = "Go to the main entrance. When someone shows up, ask them if they feel that it's hot out. Do this until you collect ten people's responses. Come back and tell me which percent of people think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
  
    total_responses = 0
    yes_count = 0
  
    # Continue until we have collected responses from 10 people.
    while total_responses < 10:
        # Wait until a person is in the room.
        if is_in_room("person"):
            response = ask("person", "Do you feel that it's hot out?", ["Yes", "No"])
            total_responses += 1
            if response == "Yes":
                yes_count += 1
    # Calculate the percentage of people who answered "Yes".
    percent_yes = (yes_count / total_responses) * 100
  
    go_to(start_loc)
    say("Percentage of people who think it's hot out: " + str(percent_yes) + "%")
"""

