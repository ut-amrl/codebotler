name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a beef jerky, cupcake, ham sandwich, or donut. Come back and tell me how many people preferred a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    savory_count = 0
    # Assume that office names contain the word "office"
    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            # Check if someone is in the office
            if is_in_room("person"):
                response = ask("person", 
                               "Would you like a beef jerky, cupcake, ham sandwich, or donut?", 
                               ["beef jerky", "cupcake", "ham sandwich", "donut"])
                # Define savory options: beef jerky and ham sandwich
                if response in ["beef jerky", "ham sandwich"]:
                    savory_count += 1
    go_to(start_loc)
    say("Total people preferring savory options: " + str(savory_count))
"""

