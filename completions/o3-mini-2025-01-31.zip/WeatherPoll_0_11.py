name = "WeatherPoll"

prompt = "Go to the main entrance, and wait for someone to show up. Ask them if they feel it is hot out. Repeat this until you have 10 responses, and then come back and tell me what percent of people think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    
    response_count = 0
    yes_count = 0
    
    # Continue asking until we have 10 responses.
    while response_count < 10:
        # Wait until someone is in the room.
        if is_in_room("person"):
            response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
            response_count += 1
            if response == "Yes":
                yes_count += 1
        # Pause briefly before checking again.
        import time
        time.sleep(1)
    
    percent_hot = (yes_count / 10) * 100
    go_to(start_loc)
    say("At the main entrance, " + str(percent_hot) + "% of people think it is hot out.")
"""

