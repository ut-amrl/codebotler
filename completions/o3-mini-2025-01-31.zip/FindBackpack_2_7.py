name = "FindBackpack"

prompt = "Please find my backpack in each conference room and then bring it to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the current location to return with the backpack
    start_loc = get_current_location()
    # Get all rooms and filter for conference rooms
    rooms = get_all_rooms()
    backpack_found = False

    # Search through all conference rooms for the backpack
    for room in rooms:
        if "conference" in room.lower():
            go_to(room)
            if is_in_room("backpack"):
                backpack_found = True
                break  # Stop searching once the backpack is found

    # Once found, bring the backpack to the user
    if backpack_found:
        go_to(start_loc)
        say("I have brought your backpack.")
    else:
        # Optional: Inform if the backpack wasn't found
        go_to(start_loc)
        say("I could not find your backpack in any conference room.")
"""

