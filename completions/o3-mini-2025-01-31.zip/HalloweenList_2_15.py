name = "HalloweenList"

prompt = "Check with every occupied office to see if the occupant would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    # Counters for each candy type
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0
    
    # Retrieve all the rooms
    rooms = get_all_rooms()
    
    # Loop through each room to check occupied offices
    for room in rooms:
        # Check if the room is an office (assuming office rooms have "office" in their name)
        if "office" in room.lower():
            go_to(room)
            # Check if there is a person in the office (indicating it's occupied)
            if is_in_room("person"):
                response = ask("occupant", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
                if response.lower() == "chocolate":
                    chocolate_count += 1
                elif response.lower() == "caramel":
                    caramel_count += 1
                elif response.lower() == "gummy":
                    gummy_count += 1
    
    # Return to the starting location and report the totals
    go_to(start_loc)
    message = ("We need {} chocolates, {} caramels, and {} gummies."
              .format(chocolate_count, caramel_count, gummy_count))
    say(message)
"""

