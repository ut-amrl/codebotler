name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. Bring what they ask for from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby and ask the visitor for their drink preference.
    go_to("lobby")
    beverage = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["bottle of water", "iced tea", "lemonade"])
    
    # Go to the kitchen to get the requested beverage.
    go_to("kitchen")
    # (Assume the robot picks up the beverage in the kitchen.)
    
    # Bring the beverage back to the lobby.
    go_to("lobby")
    say("Here is your " + beverage)
"""

