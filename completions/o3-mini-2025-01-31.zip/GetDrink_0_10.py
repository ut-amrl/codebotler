name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. Bring what they ask for from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Start by going to the lobby
    go_to("lobby")
    
    # Ask the visitor for their beverage preference
    beverage = ask("Visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["bottle of water", "iced tea", "lemonade"])
    
    # Bring the selected beverage from the kitchen
    go_to("kitchen")
    # (Assume the robot picks up the beverage)
    
    # Return to the lobby and deliver the beverage
    go_to("lobby")
    say("I have brought you your " + beverage + ".")
"""

