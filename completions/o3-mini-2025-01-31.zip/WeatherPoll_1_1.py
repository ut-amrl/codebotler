name = "WeatherPoll"

prompt = "Go to the main entrance. When someone shows up, ask them if they feel that it's hot out. Do this until you collect ten people's responses. Come back and tell me which percent of people think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    
    responses = []
    yes_count = 0
    
    # Collect ten responses.
    while len(responses) < 10:
        # Wait until someone shows up.
        if is_in_room("person"):
            # Ask the person if they feel it's hot out.
            response = ask("person", "Do you feel that it's hot out?", ["Yes", "No"])
            responses.append(response)
            if response == "Yes":
                yes_count += 1
        else:
            # Wait a bit before checking again.
            import time
            time.sleep(1)
    
    # Calculate the percentage of people who think it's hot.
    percent_yes = (yes_count / len(responses)) * 100
    
    # Return to the original location and announce the result.
    go_to(start_loc)
    say(f"{percent_yes}% of people think it's hot out.")
"""

