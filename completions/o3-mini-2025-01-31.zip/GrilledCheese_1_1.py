name = "GrilledCheese"

prompt = "Create a list of ingredients needed to make grilled cheese. Visit Zarko's office and inquire which of them he possesses. Return and inform me of the items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    ingredients = ["bread", "cheese", "butter"]
    missing_items = []
    
    go_to("Zarko's office")
    for item in ingredients:
        response = ask("Zarko", "Do you have " + item + "?", ["Yes", "No"])
        if response == "No":
            missing_items.append(item)
    
    go_to(start_loc)
    if missing_items:
        say("Zarko does not have: " + ", ".join(missing_items))
    else:
        say("Zarko has all the ingredients for grilled cheese.")
"""

