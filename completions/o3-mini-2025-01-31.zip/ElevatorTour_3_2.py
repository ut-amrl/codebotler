name = "ElevatorTour"

prompt = "Go to the elevator and wait for a person to show up. When someone shows up, ask them if they are here for the tour, and if they say yes, welcome them to the university and tell them to follow you. Then take them to the main conference room. If they say no, wait for the next person. When you get to the conference room, announce your arrival at the conference room and wish them an enjoyable visit."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the elevator and wait for a person to show up.
    go_to("elevator")
    while True:
        # Check if a person is present in the elevator.
        if is_in_room("person"):
            response = ask("person", "Are you here for the tour?", ["Yes", "No"])
            if response == "Yes":
                say("Welcome to the university. Please follow me.")
                go_to("main conference room")
                say("I have arrived at the conference room. Enjoy your visit!")
                break
            # If the person is not here for the tour, continue waiting for the next person.
        # Pause briefly before checking again.
        import time
        time.sleep(1)
"""

