name = "GrilledCheese"

prompt = "Put together a compilation of grilled cheese ingredients. Head to Zarko's office, inquire about his available ingredients, and then update me on what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # List of essential grilled cheese ingredients
    ingredients = ["bread", "cheese", "butter"]
    missing_ingredients = []
    
    # Go to Zarko's office
    go_to("Zarko's office")
    
    # Ask Zarko about each ingredient
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(ingredient)
    
    # Update with the list of ingredients he does not have
    if missing_ingredients:
        message = "Zarko does not have: " + ", ".join(missing_ingredients)
    else:
        message = "Zarko has all the grilled cheese ingredients."
    
    say(message)
"""

