name = "SetTemperature"

prompt = "Go to Arjun's office and ask him if he would like his office to be warmer or colder. The thermostat says the temperature in the office is currently 72 degrees. Come back and tell me what temperature I should reset it to based on Arjun's preferences."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Arjun's office")
    # Ask Arjun if he wants his office warmer or colder.
    response = ask("Arjun", "Would you like your office to be warmer or colder?", ["warmer", "colder"])
    
    # The thermostat currently reads 72 degrees. Adjust based on his preference.
    if response == "warmer":
        new_temperature = 73
    else:
        new_temperature = 71
    
    go_to(start_loc)
    say("Reset the thermostat to " + str(new_temperature) + " degrees")
"""

