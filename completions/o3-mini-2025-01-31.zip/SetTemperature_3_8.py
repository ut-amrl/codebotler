name = "SetTemperature"

prompt = "Go to Arjun's office and ask him if he would like his office to be warmer or colder. The thermostat says the temperature in the office is currently 72 degrees. Come back and tell me what temperature I should reset it to based on Arjun's preferences."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()  # Save the starting location.
    go_to("Arjun's office")  # Go to Arjun's office.
    
    # Ask Arjun if he'd like his office to be warmer or colder.
    preference = ask("Arjun", "Would you like your office to be warmer or colder?", ["warmer", "colder"])
    
    current_temperature = 72  # The current thermostat reading.
    
    # Adjust the temperature based on his preference.
    if preference == "warmer":
        new_temperature = current_temperature + 1
    else:
        new_temperature = current_temperature - 1
    
    # Return to the original starting location.
    go_to(start_loc)
    
    # Tell the requester the temperature setting that should be used.
    say("Based on Arjun's preference, you should reset the temperature to " + str(new_temperature) + " degrees.")
"""

