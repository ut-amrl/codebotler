name = "HalloweenList"

prompt = "Go to every office, and if there is a person there, ask them if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0

    # Go to every office
    for room in all_rooms:
        if "office" in room:
            go_to(room)
            # Check if there is a person in the room
            if is_in_room("person"):
                response = ask("person", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
                if response == "chocolate":
                    chocolate_count += 1
                elif response == "caramel":
                    caramel_count += 1
                elif response == "gummy":
                    gummy_count += 1

    # Return to the starting location and report counts
    go_to(start_loc)
    say("We need to buy " + str(chocolate_count) + " chocolates, " + str(caramel_count) + " caramels, and " + str(gummy_count) + " gummies.")
"""

