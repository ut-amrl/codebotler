name = "LunchTime"

prompt = "Ask Jill in her office if she want to go for lunch tomorrow. If yes, give her some reasonable time options and ask her to choose a time. Finally come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to come back later
    start_loc = get_current_location()
    
    # Go to Jill's office
    go_to("Jill's office")
    
    # Ask Jill if she wants to go for lunch tomorrow.
    response = ask("Jill", "Do you want to go for lunch tomorrow?", ["Yes", "No"])
    
    # If Jill says yes, ask her to choose a time option.
    if response == "Yes":
        time_choice = ask("Jill", "Great! What time works for you? Options: 12:00, 12:30, 1:00", ["12:00", "12:30", "1:00"])
        final_message = "Yes, let's go at " + time_choice
    else:
        final_message = "No"
    
    # Go back to the original location
    go_to(start_loc)
    
    # Report what Jill said.
    say("Jill said: " + final_message)
"""

