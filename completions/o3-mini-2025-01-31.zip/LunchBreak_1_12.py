name = "LunchBreak"

prompt = "Ask Alice in her office if she is up for lunch, and if yes, tell her that we will meet in the lobby in 5 minutes. Do the same for Bob. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    participants = []
    start_loc = get_current_location()
    
    # Ask Alice in her office.
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("We will meet in the lobby in 5 minutes")
        participants.append("Alice")
    
    # Ask Bob in his office.
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("We will meet in the lobby in 5 minutes")
        participants.append("Bob")
    
    # Return to the original location and announce who is joining.
    go_to(start_loc)
    if participants:
        message = ", ".join(participants) + " are joining for lunch."
    else:
        message = "No one is joining for lunch."
    say(message)
"""

