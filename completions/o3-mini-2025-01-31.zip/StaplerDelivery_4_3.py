name = "StaplerDelivery"

prompt = "Check if every printer room has a stapler. If not, put a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    
    for room in all_rooms:
        # Check if the room is a printer room by checking if its name contains "printer"
        if "printer" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                # Need to bring a stapler from the supply room to this printer room.
                go_to("supply room")
                say("Picking up a stapler for " + room)
                go_to(room)
                say("A stapler has been placed in " + room)
    go_to(start_loc)
    say("Task completed")
"""

