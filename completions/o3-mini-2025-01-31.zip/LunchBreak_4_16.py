name = "LunchBreak"

prompt = "Go to Alice's office and ask her if she is free for lunch. If she says yes, tell her that we will meet in the lobby in five minutes. Do the same for Bob. Come back and tell me who will join for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    lunch_joiners = []
    
    # Ask Alice
    go_to("Alice's office")
    response_alice = ask("Alice", "Are you free for lunch?", ["Yes", "No"])
    if response_alice == "Yes":
        say("We will meet in the lobby in five minutes.")
        lunch_joiners.append("Alice")
        
    # Ask Bob
    go_to("Bob's office")
    response_bob = ask("Bob", "Are you free for lunch?", ["Yes", "No"])
    if response_bob == "Yes":
        say("We will meet in the lobby in five minutes.")
        lunch_joiners.append("Bob")
    
    # Return to the starting location and announce who will join for lunch.
    go_to(start_loc)
    if lunch_joiners:
        message = "The following will join for lunch: " + ", ".join(lunch_joiners)
    else:
        message = "No one will join for lunch."
    say(message)
"""

