name = "GrilledCheese"

prompt = "Compile a list of ingredients for grilled cheese. Go to Zarko's office, and ask him which of them he has. Come back and tell me what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Compile the list of ingredients for grilled cheese.
    ingredients = ["bread", "cheese", "butter"]
    
    # Save the starting location so we can come back later.
    start_loc = get_current_location()
    
    # Go to Zarko's office.
    go_to("Zarko's office")
    
    # Ask Zarko about each ingredient.
    missing = []
    for ingredient in ingredients:
        response = ask("Zarko", "Do you have " + ingredient + "?", ["Yes", "No"])
        if response == "No":
            missing.append(ingredient)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Inform about the missing ingredient(s).
    if missing:
        message = "Zarko does not have: " + ", ".join(missing)
    else:
        message = "Zarko has all the ingredients for grilled cheese."
    say(message)
"""

