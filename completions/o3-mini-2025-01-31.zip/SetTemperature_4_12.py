name = "SetTemperature"

prompt = "The thermostat is set to 72 degrees. Go to Arjun's office and ask if he would like the temperature to be set to a warmer or colder value. Return and tell me what temperature in degrees I should set the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Start from the current location.
    start_loc = get_current_location()
    
    # Go to Arjun's office to ask his temperature preference.
    go_to("Arjun's office")
    response = ask("Arjun", "Would you like the temperature to be set to a warmer or colder value?", ["warmer", "colder"])
    
    # The thermostat is set to 72 degrees initially.
    # Adjust by 2 degrees based on his response.
    if response == "warmer":
        new_temp = 74
    else:
        new_temp = 70
    
    # Return to the original location.
    go_to(start_loc)
    
    # Inform the requester what new temperature to set.
    say("Set the thermostat to " + str(new_temp) + " degrees.")
"""

