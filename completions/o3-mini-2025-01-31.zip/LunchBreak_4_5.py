name = "LunchBreak"

prompt = "Go to Alice's office and ask her if she is free for lunch. If she says yes, tell her that we will meet in the lobby in five minutes. Do the same for Bob. Come back and tell me who will join for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    lunch_participants = []
    
    # Ask Alice about lunch
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you free for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("We will meet in the lobby in five minutes")
        lunch_participants.append("Alice")
    
    # Ask Bob about lunch
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you free for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("We will meet in the lobby in five minutes")
        lunch_participants.append("Bob")
    
    # Go back and report who will join for lunch
    go_to(start_loc)
    if lunch_participants:
        message = "The following will join for lunch: " + ", ".join(lunch_participants)
    else:
        message = "No one will join for lunch."
    say(message)
"""

