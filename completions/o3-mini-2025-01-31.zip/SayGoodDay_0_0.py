name = "SayGoodDay"

prompt = "Go to every lab and if there is a person there, say Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Check if this room is a lab by a simple substring match.
        if "lab" in room.lower():
            go_to(room)
            # If a person is detected in the lab, greet them.
            if is_in_room("person"):
                say("Good Day!")
"""

