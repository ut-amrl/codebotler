name = "LunchBreak"

prompt = "Ask if Alice and Bob in their offices are up for lunch. If yes, tell them that we'll meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joining = []
    
    # Ask Alice about lunch in her office
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        joining.append("Alice")
        say("We'll meet in the lobby in 5 minutes")
    
    # Ask Bob about lunch in his office
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        joining.append("Bob")
        say("We'll meet in the lobby in 5 minutes")
    
    # Return to the starting location
    go_to(start_loc)
    
    # Announce who is joining for lunch
    if joining:
        say("Joining for lunch: " + ", ".join(joining))
    else:
        say("No one is joining for lunch.")
"""

