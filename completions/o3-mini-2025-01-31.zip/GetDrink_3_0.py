name = "GetDrink"

prompt = "Go to the lobby and ask any person there if they want iced tea, lemonade or a bottle of water. Bring whatever they asked for back from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby to talk to someone.
    go_to("lobby")
    # Ask a person in the lobby if they want iced tea, lemonade, or a bottle of water.
    drink = ask("person", "Would you like iced tea, lemonade or a bottle of water?", ["iced tea", "lemonade", "bottle of water"])
    # After getting the order, go to the kitchen.
    go_to("kitchen")
    # Assume the required drink is in the kitchen; pick it up (simulated by being in the kitchen).
    # Now, bring the drink back to the lobby.
    go_to("lobby")
    say("Here is your " + drink)
"""

