name = "CountSavory"

prompt = "Visit all offices. If anyone is present; ask them to choose from the options of cupcake, ham sandwich, donut, or beef jerky. Let me know how many people selected a savory option when you return."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    savory_count = 0
    offices = []
    # Get all rooms and filter out offices
    for room in get_all_rooms():
        if "office" in room.lower():
            offices.append(room)
    
    for office in offices:
        go_to(office)
        # Check if any person is in the office.
        if is_in_room("person"):
            # Ask the person to choose an option.
            response = ask("occupant", "Please choose one: cupcake, ham sandwich, donut, or beef jerky.", ["cupcake", "ham sandwich", "donut", "beef jerky"])
            # Count if a savory option was selected (savory: ham sandwich or beef jerky)
            if response in ["ham sandwich", "beef jerky"]:
                savory_count += 1
                
    go_to(start_loc)
    say("Number of people who selected a savory option: " + str(savory_count))
"""

