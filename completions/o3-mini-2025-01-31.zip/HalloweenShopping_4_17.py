name = "HalloweenShopping"

prompt = "Go to every office and skip any office without a person in there. Otherwise, ask the person in the office to decide on how many, from zero to four, of the following they'd like: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy. "

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    # Define the options for the number selection from 0 to 4.
    options = ["0", "1", "2", "3", "4"]
    
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0
    
    # Assume get_all_rooms() returns all room names, and we filter for offices.
    all_rooms = get_all_rooms()
    
    for room in all_rooms:
        # Process only rooms that are offices.
        if "office" not in room.lower():
            continue
        
        go_to(room)
        # Check if there is a person in the office.
        if not is_in_room("person"):
            continue
        
        # Ask the person for the number of each item.
        gummies = ask("person", "How many gummies would you like?", options)
        caramels = ask("person", "How many caramels would you like?", options)
        chocolates = ask("person", "How many chocolates would you like?", options)
        
        # Sum up the totals (convert responses to integers).
        total_gummy += int(gummies)
        total_caramel += int(caramels)
        total_chocolate += int(chocolates)
    
    # Return to original location and report the totals.
    go_to(start_loc)
    say("We need to buy {} gummies, {} caramels, and {} chocolates.".format(total_gummy, total_caramel, total_chocolate))
"""

