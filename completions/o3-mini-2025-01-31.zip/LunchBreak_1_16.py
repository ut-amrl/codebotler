name = "LunchBreak"

prompt = "Ask Alice in her office if she is up for lunch, and if yes, tell her that we will meet in the lobby in 5 minutes. Do the same for Bob. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joiners = []
    for person in ["Alice", "Bob"]:
        go_to(person + "'s office")
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            say("We will meet in the lobby in 5 minutes, " + person)
            joiners.append(person)
    go_to(start_loc)
    if joiners:
        say("Joining for lunch: " + ", ".join(joiners))
    else:
        say("No one is joining for lunch.")
"""

