name = "CountSavory"

prompt = "Go through each office; if someone is there, ask about their preference among cupcake, donut, beef jerky, or ham sandwich. Report the number of individuals who opted for a savory item after returning."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    savory_count = 0
    all_rooms = get_all_rooms()
    
    # Loop through each room that is an office.
    for room in all_rooms:
        if "office" not in room:
            continue
        go_to(room)
        # Check if someone is in the office.
        if is_in_room("person"):
            # Ask the occupant their snack preference.
            response = ask("office occupant", "What is your snack preference?", 
                           ["cupcake", "donut", "beef jerky", "ham sandwich"])
            # Count if they chose a savory item.
            if response in ["beef jerky", "ham sandwich"]:
                savory_count += 1
    
    # Return to the starting location.
    go_to(start_loc)
    say("Number of individuals who opted for a savory item: " + str(savory_count))
"""

