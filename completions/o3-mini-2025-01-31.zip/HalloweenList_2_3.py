name = "HalloweenList"

prompt = "Check with every occupied office to see if the occupant would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return afterward.
    start_loc = get_current_location()
    
    # Initialize order counters.
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0

    # Get all rooms and iterate through those that are offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Check if the room is an office by looking for "office" in its name.
        if "office" in room.lower():
            go_to(room)
            # Check if someone is in the room.
            if is_in_room("person"):
                response = ask("occupant", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
                # Increment the appropriate counter.
                if response == "chocolate":
                    chocolate_count += 1
                elif response == "caramel":
                    caramel_count += 1
                elif response == "gummy":
                    gummy_count += 1

    # Return to the starting location.
    go_to(start_loc)
    
    # Create a message with the final totals.
    message = ("We need to buy " + str(chocolate_count) + " chocolates, " +
               str(caramel_count) + " caramels, and " +
               str(gummy_count) + " gummies.")
    say(message)
"""

