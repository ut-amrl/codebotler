name = "SayGoodDay"

prompt = "Go through all the labs, and if there's a person inside, say 'Good Day!' to them."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get a list of all rooms and filter for labs (case-insensitive check for "lab")
    all_rooms = get_all_rooms()
    labs = [room for room in all_rooms if "lab" in room.lower()]
    
    for lab in labs:
        go_to(lab)
        if is_in_room("person"):
            say("Good Day!")
"""

