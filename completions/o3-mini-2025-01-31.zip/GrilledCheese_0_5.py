name = "GrilledCheese"

prompt = "Compile a list of ingredients for grilled cheese. Go to Zarko's office, and ask him which of them he has. Come back and tell me what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Compile the list of ingredients for grilled cheese.
    ingredients = ["bread", "cheese", "butter"]
    missing_ingredients = []
    
    # Remember the starting location to return later.
    start_location = get_current_location()
    
    # Go to Zarko's office and ask which ingredients he has.
    go_to("Zarko's office")
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(ingredient)
    
    # Return to the starting location.
    go_to(start_location)
    
    # Tell what Zarko does not have.
    if missing_ingredients:
        missing_message = "Zarko does not have: " + ", ".join(missing_ingredients)
    else:
        missing_message = "Zarko has all the ingredients for grilled cheese."
    say(missing_message)
"""

