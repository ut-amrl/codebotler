name = "MovieMessenger"

prompt = "Go to Sally's office and ask her if she wants to go to the cinema with Mark. Tell Mark what Sally said, and if yes, ask Mark whether he wants to leave at 4PM, 5PM, or 6PM, and then go back to Sally's office and tell her what Mark said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to Sally's office to ask her about the cinema invitation.
    go_to("Sally's office")
    sally_response = ask("Sally", "Do you want to go to the cinema with Mark?", ["Yes", "No"])
    
    # Go to Mark's office to tell him what Sally said.
    go_to("Mark's office")
    say("Sally said: " + sally_response)
    
    # If Sally said yes, ask Mark about the departure time.
    if sally_response == "Yes":
        mark_response = ask("Mark", "What time do you want to leave?", ["4PM", "5PM", "6PM"])
        # Go back to Sally's office to tell her what Mark said.
        go_to("Sally's office")
        say("Mark said: " + mark_response)
"""

