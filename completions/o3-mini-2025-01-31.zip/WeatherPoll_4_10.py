name = "WeatherPoll"

prompt = "Go to the main entrance, and if there is no one there, wait for someone to show up. Ask them if they feel it is hot out. Wait for the next person and ask the same question again. Do this 10 times. Come back and report the percentage of people who think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time  # for waiting between checks
    
    start_loc = get_current_location()
    go_to("main entrance")
    
    yes_count = 0
    total_responses = 0
    
    # This loop will gather 10 responses.
    while total_responses < 10:
        # Wait until at least one person is detected in the main entrance.
        while not is_in_room("person"):
            time.sleep(1)
        
        # Ask the person if they feel it is hot out.
        response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
        if response == "Yes":
            yes_count += 1
        total_responses += 1
        
        # Wait for the current person to leave so we can ask someone new.
        # This prevents the same person from being asked repeatedly.
        while is_in_room("person"):
            time.sleep(1)
    
    # Calculate the percentage of people who think it's hot out.
    percentage = (yes_count / total_responses) * 100
    
    go_to(start_loc)
    say("Percentage of people who think it's hot out: " + str(percentage) + "%")
"""

