name = "StaplerDelivery"

prompt = "Check if there is a stapler in every printer room. For each visited room without a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Retrieve all rooms from the system.
    all_rooms = get_all_rooms()
    
    # Iterate over each room to check if it's a printer room.
    for room in all_rooms:
        # Assume a printer room's name contains the word "printer"
        if "printer" in room.lower():
            # Go to the printer room.
            go_to(room)
            # Check if the room has a stapler.
            if not is_in_room("stapler"):
                # If no stapler is present, deliver one from the supply room.
                go_to("supply room")
                # (Assume the robot picks up a stapler here.)
                go_to(room)
                say("Delivered a stapler to " + room)
"""

