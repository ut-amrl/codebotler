name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the initial location
    start_loc = get_current_location()

    # Get a list of all rooms and filter to only include offices, assuming office names contain "office"
    all_rooms = get_all_rooms()
    office_rooms = [room for room in all_rooms if "office" in room.lower()]

    # Counters for each item
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0

    # Options for the ask function
    options = ["0", "1", "2", "3", "4"]

    # Visit each office
    for office in office_rooms:
        go_to(office)
        # Check if there is a person in the office
        if not is_in_room("person"):
            continue

        # Ask for each item the quantity the person would like
        gummy_resp = ask("person", "How many gummy would you like?", options)
        caramel_resp = ask("person", "How many caramel would you like?", options)
        chocolate_resp = ask("person", "How many chocolate would you like?", options)

        # Add to totals converting responses to integers
        total_gummy += int(gummy_resp)
        total_caramel += int(caramel_resp)
        total_chocolate += int(chocolate_resp)

    # Return to the original location
    go_to(start_loc)
    # Construct the message summarizing the order
    message = ("We need to buy {} gummy, {} caramel, and {} chocolate. "
               "That's the total order based on the responses.").format(total_gummy, total_caramel, total_chocolate)
    say(message)
"""

