name = "FindBackpack"

prompt = "Look in all of the conference rooms to search for my backpack and then bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    found = False
    # Iterate over all rooms to find conference rooms.
    for room in get_all_rooms():
        if "conference" not in room.lower():
            continue  # skip non-conference rooms
        go_to(room)
        # Check if the backpack is in the current conference room.
        if is_in_room("backpack"):
            found = True
            break
    if found:
        # Bring the backpack back by returning to the original location.
        go_to(start_loc)
        say("I have brought your backpack back to you.")
    else:
        say("I could not find your backpack in any of the conference rooms.")
"""

