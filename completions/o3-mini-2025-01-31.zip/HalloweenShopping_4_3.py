name = "HalloweenShopping"

prompt = "Go to every office and skip any office without a person in there. Otherwise, ask the person in the office to decide on how many, from zero to four, of the following they'd like: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy. "

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    # Initialize accumulators for each treat.
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0

    rooms = get_all_rooms()
    # Loop through each room, filtering for offices.
    for room in rooms:
        if "office" not in room:
            continue
        go_to(room)
        # Check if there is a person in the office.
        if not is_in_room("person"):
            continue
        # Ask the person for their treat amounts.
        gummy_ans = ask("person", "How many gummy would you like? (Choose from 0 to 4)", ["0", "1", "2", "3", "4"])
        caramel_ans = ask("person", "How many caramel would you like? (Choose from 0 to 4)", ["0", "1", "2", "3", "4"])
        chocolate_ans = ask("person", "How many chocolate would you like? (Choose from 0 to 4)", ["0", "1", "2", "3", "4"])
        
        total_gummy += int(gummy_ans)
        total_caramel += int(caramel_ans)
        total_chocolate += int(chocolate_ans)
        
    # Return to the starting location.
    go_to(start_loc)
    # Report the total numbers.
    say("We need to buy {} gummy, {} caramel, and {} chocolate.".format(total_gummy, total_caramel, total_chocolate))
"""

