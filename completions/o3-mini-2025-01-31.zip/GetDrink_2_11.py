name = "GetDrink"

prompt = "Go to the lobby. Ask if the visitor wants: a bottle of water, iced tea, or lemonade. Go to the kitchen and bring the visitor back what they asked for."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby and ask the visitor for their drink preference.
    go_to("lobby")
    beverage = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["bottle of water", "iced tea", "lemonade"])
    
    # Go to the kitchen to fetch the selected beverage.
    go_to("kitchen")
    say("I've got the " + beverage + " ready.")
    
    # Bring the beverage back to the lobby for the visitor.
    go_to("lobby")
    say("Here is your " + beverage + ". Enjoy!")
"""

