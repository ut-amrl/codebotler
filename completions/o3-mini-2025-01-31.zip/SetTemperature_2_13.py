name = "SetTemperature"

prompt = "The thermostat is currently set to 72 degrees. Go ask if Arjun thinks his office should be colder or warmer. Come back and tell me what temperature in degrees I should change the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    current_temp = 72
    start_loc = get_current_location()
    go_to("Arjun's office")
    preference = ask("Arjun", "Should your office be colder or warmer?", ["colder", "warmer"])
    if preference == "colder":
        new_temp = current_temp - 2
    else:
        new_temp = current_temp + 2
    go_to(start_loc)
    say("Change the thermostat to " + str(new_temp) + " degrees")
"""

