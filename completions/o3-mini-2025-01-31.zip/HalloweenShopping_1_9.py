name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    totals = {"caramel": 0, "chocolate": 0, "gummy": 0}
    all_rooms = get_all_rooms()
    
    for room in all_rooms:
        # Process only offices
        if "office" in room.lower():
            go_to(room)
            # Check if anyone is in the office
            if is_in_room("person"):
                # Ask the person for each candy type using options 0-4.
                resp_caramel = ask("person", "How many caramel candies would you like? (Choose 0-4)", ["0", "1", "2", "3", "4"])
                resp_chocolate = ask("person", "How many chocolate candies would you like? (Choose 0-4)", ["0", "1", "2", "3", "4"])
                resp_gummy = ask("person", "How many gummies would you like? (Choose 0-4)", ["0", "1", "2", "3", "4"])

                # Convert responses to integers and add to totals.
                totals["caramel"] += int(resp_caramel)
                totals["chocolate"] += int(resp_chocolate)
                totals["gummy"] += int(resp_gummy)
    
    # Return to initial location and announce the final totals.
    go_to(start_loc)
    say("We need to buy {} caramel, {} chocolate, and {} gummy candies.".format(
        totals["caramel"], totals["chocolate"], totals["gummy"]))
"""

