name = "FindBackpack"

prompt = "Search all the conference rooms for my backpack and return it to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    conference_rooms = []
    all_rooms = get_all_rooms()
    # Filter for conference rooms by checking if "conference" is in the room name.
    for room in all_rooms:
        if "conference" in room.lower():
            conference_rooms.append(room)
    
    backpack_found = False
    for room in conference_rooms:
        go_to(room)
        if is_in_room("backpack"):
            backpack_found = True
            say("I found your backpack in " + room)
            break

    go_to(start_loc)
    if backpack_found:
        say("Your backpack has been returned to you.")
    else:
        say("I did not find your backpack in any conference rooms.")
"""

