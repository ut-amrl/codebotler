name = "LunchTime"

prompt = "Go to Jill's office and ask her whether she's free to go for lunch tomorrow. If yes, ask her when (give her some reasonable times), and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    
    availability = ask("Jill", "Are you free to go for lunch tomorrow?", ["Yes", "No"])
    
    if availability == "Yes":
        time_choice = ask("Jill", "When would you like to go for lunch tomorrow?", ["11:30", "12:00", "12:30", "1:00"])
        response_message = "She is free and suggested " + time_choice
    else:
        response_message = "She is not free for lunch tomorrow"
    
    go_to(start_loc)
    say("Jill said: " + response_message)
"""

