name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0

    all_rooms = get_all_rooms()
    # Only process rooms that are offices (by checking if "office" is in the room name).
    for room in all_rooms:
        if "office" not in room.lower():
            continue
        go_to(room)
        # If no person is in the office, skip it.
        if not is_in_room("person"):
            continue
        # Try to extract the person's name from the office name, e.g., "Alice's office" -> "Alice"
        if "'s office" in room:
            person = room.split("'s office")[0]
        else:
            person = "person"
        # Ask the person for each candy type.
        gummy_qty = ask(person, "How many gummies would you like?", ["0", "1", "2", "3", "4"])
        caramel_qty = ask(person, "How many caramels would you like?", ["0", "1", "2", "3", "4"])
        chocolate_qty = ask(person, "How many chocolates would you like?", ["0", "1", "2", "3", "4"])
        total_gummy += int(gummy_qty)
        total_caramel += int(caramel_qty)
        total_chocolate += int(chocolate_qty)

    go_to(start_loc)
    message = ("We need to buy {} gummies, {} caramels, and {} chocolates."
               .format(total_gummy, total_caramel, total_chocolate))
    say(message)
"""

