name = "StaplerSupply"

prompt = "Check every printer room for a stapler, and come back and tell me which ones do not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    printer_rooms_missing_stapler = []
    
    for room in all_rooms:
        # Filter rooms that are printer rooms by checking if "printer" is in the room name (case-insensitive)
        if "printer" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                printer_rooms_missing_stapler.append(room)
    
    go_to(start_loc)
    
    if printer_rooms_missing_stapler:
        missing_rooms_str = ", ".join(printer_rooms_missing_stapler)
        say("The following printer rooms do not have a stapler: " + missing_rooms_str)
    else:
        say("All printer rooms have a stapler.")
"""

