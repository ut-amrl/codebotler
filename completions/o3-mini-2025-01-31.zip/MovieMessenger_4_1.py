name = "MovieMessenger"

prompt = "Ask Sally if she wants to go to the cinema with Mark. Tell Mark what Sally said, and if yes, ask Mark whether he wants to leave at 4PM, 5PM, or 6PM. Then then go tell Sally what Mark said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Ask Sally if she wants to go to the cinema with Mark.
    sally_response = ask("Sally", "Do you want to go to the cinema with Mark?", ["Yes", "No"])
    
    # Go to Mark's office and tell him what Sally said.
    go_to("Mark's office")
    say("Sally said: " + sally_response)
    
    # If Sally said "Yes", ask Mark about his departure time.
    if sally_response == "Yes":
        mark_response = ask("Mark", "What time do you want to leave?", ["4PM", "5PM", "6PM"])
    else:
        mark_response = None
    
    # Go to Sally's office to tell her what Mark said.
    go_to("Sally's office")
    if mark_response:
        say("Mark said: " + mark_response)
    else:
        say("Mark was informed that you do not want to go to the cinema.")
"""

