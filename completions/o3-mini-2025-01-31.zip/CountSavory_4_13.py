name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a beef jerky, cupcake, ham sandwich, or donut. Come back and tell me how many people preferred a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    savory_count = 0
    # Get all rooms and iterate over those that are offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" not in room:
            continue
        go_to(room)
        # Check if there is someone in the office.
        if is_in_room("person"):
            # Ask the person for their snack preference.
            response = ask("person", 
                           "Would you like a beef jerky, cupcake, ham sandwich, or donut?", 
                           ["beef jerky", "cupcake", "ham sandwich", "donut"])
            # Count savory responses: beef jerky and ham sandwich are savory.
            if response in ["beef jerky", "ham sandwich"]:
                savory_count += 1
    # Return to the starting location.
    go_to(start_loc)
    # Inform how many people preferred a savory option.
    say("Number of people who preferred a savory option is " + str(savory_count))
"""

