name = "MailDelivery"

prompt = "Grab a mail bin from the mail room. Go to every office, and ask if they have any mail to deliver. Ask them to put all mail in the bin if there is any. Put the mail bin back in the mail room and report which offices the mail is from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location
    start_loc = get_current_location()
    
    # Go to the mail room to grab the mail bin.
    go_to("mail room")
    say("Grabbing mail bin from the mail room.")
    
    # Prepare a list to record offices that have mail.
    offices_with_mail = []
    
    # Get all rooms and filter for offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Assume that any room with "office" in its name is an office.
        if "office" in room.lower():
            go_to(room)
            # Ask if the office has any mail to deliver.
            response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                # Instruct them to put all mail in the bin.
                say("Please put all your mail in the bin.")
                # Record the office from where mail is coming.
                offices_with_mail.append(room)
    
    # Return the mail bin to the mail room.
    go_to("mail room")
    say("
"""

