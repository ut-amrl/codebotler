name = "ElevatorTour"

prompt = "Go to the elevator, wait until someone arrives, and then ask them if they are here for the tour. If they say yes, welcome them to the university and tell them to follow you, and guide them to the main conference room. If they say no, wait for the next person. When you get to the conference room, announce your arrival at the conference room and wish them an enjoyable visit."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the elevator.
    go_to("elevator")
    
    # Wait until someone arrives.
    while True:
        # Check if a person is in the current room.
        if is_in_room("person"):
            response = ask("person", "Are you here for the tour?", ["Yes", "No"])
            if response == "Yes":
                # Welcome the visitor and instruct them to follow.
                say("Welcome to the university! Please follow me.")
                # Guide them to the main conference room.
                go_to("main conference room")
                # Announce arrival at the conference room and wish them an enjoyable visit.
                say("We have arrived at the conference room. Enjoy your visit!")
                break
            else:
                # If the response is "No", wait for the next person.
                # Continue to check for a different person.
                continue
        # Optionally add a short wait here to avoid a busy loop
        # time.sleep(1)  # Uncomment if a waiting mechanism is available.
"""

