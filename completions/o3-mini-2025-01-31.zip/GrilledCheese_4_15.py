name = "GrilledCheese"

prompt = "Put together a list of grilled cheese ingredients. Head to Zarko's office and inquire about his available ingredients. Return and inform me of what he is missing."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # List of ingredients for a grilled cheese sandwich.
    ingredients = ["bread", "cheese", "butter"]
    
    missing_ingredients = []
    start_loc = get_current_location()
    
    # Go to Zarko's office to check his available ingredients.
    go_to("Zarko's office")
    
    # Ask Zarko about each ingredient.
    for item in ingredients:
        response = ask("Zarko", f"Do you have {item} for a grilled cheese?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(item)
    
    # Return to the initial location.
    go_to(start_loc)
    
    # Inform the user which ingredients Zarko is missing.
    if missing_ingredients:
        missing_list = ", ".join(missing_ingredients)
        say(f"Zarko is missing: {missing_list}")
    else:
        say("Zarko has all the grilled cheese ingredients")
"""

