name = "LunchTime"

prompt = "Go to Jill's office and ask her whether she's free to go for lunch tomorrow. If yes, ask her when (give her some reasonable times), and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    
    # Go to Jill's office
    go_to("Jill's office")
    
    # Ask if she's free for lunch tomorrow
    availability = ask("Jill", "Are you free to go for lunch tomorrow?", ["Yes", "No"])
    
    # If yes, ask her for a preferred time slot
    if availability == "Yes":
        lunch_time = ask("Jill", "What time works best for lunch tomorrow?", ["12:00", "12:30", "1:00", "1:30"])
        final_message = "Jill is free for lunch tomorrow at " + lunch_time + "."
    else:
        final_message = "Jill is not free to go for lunch tomorrow."
    
    # Return to previous location and announce the result
    go_to(start_loc)
    say(final_message)
"""

