name = "WeatherPoll"

prompt = "Go to the main entrance. When someone shows up, ask them if they feel that it's hot out. Do this until you collect ten people's responses. Come back and tell me which percent of people think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    responses = []
    while len(responses) < 10:
        if is_in_room("person"):
            # Ask the person if they think it's hot out.
            answer = ask("Person", "Do you feel that it's hot out?", ["Yes", "No"])
            responses.append(answer)
        time.sleep(1)  # wait a bit before checking again
        
    # Calculate the percentage of people who said "Yes"
    yes_count = responses.count("Yes")
    percent_yes = (yes_count / 10) * 100
    
    go_to(start_loc)
    say("Out of 10 people, " + str(percent_yes) + "% think it's hot out.")
"""

