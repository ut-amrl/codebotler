name = "GrilledCheese"

prompt = "Put together a compilation of grilled cheese ingredients. Head to Zarko's office, inquire about his available ingredients, and then update me on what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Compilation of essential grilled cheese ingredients
    ingredients = ["bread", "cheese", "butter"]
    missing_ingredients = []
    
    # Head to Zarko's office to inquire about his available ingredients.
    go_to("Zarko's office")
    
    # For each ingredient, ask Zarko if he has it.
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response != "Yes":
            missing_ingredients.append(ingredient)
            
    # Update on what ingredients he does not have.
    if missing_ingredients:
        message = "Zarko does not have: " + ", ".join(missing_ingredients)
    else:
        message = "Zarko has all the grilled cheese ingredients."
        
    say(message)
"""

