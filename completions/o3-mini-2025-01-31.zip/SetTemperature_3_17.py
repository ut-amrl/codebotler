name = "SetTemperature"

prompt = "Go to Arjun's office and ask him if he would like his office to be warmer or colder. The thermostat says the temperature in the office is currently 72 degrees. Come back and tell me what temperature I should reset it to based on Arjun's preferences."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Store the starting location so we can return later.
    start_loc = get_current_location()
    
    # Go to Arjun's office.
    go_to("Arjun's office")
    
    # Ask Arjun for his temperature preference.
    response = ask("Arjun", "Would you like your office to be warmer or colder?", ["warmer", "colder"])
    
    # The current temperature is given as 72 degrees.
    current_temp = 72
    if response.lower() == "warmer":
        new_temp = current_temp + 1
    elif response.lower() == "colder":
        new_temp = current_temp - 1
    else:
        # Fallback in case an unexpected answer is returned.
        new_temp = current_temp

    # Return to the original location.
    go_to(start_loc)
    
    # Report the determined temperature.
    say("Based on Arjun's preference, the thermostat should be set to " + str(new_temp) + " degrees.")
"""

