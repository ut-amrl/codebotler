name = "FindBackpack"

prompt = "Look in all of the conference rooms to search for my backpack and then bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    backpack_found = False
    
    # Iterate over all rooms and check conference rooms for the backpack.
    for room in get_all_rooms():
        if "conference" in room.lower():
            go_to(room)
            if is_in_room("backpack"):
                backpack_found = True
                break

    # If the backpack is found, bring it back to the start location.
    if backpack_found:
        go_to(start_loc)
        say("I have found and brought your backpack.")
    else:
        go_to(start_loc)
        say("I did not find your backpack in any conference room.")
"""

