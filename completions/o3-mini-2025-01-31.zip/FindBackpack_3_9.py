name = "FindBackpack"

prompt = "Go through every conference room and find my backpack, then bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location to bring the backpack back.
    start_loc = get_current_location()
    backpack_found = False

    # Iterate over all rooms to check the conference rooms only.
    for room in get_all_rooms():
        if "conference" in room.lower():
            go_to(room)
            # Check if the backpack is in the current conference room.
            if is_in_room("backpack"):
                backpack_found = True
                break

    # If the backpack was found, bring it back to the starting location.
    if backpack_found:
        go_to(start_loc)
        say("I have brought your backpack back to you.")
    else:
        say("I could not find your backpack in any conference room.")
"""

