name = "CountSavory"

prompt = "Go through each office; if someone is there, ask about their preference among cupcake, donut, beef jerky, or ham sandwich. Report the number of individuals who opted for a savory item after returning."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    savory_count = 0
    # Iterate over all rooms and process offices
    for room in rooms:
        if "office" not in room:
            continue
        go_to(room)
        # Check if someone is in the office
        if is_in_room("person"):
            response = ask("person", "What is your preference among cupcake, donut, beef jerky, or ham sandwich?",
                           ["cupcake", "donut", "beef jerky", "ham sandwich"])
            if response in ["beef jerky", "ham sandwich"]:
                savory_count += 1
    go_to(start_loc)
    say("Number of individuals who opted for a savory item: " + str(savory_count))
"""

