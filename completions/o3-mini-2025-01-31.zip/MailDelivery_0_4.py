name = "MailDelivery"

prompt = "Pick up a mail bin from the mail room. Go to every office and ask if they have any mail they'd like delivered. If so, ask them to put it in the mail bin. Finally, meet me in the mail room with all the mail. Place the mail bin back and tell me which offices they are from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Pick up the mail bin from the mail room.
    go_to("mail room")
    say("Picking up the mail bin.")
    
    # Get all rooms and filter out the ones that are offices.
    all_rooms = get_all_rooms()
    # We'll record offices that have mail.
    offices_with_mail = []
    
    for room in all_rooms:
        # Check if the room is an office.
        if "office" in room.lower():
            go_to(room)
            # Ask the office occupant if they have any mail they'd like delivered.
            # We assume the person's name is the part before "'s" if available, otherwise we use the room name.
            if "'s" in room:
                person = room.split("'s")[0]
            else:
                person = room
            response = ask
"""

