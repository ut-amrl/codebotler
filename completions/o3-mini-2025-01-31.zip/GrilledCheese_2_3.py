name = "GrilledCheese"

prompt = "Put together a compilation of grilled cheese ingredients. Head to Zarko's office, inquire about his available ingredients, and then update me on what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the current location to return later.
    start_loc = get_current_location()
    
    # Go to Zarko's office.
    go_to("Zarko's office")
    
    # Define the standard grilled cheese ingredients.
    ingredients = ["bread", "cheese", "butter"]
    missing_ingredients = []
    
    # Ask Zarko about each ingredient.
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient} for making a grilled cheese?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(ingredient)
    
    # Update with the ingredients he does not have.
    if missing_ingredients:
        missing_message = "Zarko does not have: " + ", ".join(missing_ingredients)
    else:
        missing_message = "Zarko has all the grilled cheese ingredients."
    
    say(missing_message)
    
    # Return to the starting location.
    go_to(start_loc)
"""

