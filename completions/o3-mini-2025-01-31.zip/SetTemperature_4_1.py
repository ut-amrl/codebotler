name = "SetTemperature"

prompt = "The thermostat is set to 72 degrees. Go to Arjun's office and ask if he would like the temperature to be set to a warmer or colder value. Return and tell me what temperature in degrees I should set the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    current_temp = 72  # Current thermostat setting
    current_loc = get_current_location()
    
    go_to("Arjun's office")
    response = ask("Arjun", "Would you like the temperature to be set to a warmer or colder value?", ["Warmer", "Colder"])
    
    # Decide the new temperature based on Arjun's answer.
    if response == "Warmer":
        new_temp = current_temp + 2  # setting warmer by increasing 2 degrees
    else:  # Assuming response is "Colder"
        new_temp = current_temp - 2  # setting colder by decreasing 2 degrees
    
    go_to(current_loc)
    say("Set the thermostat to " + str(new_temp) + " degrees")
"""

