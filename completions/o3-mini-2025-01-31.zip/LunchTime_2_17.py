name = "LunchTime"

prompt = "Visit Jill's office and ask her if she would like to go for lunch tomorrow. If yes, ask her when (offer some reasonable lunch time options). Let me know what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Visit Jill's office.
    go_to("Jill's office")
    
    # Ask Jill if she would like to go for lunch tomorrow.
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    
    # Based on her response, proceed accordingly.
    if response == "Yes":
        # Ask for a preferred lunch time.
        time_response = ask("Jill", "What time would you like to have lunch tomorrow?", ["12:00 PM", "12:30 PM", "1:00 PM"])
        final_message = "Jill said yes and she prefers lunch at " + time_response + "."
    else:
        final_message = "Jill said no to going for lunch tomorrow."
    
    # Return to the original location.
    go_to(start_loc)
    
    # Inform the requester of Jill's response.
    say(final_message)
"""

