name = "SetTemperature"

prompt = "The thermostat is set to 72 degrees. Go to Arjun's office and ask if he would like the temperature to be set to a warmer or colder value. Return and tell me what temperature in degrees I should set the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Go to Arjun's office.
    go_to("Arjun's office")
    
    # Ask Arjun if he wants the temperature to be warmer or colder.
    response = ask("Arjun", "Would you like the temperature to be set to a warmer or colder value?", ["Warmer", "Colder"])
    
    # The thermostat currently is set to 72 degrees.
    # Based on his response, decide the new thermostat setting.
    new_temperature = 73 if response == "Warmer" else 71
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Inform the requestor of the recommended thermostat setting.
    say("Set the thermostat to " + str(new_temperature) + " degrees.")
"""

