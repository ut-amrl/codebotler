name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later
    start_loc = get_current_location()
    
    # Totals to keep track of how many candies are needed
    total_gummies = 0
    total_caramels = 0
    total_chocolates = 0

    # Get all rooms and filter for offices
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" not in room:
            continue  # skip non-office rooms
        
        go_to(room)
        # Check if there is a person in the office; if not, skip this office
        if not is_in_room("person"):
            continue
        
        # Assume occupant's name can be extracted from the room name, e.g., "Alice's office"
        occupant = room.split("'")[0]
        
        # Ask the occupant for the number of gummies they want (options: 0,1,2,3,4)
        gummies = ask(occupant, "How many gummies would you like?", ["0", "1", "2", "3", "4"])
        # Ask for caramels
        caramels = ask(occupant, "How many caramels would you like?", ["0", "1", "2", "3", "4"])
        # Ask for chocolates
        chocolates = ask(occupant, "How many chocolates would you like?", ["0", "1", "2", "3", "4"])
        
        # Sum up the selections, converting responses from string to integer
        total_gummies += int(gummies)
        total_caramels += int(caramels)
        total_chocolates += int(chocolates)
    
    # Return to the original location and announce the totals needed
    go_to(start_loc)
    say("We need to buy {} gummies, {} caramels, and {} chocolates.".format(total_gummies, total_caramels, total_chocolates))
"""

