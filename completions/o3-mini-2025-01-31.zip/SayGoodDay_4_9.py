name = "SayGoodDay"

prompt = "Visit every lab space and when encountering an individual, tell them a Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get all rooms and filter out lab spaces (assuming lab spaces include "lab" in name)
    all_rooms = get_all_rooms()
    lab_spaces = [room for room in all_rooms if "lab" in room.lower()]
    
    # Visit each lab space.
    for lab in lab_spaces:
        go_to(lab)
        # If an individual is present, greet them.
        if is_in_room("person"):
            say("Good Day!")
"""

