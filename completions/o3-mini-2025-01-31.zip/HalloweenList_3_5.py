name = "HalloweenList"

prompt = "Find every occupied office and ask their occupants whether they would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location to return after visiting offices.
    start_loc = get_current_location()
    
    # Initialize counters for each candy type.
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0

    # Get all room names.
"""

