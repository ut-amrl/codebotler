name = "StaplerSupply"

prompt = "Go find all printer rooms that do not have a stapler. Come back and tell me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    printer_rooms_without_stapler = []
    
    for room in all_rooms:
        # Check if the room name suggests it's a printer room.
        if "printer" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                printer_rooms_without_stapler.append(room)
                
    go_to(start_loc)
    
    if printer_rooms_without_stapler:
        message = "The printer rooms without a stapler are: " + ", ".join(printer_rooms_without_stapler)
    else:
        message = "All printer rooms have a stapler."
    say(message)
"""

