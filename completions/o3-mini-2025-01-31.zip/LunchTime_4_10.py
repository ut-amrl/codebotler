name = "LunchTime"

prompt = "Ask Jill in her office if she want to go for lunch tomorrow. If yes, give her some reasonable time options and ask her to choose a time. Finally come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    
    # Ask Jill if she wants to go for lunch tomorrow
    response = ask("Jill", "Do you want to go for lunch tomorrow?", ["Yes", "No"])
    
    # If she wants to go, ask her to choose a time
    if response == "Yes":
        time_choice = ask("Jill", "What time works for you? Choose one:", ["12:00", "12:30", "1:00"])
        final_message = "Jill said Yes and selected " + time_choice + " for lunch tomorrow."
    else:
        final_message = "Jill said No to lunch tomorrow."
    
    go_to(start_loc)
    say(final_message)
"""

