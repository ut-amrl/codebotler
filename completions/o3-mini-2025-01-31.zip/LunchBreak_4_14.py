name = "LunchBreak"

prompt = "Go to Alice's office and ask her if she is free for lunch. If she says yes, tell her that we will meet in the lobby in five minutes. Do the same for Bob. Come back and tell me who will join for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later
    start_loc = get_current_location()
    
    # List to record who will join for lunch
    joiners = []
    
    # Go to Alice's office and ask if she's free for lunch
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you free for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("Alice, we will meet in the lobby in five minutes.")
        joiners.append("Alice")
    
    # Go to Bob's office and ask if he's free for lunch
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you free for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("Bob, we will meet in the lobby in five minutes.")
        joiners.append("Bob")
    
    # Return to the starting location
    go_to(start_loc)
    
    # Announce who will join for lunch
    if joiners:
        message = "The following will join for lunch: " + ", ".join(joiners)
    else:
        message = "No one will join for lunch."
    say(message)
"""

