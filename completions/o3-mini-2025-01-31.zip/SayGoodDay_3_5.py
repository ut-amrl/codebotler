name = "SayGoodDay"

prompt = "Head to each lab and in case there's a person present, bid them a Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    # Go through all rooms that are labs.
    for room in rooms:
        if "lab" in room.lower():
            go_to(room)
            # If a person is present, greet them.
            if is_in_room("person"):
                say("Good Day!")
    go_to(start_loc)
"""

