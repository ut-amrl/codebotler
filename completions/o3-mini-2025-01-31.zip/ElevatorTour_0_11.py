name = "ElevatorTour"

prompt = "Go to the elevator. Wait until someone shows up and ask them if they are here for the tour. If yes, welcome them to the university, tell them to follow you, and take them to the main conference room. If not, wait for the next person. When you get to the conference room, say you have arrived at the conference room and also say enjoy your visit here!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the elevator location
    go_to("elevator")
    
    # Loop until a person who is here for the tour is encountered.
    while True:
        # Wait until someone shows up in the elevator
        if is_in_room("person"):
            # Ask the person if they are here for the tour.
            response = ask("person", "Are you here for the tour?", ["Yes", "No"])
            
            # If the person confirms, guide them on the tour.
            if response == "Yes":
                say("Welcome to the university! Please follow me.")
                go_to("main conference room")
                say("You have arrived at the conference room.")
                say("Enjoy your visit here!")
                break
            # Otherwise, ignore and wait for the next person
        # Optionally, include a short wait before checking again
        import time
        time.sleep(1)
"""

