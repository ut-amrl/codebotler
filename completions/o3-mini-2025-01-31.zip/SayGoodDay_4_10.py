name = "SayGoodDay"

prompt = "Visit every lab space and when encountering an individual, tell them a Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    
    # Iterate over each room and check if it's a lab space.
    # We assume lab spaces have the word "lab" in their room name.
    for room in all_rooms:
        if "lab" in room.lower():
            go_to(room)
            # Check if there is any individual in the room
            if is_in_room("person"):
                say("Good Day!")
    
    go_to(start_loc)
"""

