name = "HalloweenList"

prompt = "Find every occupied office and ask their occupants whether they would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Initialize counts for each candy type
    counts = {"chocolate": 0, "caramel": 0, "gummy": 0}
    
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    
    # Loop through all rooms and check offices for occupancy.
    for room in all_rooms:
        # Identify offices by name (assuming office rooms contain the word "office")
        if "office" not in room:
            continue
        
        go_to(room)
        # Check if the office is occupied; assuming the occupant is represented by "person"
        if not is_in_room("person"):
            continue  # Skip unoccupied offices
        
        # Ask the occupant which treat they want.
        # Since we don't have the occupant's name, we'll use a generic identifier.
        response = ask("occupant", "Would you like a chocolate, caramel, or gummy?", 
                       ["chocolate", "caramel", "gummy"])
        
        # Increment the corresponding count
        if response in counts:
            counts[response] += 1
    
    # Go back to the starting location
    go_to(start_loc)
    
    # Report the totals
    say("We need to buy {0} chocolates, {1} caramels, and {2} gummies.".
        format(counts["chocolate"], counts["caramel"], counts["gummy"]))
"""

