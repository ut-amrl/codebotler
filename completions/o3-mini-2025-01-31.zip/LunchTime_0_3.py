name = "LunchTime"

prompt = "Go to Jill's office and ask her if she'd like to go for lunch tomorrow. If yes, ask her at what time (offer her some reasonable options). Come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()  # Remember the original location.
    
    # Go to Jill's office
    go_to("Jill's office")
    
    # Ask Jill if she'd like to go for lunch tomorrow.
    lunch_response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    
    # Prepare message based on her response.
    if lunch_response == "Yes":
        # If she said yes, ask her at what time with reasonable options.
        time_response = ask("Jill", "At what time would you like to have lunch?", ["12:00", "12:30", "1:00"])
        final_message = f"Jill said Yes, I'd like lunch at {time_response}."
    else:
        final_message = "Jill said No, she doesn't want to go for lunch tomorrow."
    
    # Return to the original location.
    go_to(start_loc)
    
    # Tell the original requester what Jill said.
    say(final_message)
"""

