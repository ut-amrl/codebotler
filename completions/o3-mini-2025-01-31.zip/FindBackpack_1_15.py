name = "FindBackpack"

prompt = "Search all the conference rooms for my backpack and return it to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    backpack_found = False

    # Iterate over all rooms and search only conference rooms.
    for room in get_all_rooms():
        if "conference" not in room.lower():
            continue
        go_to(room)
        if is_in_room("backpack"):
            backpack_found = True
            break

    # Return to the starting location.
    go_to(start_loc)
    
    if backpack_found:
        say("I found your backpack and returned it to you.")
    else:
        say("I could not find your backpack in any conference room.")
"""

