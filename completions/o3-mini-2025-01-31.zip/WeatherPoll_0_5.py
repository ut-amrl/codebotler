name = "WeatherPoll"

prompt = "Go to the main entrance, and wait for someone to show up. Ask them if they feel it is hot out. Repeat this until you have 10 responses, and then come back and tell me what percent of people think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time  # to use time.sleep for waiting
    start_loc = get_current_location()
    go_to("main entrance")
    total_responses = 0
    yes_count = 0

    while total_responses < 10:
        # Wait until someone shows up
        if not is_in_room("person"):
            time.sleep(1)
            continue

        # Ask the person if they feel it is hot out.
        response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
        total_responses += 1
        if response == "Yes":
            yes_count += 1

    percentage = (yes_count / total_responses) * 100
    go_to(start_loc)
    say("Out of 10 responses, " + str(percentage) + "% of people think it is hot out.")
"""

