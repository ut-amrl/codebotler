name = "FindBackpack"

prompt = "Go through every conference room and find my backpack, then bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    backpack_found = False
    found_room = ""
    
    # Loop through each room and check if it's a conference room
    for room in all_rooms:
        # Check if the room name includes "conference"
        if "conference" in room.lower():
            go_to(room)
            if is_in_room("backpack"):
                backpack_found = True
                found_room = room
                break  # Stop searching once backpack is found
                
    if backpack_found:
        # Bring the backpack back (assuming carrying it with you)
        go_to(start_loc)
        say("I found your backpack in " + found_room + " and brought it back to you.")
    else:
        go_to(start_loc)
        say("I did not find your backpack in any conference room.")
"""

