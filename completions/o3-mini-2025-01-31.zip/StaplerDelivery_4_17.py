name = "StaplerDelivery"

prompt = "Check if every printer room has a stapler. If not, put a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location
    start_loc = get_current_location()
    
    # Obtain the list of all rooms.
    all_rooms = get_all_rooms()
    
    # Filter for printer rooms (assuming the room name contains "printer")
    for room in all_rooms:
        if "printer" in room.lower():
            go_to(room)
            # Check if the current printer room has a stapler.
            if not is_in_room("stapler"):
                # If not, go to the supply room to get a stapler.
                go_to("supply room")
                say("Fetching a stapler for " + room)
                # Now go back to the printer room.
                go_to(room)
                say("Placed a stapler in " + room)
    
    # Return to the original starting location.
    go_to(start_loc)
"""

