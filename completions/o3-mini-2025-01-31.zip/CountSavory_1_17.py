name = "CountSavory"

prompt = "Visit all offices. If anyone is present; ask them to choose from the options of cupcake, ham sandwich, donut, or beef jerky. Let me know how many people selected a savory option when you return."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    savory_options = {"ham sandwich", "beef jerky"}
    savory_count = 0

    # Get all rooms and filter those with "office" in their name.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" in room:
            go_to(room)
            # Check if anyone is present in the office.
            if is_in_room("person"):
                # Ask the person to choose an option.
                response = ask("person", "Please choose one option: cupcake, ham sandwich, donut, or beef jerky.", 
                               ["cupcake", "ham sandwich", "donut", "beef jerky"])
                # Increment count if the response is a savory option.
                if response in savory_options:
                    savory_count += 1

    # Return to the starting location.
    go_to(start_loc)
    say("Number of people who selected a savory option: " + str(savory_count))
"""

