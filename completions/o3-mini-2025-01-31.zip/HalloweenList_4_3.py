name = "HalloweenList"

prompt = "Go to every office with a person, and ask them if they would like a chocolate, caramel, or gummy, then come back and tell me how many of each people asked for."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Initialize counters for each candy type.
    candy_counts = {"chocolate": 0, "caramel": 0, "gummy": 0}
    
    # Record the starting location to return at the end.
    start_loc = get_current_location()
    
    # Iterate through all rooms.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Consider only offices.
        if "office" not in room:
            continue
        
        # Go to the office.
        go_to(room)
        
        # If there's a person in the room, ask for their preference.
        if is_in_room("person"):
            # Using the room name to indicate the occupant.
            response = ask(room + " occupant", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
            # Increment the count for the chosen candy.
            candy_counts[response] += 1
            
    # Return to the starting location.
    go_to(start_loc)
    
    # Report the results.
    message = (
        "Chocolate: " + str(candy_counts["chocolate"]) +
        ", Caramel: " + str(candy_counts["caramel"]) +
        ", Gummy: " + str(candy_counts["gummy"])
    )
    say(message)
"""

