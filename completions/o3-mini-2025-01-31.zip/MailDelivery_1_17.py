name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save starting location to return later if needed.
    start_loc = get_current_location()

    # Step 1: Go to the mail room to pick up a mail bin.
    go_to("mail room")
    say("Picked up a mail bin.")

    # Step 2: Ask at every office if they have mail to deliver.
    mail_offices = []
    rooms = get_all_rooms()
    for room in rooms:
        # Identify office rooms; assume offices have "office" in their name and are not the mail room.
        if "office" in room.lower() and room.lower() != "mail room":
            go_to(room)
            response = ask(room, "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                # Ask them to put the mail in the bin.
                ask(room, "Please put your mail in the bin.", [])
                mail_offices.append(room)
    
    # Step 3: Return to the mail room with the mail.
    go_to("mail room")
    
    # Step 4: Tell the user which offices the mail are from.
    if mail_offices:
        office_list = ", ".join(mail_offices)
        say("The mail are from the following offices: " + office_list)
    else:
        say("No offices had mail to deliver.")
    
    # Step 5: Put the mail bin back.
    say("Putting the mail bin back.")
    
    # Optionally, return to starting location.
    go_to(start_loc)
"""

