name = "SayGoodDay"

prompt = "Visit each lab and if someone is present, greet them with a pleasant Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get all rooms in the building.
    rooms = get_all_rooms()
    
    # Loop through each room.
    for room in rooms:
        # Check if the room is a lab by seeing if "lab" appears in the room's name (case-insensitive).
        if "lab" in room.lower():
            go_to(room)
            # If a person is present in the lab, greet them.
            if is_in_room("person"):
                say("Good Day!")
"""

