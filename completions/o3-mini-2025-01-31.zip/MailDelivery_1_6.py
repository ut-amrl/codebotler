name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location to return later.
    start_loc = get_current_location()
    
    # Go to the mail room and pick up a mail bin.
    go_to("mail room")
    say("Picked up a mail bin.")
    
    # Initialize a list to store which offices had mail.
    offices_with_mail = []
    
    # Get a list of all rooms and filter for offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Only consider rooms with "office" in the name.
        if "office" in room.lower():
            go_to(room)
            response = ask(room, "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                # Ask them to put the mail in the bin.
                ask(room, "Please put the mail in the bin.", ["Done"])
                offices_with_mail.append(room)
    
    # Return to the mail room with the mail.
    go_to("mail room")
    
    # Report which offices provided mail.
    if offices_with_mail:
        message = "Collected mail from: " + ", ".join(offices_with_mail)
    else:
        message = "No mail was collected from any office."
    say(message)
    
    # Put the mail bin back.
    say("The mail bin has been put back.")
    
    # Optionally, return to the original starting location.
    go_to(start_loc)
"""

