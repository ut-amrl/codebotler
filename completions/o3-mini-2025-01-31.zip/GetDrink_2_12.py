name = "GetDrink"

prompt = "Go to the lobby. Ask if the visitor wants: a bottle of water, iced tea, or lemonade. Go to the kitchen and bring the visitor back what they asked for."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby to greet the visitor.
    go_to("lobby")
    
    # Ask the visitor what they would like.
    drink = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", 
                ["Bottle of water", "Iced tea", "Lemonade"])
    
    # Go to the kitchen to get the selected drink.
    go_to("kitchen")
    
    # Bring the drink back to the visitor by returning to the lobby.
    go_to("lobby")
    
    # Inform the visitor the drink is ready.
    say("Here is your " + drink)
"""

