name = "StaplerDelivery"

prompt = "Check every printer room for a stapler, and deliver a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                # No stapler in this printer room; fetch from supply room
                go_to("supply room")
                say("Picking up a stapler for " + room)
                go_to(room)
                say("Delivered a stapler to " + room)
    go_to(start_loc)
"""

