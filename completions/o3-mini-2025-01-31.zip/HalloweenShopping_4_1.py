name = "HalloweenShopping"

prompt = "Go to every office and skip any office without a person in there. Otherwise, ask the person in the office to decide on how many, from zero to four, of the following they'd like: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy. "

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return at the end.
    start_loc = get_current_location()
    
    # Counters for each candy type.
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0
    
    # Get a list of all rooms.
    all_rooms = get_all_rooms()
    
    # Iterate over all rooms.
    for room in all_rooms:
        # Consider only offices.
        if "office" not in room.lower():
            continue
        
        go_to(room)
        
        # Check if there is a person in the office.
        if not is_in_room("person"):
            continue
        
        # Extract a person name from the office name if possible.
        # For example, "Arjun's office" will return "Arjun".
        if "'s" in room:
            person = room.split("'s")[0]
        else:
            person = "there"
        
        # Ask for gummy candies.
        gummy_response = ask(person, "How many gummy candies would you like? (Choose from 0 to 4)", 
                             ["0", "1", "2", "3", "4"])
        # Ask for caramel candies.
        caramel_response = ask(person, "How many caramel candies would you like? (Choose from 0 to 4)", 
                               ["0", "1", "2", "3", "4"])
        # Ask for chocolate candies.
        chocolate_response = ask(person, "How many chocolate candies would you like? (Choose from 0 to 4)", 
                                 ["0", "1", "2", "3", "4"])
        
        # Convert responses to integers and sum.
        total_gummy += int(gummy_response)
        total_caramel += int(caramel_response)
        total_chocolate += int(chocolate_response)
    
    # After visiting all offices, return to the starting location.
    go_to(start_loc)
    
    # Say how many of each candy we need to buy.
    say("We need to buy {} gummy, {} caramel, and {} chocolate candies.".format(total_gummy, total_caramel, total_chocolate))
"""

