name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a cupcake, ham sandwich, donut, or beef jerky. Come back and tell me how many people chose a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()  # Save the starting location
    savory_count = 0
    # Get all rooms and filter for offices (assuming the room name contains "office")
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" not in room.lower():
            continue
        go_to(room)
        # Check if someone is in the office before asking
        if is_in_room("person"):
            # Ask the person their food preference
            response = ask("person", 
                           "Would you like a cupcake, ham sandwich, donut, or beef jerky?", 
                           ["cupcake", "ham sandwich", "donut", "beef jerky"])
            # Count savory choices: ham sandwich and beef jerky considered savory options.
            if response in ["ham sandwich", "beef jerky"]:
                savory_count += 1
    # Return to the starting location
    go_to(start_loc)
    # Announce the number of people who chose a savory option.
    say("Number of people who chose a savory option: " + str(savory_count))
"""

