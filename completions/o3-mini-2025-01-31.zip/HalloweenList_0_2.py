name = "HalloweenList"

prompt = "Go to every office, and if there is anyone there, ask if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Initialize counters for each treat.
    treat_counts = {"chocolate": 0, "caramel": 0, "gummy": 0}
    
    # Get all rooms and filter for offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # We assume offices have the word "office" in the room name.
        if "office" in room:
            go_to(room)
            # Check if anyone is in the office.
            if is_in_room("person"):
                # Ask the person for their treat preference.
                response = ask("person", "Would you like a chocolate, caramel, or gummy?", 
                               ["chocolate", "caramel", "gummy"])
                treat_counts[response] += 1
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Report the total number of each treat we need to buy.
    message = ("We need to buy {choc} chocolates, {caramels} caramels, and {gummies} gummies."
               .format(choc=treat_counts["chocolate"],
                       caramels=treat_counts["caramel"],
                       gummies=treat_counts["gummy"]))
    say(message)
"""

