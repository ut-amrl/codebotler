name = "WeatherPoll"

prompt = "Go to the main entrance, and wait for someone to show up. Ask them if they feel it is hot out. Repeat this until you have 10 responses, and then come back and tell me what percent of people think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    # Save the starting location to return later.
    start_loc = get_current_location()
    # Go to the main entrance.
    go_to("main entrance")
    
    yes_count = 0
    total_responses = 0
    
    # Continue collecting responses until we have 10.
    while total_responses < 10:
        # Wait until someone is in the room.
        if is_in_room("person"):
            # Ask the person if they feel it is hot out.
            response = ask("someone", "Do you feel it is hot out?", ["Yes", "No"])
            total_responses += 1
            if response == "Yes":
                yes_count += 1
        else:
            time.sleep(1)
    
    # Calculate the percentage of people who said "Yes".
    percentage = (yes_count / total_responses) * 100
    
    # Return to the starting location and announce the result.
    go_to(start_loc)
    say(str(percentage) + " percent of people think it is hot out.")
"""

