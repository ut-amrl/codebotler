name = "LunchBreak"

prompt = "Ask if Alice and Bob in their offices are up for lunch. If yes, tell them that we'll meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the current location to return later.
    start_loc = get_current_location()
    
    lunch_participants = []
    persons = [("Alice", "Alice's office"), ("Bob", "Bob's office")]
    
    # Visit each person's office and ask if they are up for lunch.
    for person, office in persons:
        go_to(office)
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            lunch_participants.append(person)
            say("We'll meet in the lobby in 5 minutes.")
    
    # Return to the original location.
    go_to(start_loc)
    
    # Tell me who all are joining for lunch.
    if lunch_participants:
        participants_str = ", ".join(lunch_participants)
        say("The following are joining for lunch: " + participants_str)
    else:
        say("No one is joining for lunch.")
"""

