name = "CountSavory"

prompt = "Go visit each office. If there is a person in the office, inquire about their liking for cupcake, ham sandwich, beef jerky, or donut. Come back and tell me of the count of people who went for a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    savory_options = ["ham sandwich", "beef jerky"]
    savory_count = 0
    start_loc = get_current_location()
    
    # Get a list of all rooms and filter for offices.
    all_rooms = get_all_rooms()
    offices = [room for room in all_rooms if "office" in room.lower()]
    
    # Visit each office.
    for office in offices:
        go_to(office)
        if is_in_room("person"):
            response = ask("person", 
                           "Which would you prefer: cupcake, ham sandwich, beef jerky, or donut?", 
                           ["cupcake", "ham sandwich", "beef jerky", "donut"])
            if response in savory_options:
                savory_count += 1
                
    # Return to the starting location and report the count.
    go_to(start_loc)
    say("The number of people who chose a savory option is " + str(savory_count))
"""

