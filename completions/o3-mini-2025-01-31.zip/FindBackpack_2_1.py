name = "FindBackpack"

prompt = "Please find my backpack in each conference room and then bring it to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    backpack_found = False
    for room in all_rooms:
        if "conference" not in room.lower():
            continue
        go_to(room)
        if is_in_room("backpack"):
            backpack_found = True
            break
    if
"""

