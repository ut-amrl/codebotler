name = "FindBackpack"

prompt = "Search all the conference rooms for my backpack and return it to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location (assumed to be "you" location)
    start_loc = get_current_location()
    
    # Get all the rooms and search through those that are conference rooms.
    all_rooms = get_all_rooms()
    backpack_found = False
    found_in = ""
    
    for room in all_rooms:
        # Check if the room is a conference room (e.g., name contains "conference")
        if "conference" in room.lower():
            go_to(room)
            if is_in_room("backpack"):
                backpack_found = True
                found_in = room
                break
                
    # If backpack is found, return it to the starting location.
    if backpack_found:
        go_to(start_loc)
        say("I have retrieved your backpack from " + found_in)
    else:
        go_to(start_loc)
        say("I could not find your backpack in any conference room.")
"""

