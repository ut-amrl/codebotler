name = "SayGoodDay"

prompt = "Visit each lab and if someone is present, greet them with a pleasant Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location so we can return later.
    start_loc = get_current_location()
    
    # Get all rooms and iterate through each one.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Only consider rooms that are labs.
        if "lab" in room.lower():
            go_to(room)
            # Check if someone is present in the lab.
            if is_in_room("person"):
                say("Good Day!")
    
    # Optionally return to the starting location after visiting all labs.
    go_to(start_loc)
"""

