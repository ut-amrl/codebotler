name = "GetDrink"

prompt = "Go to the lobby and ask any person there if they want iced tea, lemonade or a bottle of water. Bring whatever they asked for back from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby and ask a person their beverage preference.
    go_to("lobby")
    response = ask("person", "Would you like iced tea, lemonade or a bottle of water?", ["iced tea", "lemonade", "bottle of water"])
    
    # Bring the specified beverage from the kitchen.
    go_to("kitchen")
    say("I have picked up " + response)
    
    # Return to the lobby to deliver the beverage.
    go_to("lobby")
    say("I have delivered your " + response)
"""

