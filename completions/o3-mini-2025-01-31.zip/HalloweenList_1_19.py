name = "HalloweenList"

prompt = "Go to every office, and if there is a person there, ask them if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    counts = {"chocolate": 0, "caramel": 0, "gummy": 0}
    
    all_rooms = get_all_rooms()
    # Iterate over all rooms and check for offices
    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            # Check if a person is present in the office.
            if is_in_room("person"):
                response = ask("person", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
                if response in counts:
                    counts[response] += 1

    go_to(start_loc)
    message = ("We need to buy " + str(counts["chocolate"]) + " chocolates, " +
               str(counts["caramel"]) + " caramels, and " +
               str(counts["gummy"]) + " gummies.")
    say(message)
"""

