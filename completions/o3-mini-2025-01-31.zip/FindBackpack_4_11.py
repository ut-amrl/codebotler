name = "FindBackpack"

prompt = "Look in all of the conference rooms to search for my backpack and then bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    backpack_found = False
    
    for room in rooms:
        # Check if the room is a conference room (case insensitive check)
        if "conference" in room.lower():
            go_to(room)
            if is_in_room("backpack"):
                backpack_found = True
                # Assume we pick up the backpack here.
                break
    
    if backpack_found:
        go_to(start_loc)
        say("I have brought your backpack.")
    else:
        go_to(start_loc)
        say("I could not find your backpack.")
"""

