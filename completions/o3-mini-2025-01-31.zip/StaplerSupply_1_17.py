name = "StaplerSupply"

prompt = "Go to every printer room and check to see if there is a stapler. Come back and tell me which printer rooms do not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    rooms_missing_stapler = []
    
    # Loop through all rooms and target those identified as printer rooms.
    for room in all_rooms:
        # Assuming printer rooms include "printer room" in their name (case-insensitive).
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                rooms_missing_stapler.append(room)
    
    # Return to the original starting location.
    go_to(start_loc)
    
    # Prepare the message based on the rooms found.
    if rooms_missing_stapler:
        message = "The following printer rooms do not have a stapler: " + ", ".join(rooms_missing_stapler)
    else:
        message = "All printer rooms have a stapler."
    
    say(message)
"""

