name = "MailDelivery"

prompt = "Grab a mail bin from the mail room. Go to every office, and ask if they have any mail to deliver. Ask them to put all mail in the bin if there is any. Put the mail bin back in the mail room and report which offices the mail is from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location.
    start_loc = get_current_location()
    
    # Go to the mail room and grab a mail bin.
    go_to("mail room")
    # Assume that arriving at the mail room implies we have grabbed the mail bin.
    
    offices_with_mail = []
    
    # Get a
"""

