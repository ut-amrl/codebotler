name = "GetDrink"

prompt = "Ask any visitor in the lobby if they would like a bottle of water, iced tea, or lemonade. Bring what they ask for from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location.
    start_loc = get_current_location()
    
    # Go to the lobby to find a visitor.
    go_to("lobby")
    
    # Ask the visitor if they would like a bottle of water, iced tea, or lemonade.
    drink = ask("Visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["Bottle of water", "Iced tea", "Lemonade"])
    
    # Go to the kitchen to get the selected drink.
    go_to("kitchen")
    say("Picked up " + drink.lower())
    
    # Return to the lobby and deliver the drink.
    go_to("lobby")
    say("Here is your " + drink.lower())
    
    # Optional: Return to the starting location.
    go_to(start_loc)
"""

