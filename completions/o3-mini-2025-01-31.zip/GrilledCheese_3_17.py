name = "GrilledCheese"

prompt = "Compile the necessary ingredients for grilled cheese. Go to Zarko's office, ask him about his available items, and then report back to me which items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later
    start_loc = get_current_location()
    
    # Define the necessary ingredients for a grilled cheese sandwich.
    necessary_ingredients = ["bread", "cheese", "butter"]
    
    # Go to Zarko's office
    go_to("Zarko's office")
    
    # Check which ingredients Zarko does not have.
    missing_items = []
    for ingredient in necessary_ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response == "No":
            missing_items.append(ingredient)
    
    # Return to the original location and report the missing items.
    go_to(start_loc)
    if missing_items:
        say("Zarko does not have: " + ", ".join(missing_items))
    else:
        say("Zarko has all the necessary ingredients for grilled cheese.")
"""

