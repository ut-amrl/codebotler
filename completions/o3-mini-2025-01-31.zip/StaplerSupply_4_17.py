name = "StaplerSupply"

prompt = "Tell me the name of every printer room that does not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    printer_rooms_without_stapler = []
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Check if this room is a printer room.
        if "printer" in room.lower():
            go_to(room)
            # Check if there is no stapler in this room.
            if not is_in_room("stapler"):
                printer_rooms_without_stapler.append(room)
    if printer_rooms_without_stapler:
        message = "The following printer rooms do not have a stapler: " + ", ".join(printer_rooms_without_stapler)
    else:
        message = "All printer rooms have a stapler."
    say(message)
"""

