name = "LunchBreak"

prompt = "Ask if Alice and Bob in their offices are up for lunch. If yes, tell them that we'll meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the robot's starting location to return later
    start_loc = get_current_location()
    lunch_joiners = []

    # Ask Alice in her office
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("We'll meet in the lobby in 5 minutes")
        lunch_joiners.append("Alice")
    
    # Ask Bob in his office
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("We'll meet in the lobby in 5 minutes")
        lunch_joiners.append("Bob")
    
    # Return to the starting location
    go_to(start_loc)
    
    # Inform the user who all are joining for lunch
    if lunch_joiners:
        message = "Joining for lunch: " + ", ".join(lunch_joiners)
    else:
        message = "No one is joining for lunch."
    say(message)
"""

