name = "HalloweenList"

prompt = "Go to every office, and if there is anyone there, ask if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    counts = {"chocolate": 0, "caramel": 0, "gummy": 0}
    rooms = get_all_rooms()
    
    # Loop through each room and process offices only.
    for room in rooms:
        # Consider rooms with "office" in the name as office rooms.
        if "office" not in room:
            continue
        
        go_to(room)
        # Check if there's at least one person here.
        if is_in_room("person"):
            # Ask the person for their treat preference.
            response = ask("person",
                           "Would you like a chocolate, caramel, or gummy?",
                           ["chocolate", "caramel", "gummy"])
            # Increment the corresponding treat count.
            counts[response] += 1

    # Return back to original location.
    go_to(start_loc)
    message = ("We need to buy {chocolate} chocolates, {caramel} caramels, and "
               "{gummy} gummies.").format(**counts)
    say(message)
"""

