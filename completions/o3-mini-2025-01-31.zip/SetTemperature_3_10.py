name = "SetTemperature"

prompt = "Go to Arjun's office and ask him if he would like his office to be warmer or colder. The thermostat says the temperature in the office is currently 72 degrees. Come back and tell me what temperature I should reset it to based on Arjun's preferences."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    current_temp = 72
    start_loc = get_current_location()
    go_to("Arjun's office")
    response = ask("Arjun", "Would you like your office to be warmer or colder?", ["Warmer", "Colder"])
    if response == "Warmer":
        new_temp = current_temp + 3
    else:
        new_temp = current_temp - 3
    go_to(start_loc)
    say("Based on Arjun's preference, reset the thermostat to " + str(new_temp) + " degrees")
"""

