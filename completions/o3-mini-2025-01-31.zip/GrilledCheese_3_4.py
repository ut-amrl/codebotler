name = "GrilledCheese"

prompt = "Compile the necessary ingredients for grilled cheese. Go to Zarko's office, ask him about his available items, and then report back to me which items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the necessary ingredients for a grilled cheese sandwich.
    necessary_ingredients = ["bread", "cheese", "butter"]
    
    # Go to Zarko's office.
    go_to("Zarko's office")
    
    # Ask Zarko if he has each ingredient.
    missing_items = []
    for ingredient in necessary_ingredients:
        response = ask("Zarko", "Do you have " + ingredient + "?", ["Yes", "No"])
        if response == "No":
            missing_items.append(ingredient)
    
    # Create a report message detailing which items he does not have.
    if missing_items:
        message = "Zarko does not have: " + ", ".join(missing_items)
    else:
        message = "Zarko has all the necessary ingredients for grilled cheese."
    
    # Report back with the message.
    say(message)
"""

