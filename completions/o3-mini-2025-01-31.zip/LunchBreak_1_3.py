name = "LunchBreak"

prompt = "Ask Alice in her office if she is up for lunch, and if yes, tell her that we will meet in the lobby in 5 minutes. Do the same for Bob. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    
    # Ask Alice
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("We will meet in the lobby in 5 minutes.")
    
    # Ask Bob
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("We will meet in the lobby in 5 minutes.")
    
    # Return to the starting location
    go_to(start_loc)
    
    # Report who is joining for lunch
    joining = []
    if alice_response == "Yes":
        joining.append("Alice")
    if bob_response == "Yes":
        joining.append("Bob")
    
    if joining:
        say("Joining for lunch: " + ", ".join(joining))
    else:
        say("No one is joining for lunch.")
"""

