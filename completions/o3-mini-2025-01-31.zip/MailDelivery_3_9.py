name = "MailDelivery"

prompt = "Find a mail bin in the mail room and carry it with you. Collect mail from every office by asking if there is any mail they'd like delivered. If yes, ask them to put it in the bin. Return the bin to the mail room and say which offices sent mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """
"""

