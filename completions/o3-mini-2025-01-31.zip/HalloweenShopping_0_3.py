name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    # Get all rooms and filter those that are offices (assuming "office" is in the room name).
    all_rooms = get_all_rooms()
    office_rooms = [room for room in all_rooms if "office" in room.lower()]
    
    # Initialize treat counts.
    treat_counts = {"chocolate": 0, "caramel": 0, "gummy": 0}
    options = ["0", "1", "2", "3", "4"]
    
    for office in office_rooms:
        go_to(office)
        # Check if there's anyone in the office.
        if is_in_room("person"):
            # Ask the occupant for their desired number of each treat.
            chocolate_resp = ask("occupant", "How many chocolate treats would you like?", options)
            caramel_resp = ask("occupant", "How many caramel treats would you like
"""

