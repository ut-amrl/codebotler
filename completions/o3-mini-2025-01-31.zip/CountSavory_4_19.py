name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a beef jerky, cupcake, ham sandwich, or donut. Come back and tell me how many people preferred a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    savory_options = ["beef jerky", "ham sandwich"]
    savory_count = 0

    # Assume offices are rooms with "office" in their name.
    all_rooms = get_all_rooms()
    offices = [room for room in all_rooms if "office" in room.lower()]
    
    for office in offices:
        go_to(office)
        # Check if there's someone in the room.
        if is_in_room("person"):
            response = ask("person", "Would you like a beef jerky, cupcake, ham sandwich, or donut?", 
                           ["beef jerky", "cupcake", "ham sandwich", "donut"])
            if response in savory_options:
                savory_count += 1

    go_to(start_loc)
    say("Number of people who preferred a savory option: " + str(savory_count))
"""

