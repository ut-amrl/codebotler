name = "GetDrink"

prompt = "Go to the lobby and ask any person there if they want iced tea, lemonade or a bottle of water. Bring whatever they asked for back from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # First, go to the lobby to find someone to ask
    go_to("lobby")
    
    # Ask a person in the lobby about their drink preference
    drink_choice = ask("lobby guest", "Would you like iced tea, lemonade, or a bottle of water?", ["iced tea", "lemonade", "bottle of water"])
    
    # Go to the kitchen to get the drink they requested
    go_to("kitchen")
    
    # (Assume that the robot picks up the drink in the kitchen)
    # Bring the drink back to the lobby
    go_to("lobby")
    say("I brought you your " + drink_choice)
"""

