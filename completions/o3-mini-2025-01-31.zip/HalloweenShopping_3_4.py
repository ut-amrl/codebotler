name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    
    # Initialize counters for each candy type.
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0
    
    # Get list of all rooms.
    rooms = get_all_rooms()
    
    # Iterate over rooms that are offices.
    for room in rooms:
        if "office" not in room.lower():
            continue  # Skip non-office rooms.
        go_to(room)
        # Check if there is a person in the office.
        if not is_in_room("person"):
            continue
        
        # Ask the person for the quantity of each candy type.
        response_gummy = ask("person", "How many gummy would you like?", ["0", "1", "2", "3", "4"])
        response_caramel = ask("person", "How many caramel would you like?", ["0", "1", "2", "3", "4"])
        response_chocolate = ask("person", "How many chocolate would you like?", ["0", "1", "2", "3", "4"])
        
        # Convert responses to numbers and update totals.
        total_gummy += int(response_gummy)
        total_caramel += int(response_caramel)
        total_chocolate += int(response_chocolate)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Report the total quantities needed.
    say("We need {} gummy, {} caramel, and {} chocolate.".format(total_gummy, total_caramel, total_chocolate))
"""

