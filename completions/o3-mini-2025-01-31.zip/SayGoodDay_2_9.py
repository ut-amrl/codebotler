name = "SayGoodDay"

prompt = "Go through all the labs, and if there's a person inside, say 'Good Day!' to them."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Retrieve all the rooms
    all_rooms = get_all_rooms()
    
    # Iterate over each room and check if its name suggests it's a lab.
    for room in all_rooms:
        if "lab" in room.lower():
            go_to(room)
            # If there's a person in the lab, greet them.
            if is_in_room("person"):
                say("Good Day!")
"""

