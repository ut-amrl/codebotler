name = "LunchBreak"

prompt = "Ask Alice in her office if she is up for lunch, and if yes, tell her that we will meet in the lobby in 5 minutes. Do the same for Bob. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    participants = []
    
    for person in ["Alice", "Bob"]:
        # Go to the person's office (e.g., "Alice's office", "Bob's office")
        go_to(f"{person}'s office")
        # Ask if they are up for lunch
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            # Tell them to meet in the lobby in 5 minutes
            say("We will meet in the lobby in 5 minutes")
            participants.append(person)
    
    # Return to the starting location
    go_to(start_loc)
    
    # Announce who all are joining for lunch
    if participants:
        say(", ".join(participants) + " are joining for lunch.")
    else:
        say("No one is joining for lunch.")
"""

