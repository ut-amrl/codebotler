name = "LunchTime"

prompt = "Ask Jill in her office whether she will be free to go for lunch tomorrow. If yes, offer her some reasonable time options to choose from, and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return later.
    start_location = get_current_location()
    
    # Go to Jill's office.
    go_to("Jill's office")
    
    # Ask Jill if she'll be free for lunch tomorrow.
    response = ask("Jill", "Will you be free to go for lunch tomorrow?", ["Yes", "No"])
    
    # If Jill is available, ask her to choose a lunchtime option.
    if response == "Yes":
        time_option = ask("Jill", "Which time works best for you for lunch tomorrow?", ["12:00", "12:30", "1:00"])
        final_message = "Jill said she'll be free for lunch tomorrow at " + time_option + "."
    else:
        final_message = "Jill said she will not be free for lunch tomorrow."
    
    # Return to the starting location and report the result.
    go_to(start_location)
    say(final_message)
"""

