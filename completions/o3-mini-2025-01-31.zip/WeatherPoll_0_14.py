name = "WeatherPoll"

prompt = "Go to the main entrance, and wait for someone to show up. Ask them if they feel it is hot out. Repeat this until you have 10 responses, and then come back and tell me what percent of people think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    
    total_responses = 0
    yes_count = 0
    
    # Continue until we have 10 responses
    while total_responses < 10:
        # Wait for a person to show up in the room
        if is_in_room("person"):
            response = ask("person", "Do you think it's hot out?", ["Yes", "No"])
            total_responses += 1
            if response == "Yes":
                yes_count += 1
        else:
            # Wait a bit before checking again
            import time
            time.sleep(1)
    
    # Calculate the percentage of people that think it's hot
    percent = int((yes_count / total_responses) * 100)
    go_to(start_loc)
    say(str(percent) + " percent of people think it is hot out")
"""

