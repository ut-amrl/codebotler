name = "FindBackpack"

prompt = "Go through every conference room and find my backpack, then bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location (assumed to be the location of "me")
    start_loc = get_current_location()
    rooms = get_all_rooms()
    backpack_found = False

    # Iterate through every conference room.
    for room in rooms:
        # Check if this room is a conference room (case insensitive check).
        if "conference room" in room.lower():
            go_to(room)
            # Check if the backpack is in the current conference room.
            if is_in_room("backpack"):
                backpack_found = True
                break

    if backpack_found:
        # Bring the backpack back to the starting location.
        go_to(start_loc)
        say("I have found your backpack and brought it back to you.")
    else:
        go_to(start_loc)
        say("I could not find your backpack in any conference room.")
"""

