name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a beef jerky, cupcake, ham sandwich, or donut. Come back and tell me how many people preferred a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save starting location
    start_loc = get_current_location()
    savory_count = 0

    # Get all rooms and filter out those that are offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            # Check if there is someone in the office.
            if is_in_room("person"):
                # Ask the person for their snack preference.
                response = ask("person", "Would you like a beef jerky, cupcake, ham sandwich, or donut?", 
                               ["beef jerky", "cupcake", "ham sandwich", "donut"])
                # Check if the response is a savory option.
                if response in ["beef jerky", "ham sandwich"]:
                    savory_count += 1

    # Return to the original location and report the result.
    go_to(start_loc)
    say("Number of people who preferred a savory option: " + str(savory_count))
"""

