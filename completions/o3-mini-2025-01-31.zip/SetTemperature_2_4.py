name = "SetTemperature"

prompt = "The thermostat is currently set to 72 degrees. Go ask if Arjun thinks his office should be colder or warmer. Come back and tell me what temperature in degrees I should change the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # The thermostat is initially set to 72 degrees.
    current_temp = 72

    # Go to Arjun's office to ask his opinion.
    go_to("Arjun's office")
    response = ask("Arjun", "Should the office be colder or warmer than 72 degrees?", ["Colder", "Warmer"])
    
    # Compute the new thermostat setting based on his preference.
    # Here we adjust by 2 degrees: 2 degrees lower if colder; 2 degrees higher if warmer.
    if response == "Colder":
        new_temp = current_temp - 2
    else:
        new_temp = current_temp + 2

    # Return to the starting location.
    start_loc = get_current_location() 
    go_to(start_loc)
    
    # Tell the user what temperature to change the thermostat to.
    say("You should change the thermostat to " + str(new_temp) + " degrees")
"""

