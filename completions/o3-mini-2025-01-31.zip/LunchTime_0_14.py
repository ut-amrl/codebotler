name = "LunchTime"

prompt = "Go to Jill's office and ask her if she'd like to go for lunch tomorrow. If yes, ask her at what time (offer her some reasonable options). Come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    
    # Go to Jill's office
    go_to("Jill's office")
    
    # Ask if she would like to go for lunch tomorrow
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    
    # If she is interested, ask for a preferred time from reasonable options
    if response == "Yes":
        time_response = ask("Jill", "At what time would you like to go for lunch tomorrow?", ["11 AM", "12 PM", "1 PM"])
        final_answer = "Yes, at " + time_response
    else:
        final_answer = "No"
    
    # Return to the original location and report the conversation
    go_to(start_loc)
    say("Jill said: " + final_answer)
"""

