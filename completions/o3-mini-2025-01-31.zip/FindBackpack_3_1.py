name = "FindBackpack"

prompt = "Go through every conference room and find my backpack, then bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    conference_rooms = get_all_rooms()
    backpack_found = False

    # Go through each room that is a conference room.
    for room in conference_rooms:
        if "conference" not in room.lower():
            continue
        go_to(room)
        if is_in_room("backpack"):
            backpack_found = True
            break

    # If the backpack was found, bring it back.
    if backpack_found:
        go_to(start_loc)
        say("I have brought your backpack back to you.")
    else:
        go_to(start_loc)
        say("I could not find your backpack in any conference room.")
"""

