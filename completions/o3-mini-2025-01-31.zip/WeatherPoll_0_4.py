name = "WeatherPoll"

prompt = "Go to the main entrance, and wait for someone to show up. Ask them if they feel it is hot out. Repeat this until you have 10 responses, and then come back and tell me what percent of people think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    responses = 0
    yes_count = 0
    
    # continue until we have collected 10 responses
    while responses < 10:
        # Check if someone is present in the main entrance.
        if is_in_room("person"):
            response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
            if response == "Yes":
                yes_count += 1
            responses += 1
        else:
            # Wait a bit before checking again.
            time.sleep(1)
    
    percent_hot = (yes_count / 10) * 100
    go_to(start_loc)
    say("Percent of people who think it is hot out: " + str(percent_hot) + "%")
"""

