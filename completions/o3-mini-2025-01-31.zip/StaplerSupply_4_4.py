name = "StaplerSupply"

prompt = "Tell me the name of every printer room that does not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get a list of all rooms.
    rooms = get_all_rooms()
    # List to hold the names of printer rooms that do not have a stapler.
    empty_printer_rooms = []
    
    # Loop through all rooms.
    for room in rooms:
        # Check if the room name designates a printer room.
        if "printer room" in room.lower():
            go_to(room)
            # Check if there is no stapler in the room.
            if not is_in_room("stapler"):
                empty_printer_rooms.append(room)
    
    # Format and say the result.
    if len(empty_printer_rooms) == 0:
        say("All printer rooms have a stapler.")
    else:
        message = "The following printer rooms do not have a stapler: " + ", ".join(empty_printer_rooms)
        say(message)
"""

