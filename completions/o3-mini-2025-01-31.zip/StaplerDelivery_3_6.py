name = "StaplerDelivery"

prompt = "Make sure there is a stapler in each printer room. Otherwise, bring a stapler from the supply room to each printer room that currently lacks one."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Loop through all rooms and process those that are printer rooms.
    for room in get_all_rooms():
        if "printer room" in room.lower():
            go_to(room)
            # Check if the current printer room has a stapler.
            if not is_in_room("stapler"):
                # Go to the supply room to get a stapler.
                go_to("supply room")
                # Now, bring the stapler back to the printer room.
                go_to(room)
                say("Stapler delivered to " + room)
    say("Task completed")
"""

