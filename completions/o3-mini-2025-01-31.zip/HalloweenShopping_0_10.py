name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can come back.
    start_location = get_current_location()
    
    # Initialize totals for each treat.
    total_chocolates = 0
    total_caramels = 0
    total_gummies = 0
    
    # Get all rooms and filter for offices (assuming the room name contains "office").
    all_rooms = get_all_rooms()
    offices = [room for room in all_rooms if "office" in room.lower()]
    
    # Visit each office.
    for office in offices:
        go_to(office)
        # Check if there's someone in the office.
        if is_in_room("person"):
            # Ask for the number of chocolates.
            chocolate_response = ask("person", "How many chocolates would you like? (0-4)", ["0", "1", "2", "3", "4"])
            total_chocolates += int(chocolate_response)
            
            # Ask for the number of caramels.
            caramel_response = ask("person", "How many caramels would you like? (0-4)", ["0", "1", "2", "3", "4"])
            total_caramels += int(caramel_response)
            
            # Ask for the number of gummies.
            gummy_response = ask("person", "How many gummies would you like? (0-4)", ["0", "1", "2", "3", "4"])
            total_gummies += int(gummy_response)
    
    # Return to the starting location.
    go_to(start_location)
    
    # Announce the totals.
    message = ("We need to buy {} chocolates, {} caramels, and {} gummies."
               .format(total_chocolates, total_caramels, total_gummies))
    say(message)
"""

