name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. If they want a bottle of water, bring it to them from the kitchen. If they want iced tea, bring it to them from the kitchen. If they want lemonade, bring it to them from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby to speak with the visitor.
    go_to("lobby")
    # Ask the visitor which drink they would like.
    response = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["bottle of water", "iced tea", "lemonade"])
    
    # Depending on the response, go to the kitchen to retrieve the drink.
    if response in ["bottle of water", "iced tea", "lemonade"]:
        go_to("kitchen")
        # (Assume the robot picks up the requested drink in the kitchen.)
        go_to("lobby")
        say("Here is your " + response + ".")
"""

