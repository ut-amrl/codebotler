name = "GetDrink"

prompt = "Go to the lobby. Ask if the visitor wants: a bottle of water, iced tea, or lemonade. Go to the kitchen and bring the visitor back what they asked for."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby and ask the visitor for their drink choice.
    go_to("lobby")
    drink_choice = ask("Visitor", "Would you like a bottle of water, iced tea, or lemonade?", 
                       ["a bottle of water", "iced tea", "lemonade"])
    
    # Go to the kitchen to get the requested drink.
    go_to("kitchen")
    # (Assume that the robot picks up the drink here in the kitchen.)
    
    # Bring the visitor back the drink by returning to the lobby.
    go_to("lobby")
    say("Here is your " + drink_choice)
"""

