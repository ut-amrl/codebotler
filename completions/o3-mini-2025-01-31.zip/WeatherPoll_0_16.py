name = "WeatherPoll"

prompt = "Go to the main entrance, and wait for someone to show up. Ask them if they feel it is hot out. Repeat this until you have 10 responses, and then come back and tell me what percent of people think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    
    total_responses = 0
    yes_count = 0
    
    # Continue until 10 responses are collected.
    while total_responses < 10:
        # Wait for someone to show up.
        if is_in_room("person"):
            response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
            total_responses += 1
            if response == "Yes":
                yes_count += 1
        # Small delay to avoid a tight loop.
        import time
        time.sleep(1)
    
    # Calculate the percentage of "Yes" responses.
    percentage = (yes_count / total_responses) * 100
    
    # Return to the original location and announce the result.
    go_to(start_loc)
    say(str(percentage) + "% of people think it is hot out.")
"""

