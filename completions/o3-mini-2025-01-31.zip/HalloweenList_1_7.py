name = "HalloweenList"

prompt = "Go to every office, and if there is a person there, ask them if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0

    all_rooms = get_all_rooms()

    # Iterate over all rooms that are offices.
    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            # Check if there is a person in the office.
            if is_in_room("person"):
                response = ask("person", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
                if response.lower() == "chocolate":
                    chocolate_count += 1
                elif response.lower() == "caramel":
                    caramel_count += 1
                elif response.lower() == "gummy":
                    gummy_count += 1

    # Return to the starting location.
    go_to(start_loc)
    # Report how many of each item need to be bought.
    say("We need to buy {} chocolates, {} caramels, and {} gummies.".format(chocolate_count, caramel_count, gummy_count))
"""

