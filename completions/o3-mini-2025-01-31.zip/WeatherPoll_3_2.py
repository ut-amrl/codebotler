name = "WeatherPoll"

prompt = "Go to the main entrance. If there is no one there, wait for someone. Ask them if they feel it is hot out. Ask 10 people this same question until you have 10 replies. Finally, come back and tell me the percentage of people that think it's hot outside."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time

    start_loc = get_current_location()
    go_to("main entrance")
    
    # Wait until at least one person is detected
    while not is_in_room("person"):
        time.sleep(1)
    
    total_asks = 0
    yes_count = 0
    while total_asks < 10:
        # Wait for a person to be present
        if is_in_room("person"):
            response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
            total_asks += 1
            if response == "Yes":
                yes_count += 1
            # Pause briefly before asking the next person to avoid duplicate responses
            time.sleep(1)
        else:
            # If no one, wait a bit before checking again
            time.sleep(1)
    
    percentage = (yes_count / 10) * 100
    go_to(start_loc)
    say("Percentage of people that think it's hot outside: " + str(percentage) + "%")
"""

