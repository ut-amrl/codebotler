name = "SetTemperature"

prompt = "Go to Arjun's office and ask him if he would like his office to be warmer or colder. The thermostat says the temperature in the office is currently 72 degrees. Come back and tell me what temperature I should reset it to based on Arjun's preferences."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location to return later.
    start_loc = get_current_location()
    
    # Go to Arjun's office.
    go_to("Arjun's office")
    
    # Ask Arjun if he would like the office to be warmer or colder.
    response = ask("Arjun", "Would you like your office to be warmer or colder?", ["Warmer", "Colder"])
    
    # The thermostat currently reads 72 degrees.
    # Adjust the temperature based on his preference:
    # If Arjun wants it warmer, reset it to 74 degrees.
    # If he wants it colder, reset it to 70 degrees.
    if response == "Warmer":
        new_temperature = 74
    else:
        new_temperature = 70
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Inform about the new temperature setting.
    say("Reset the temperature to " + str(new_temperature) + " degrees.")
"""

