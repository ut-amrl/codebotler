name = "LunchBreak"

prompt = "Go to Alice's and Bob's offices and ask each of them if they are up for lunch. If they say yes, tell them that we will meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joining_for_lunch = []

    for person in ["Alice", "Bob"]:
        # Go to the person's office
        go_to(f"{person}'s office")
        # Ask if they are up for lunch
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            # Tell them to meet in the lobby in 5 minutes
            say("We will meet in the lobby in 5 minutes.")
            joining_for_lunch.append(person)
    
    # Return to the starting location
    go_to(start_loc)
    
    # Inform which people are joining for lunch
    if joining_for_lunch:
        lunch_message = "Joining for lunch: " + ", ".join(joining_for_lunch)
    else:
        lunch_message = "No one is joining for lunch."
    say(lunch_message)
"""

