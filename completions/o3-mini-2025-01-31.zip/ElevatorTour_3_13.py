name = "ElevatorTour"

prompt = "Go to the elevator and wait for a person to show up. When someone shows up, ask them if they are here for the tour, and if they say yes, welcome them to the university and tell them to follow you. Then take them to the main conference room. If they say no, wait for the next person. When you get to the conference room, announce your arrival at the conference room and wish them an enjoyable visit."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the elevator.
    go_to("elevator")
    
    # Wait for a person to show up in the elevator.
    while True:
        if is_in_room("person"):
            # Ask the person if they are here for the tour.
            response = ask("person", "Are you here for the tour?", ["Yes", "No"])
            if response == "Yes":
                # If they are here for the tour, welcome them and ask them to follow.
                say("Welcome to the university! Please follow me.")
                # Take them to the main conference room.
                go_to("main conference room")
                # Once there, announce arrival and wish them an enjoyable visit.
                say("We have arrived at the conference room. Enjoy your visit!")
                break
            # If they say "No", the loop continues waiting for the next person.
    
    # End of task_program function.
"""

