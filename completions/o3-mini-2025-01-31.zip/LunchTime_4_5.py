name = "LunchTime"

prompt = "Ask Jill in her office if she want to go for lunch tomorrow. If yes, give her some reasonable time options and ask her to choose a time. Finally come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    
    response = ask("Jill", "Do you want to go for lunch tomorrow?", ["Yes", "No"])
    
    # If Jill wants to go for lunch, ask her for a time option.
    if response == "Yes":
        time_option = ask("Jill", "What time would you like to meet for lunch?", ["11:00 AM", "12:00 PM", "1:00 PM"])
        final_message = "Jill said Yes and chose " + time_option
    else:
        final_message = "Jill said No"
    
    # Return to the starting location and relay the message.
    go_to(start_loc)
    say(final_message)
"""

