name = "SetTemperature"

prompt = "The thermostat is currently set to 72 degrees. Go ask if Arjun thinks his office should be colder or warmer. Come back and tell me what temperature in degrees I should change the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location to return to later.
    start_loc = get_current_location()
    
    # Go to Arjun's office to ask his preference.
    go_to("Arjun's office")
    
    # Ask Arjun if he thinks his office should be colder or warmer.
    response = ask("Arjun", "Do you think your office should be colder or warmer?", ["colder", "warmer"])
    
    # The thermostat is currently set to 72 degrees.
    # Adjust the temperature based on his response:
    # - If Arjun says "colder", lower the thermostat by 2 degrees (to 70).
    # - If he says "warmer", raise it by 2 degrees (to 74).
    if response == "colder":
        new_temperature = 70
    else:
        new_temperature = 74
    
    # Return to the original location.
    go_to(start_loc)
    
    # Tell the user the recommended temperature change.
    say("Change the thermostat to " + str(new_temperature) + " degrees.")
"""

