name = "MailDelivery"

prompt = "Take a mail bin from the mail room. For every office, ask if there is any mail to deliver and if someone says yes, ask them to put all mail in the bin. Finally find me at the mail room. Put the mail bin away, and tell me which offices had mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices_with_mail = []

    # Step 1: Go to the mail room and pick up a mail bin.
    go_to("mail room")
    # Assume that picking up the mail bin happens automatically when in the mail room.

    # Step 2: For every office, ask about mail delivery.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Identify offices by checking if the room name contains "office" but skip the mail room.
        if "office" in room and room.lower() != "mail room":
            go_to(room)
            response = ask("office occupant", "Is there any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                # Request that all mail be put in the bin.
                ask("office occupant", "Please put all mail in the bin.", ["Done"])
                offices_with_mail.append(room)

    # Step 3: Return to the mail room, put the mail bin away, and report which offices had mail.
    go_to("mail room")
    # Assume putting the mail bin away is handled implicitly.
    if offices_with_mail:
        message = "The following offices had mail: " + ", ".join(offices_with_mail)
    else:
        message = "No offices had mail."
    say(message)
    
    # Optionally return to the original starting location if needed.
    # go_to(start_loc)
"""

