name = "MovieMessenger"

prompt = "Ask Sally if she wants to go to the cinema with Mark. Tell Mark what Sally said, and if yes, ask Mark whether he wants to leave at 4PM, 5PM, or 6PM. Then then go tell Sally what Mark said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Ask Sally about going to the cinema with Mark
    sally_response = ask("Sally", "Do you want to go to the cinema with Mark?", ["Yes", "No"])
    
    # Go to Mark's location and tell him what Sally said
    go_to("Mark's office")
    say("Sally said: " + sally_response)
    
    # If Sally's answer is "Yes", ask Mark his preferred departure time.
    mark_response = ""
    if sally_response == "Yes":
        mark_response = ask("Mark", "Do you want to leave at 4PM, 5PM, or 6PM?", ["4PM", "5PM", "6PM"])
    else:
        # If Sally said "No", we can assume there's no cinema plan so no time discussion.
        mark_response = "No departure time needed since Sally said No"
    
    # Go back to Sally's location and tell her what Mark said.
    go_to("Sally's office")
    say("Mark said: " + mark_response)
"""

