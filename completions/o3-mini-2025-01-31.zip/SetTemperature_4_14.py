name = "SetTemperature"

prompt = "The thermostat is set to 72 degrees. Go to Arjun's office and ask if he would like the temperature to be set to a warmer or colder value. Return and tell me what temperature in degrees I should set the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the current location so we can return later.
    start_loc = get_current_location()
    
    # Go to Arjun's office and ask him if he would like the temperature warmer or colder.
    go_to("Arjun's office")
    response = ask("Arjun", "Would you like the temperature set to a warmer or colder value?", ["warmer", "colder"])
    
    # The thermostat is currently set to 72 degrees.
    # Adjust the temperature by 2 degrees depending on Arjun's preference.
    if response == "warmer":
        new_temperature = 74
    else:  # assuming the only other option is "colder"
        new_temperature = 70
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Inform the requester of the new thermostat setting.
    say("Set the thermostat to " + str(new_temperature) + " degrees.")
"""

