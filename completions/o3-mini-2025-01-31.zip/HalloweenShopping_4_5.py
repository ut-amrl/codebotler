name = "HalloweenShopping"

prompt = "Go to every office and skip any office without a person in there. Otherwise, ask the person in the office to decide on how many, from zero to four, of the following they'd like: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy. "

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0

    # Get all rooms and loop through each office.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" not in room:
            continue  # Skip rooms that aren't offices.
        go_to(room)
        # Check if there is a person in the office.
        if not is_in_room("person"):
            continue  # Skip this office if no person is present.

        # For the person in the office, ask for candy quantities.
        response_gummy = ask("person", "How many gummy would you like?", ["0", "1", "2", "3", "4"])
        response_caramel = ask("person", "How many caramel would you like?", ["0", "1", "2", "3", "4"])
        response_chocolate = ask("person", "How many chocolate would you like?", ["0", "1", "2", "3", "4"])

        total_gummy += int(response_gummy)
        total_caramel += int(response_caramel)
        total_chocolate += int(response_chocolate)

    # Return to the starting location and report the totals.
    go_to(start_loc)
    say("We need to buy {} gummy, {} caramel, and {} chocolate.".format(total_gummy, total_caramel, total_chocolate))
"""

