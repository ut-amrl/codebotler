name = "ElevatorTour"

prompt = "Go to the elevator, wait until someone arrives, and then ask them if they are here for the tour. If they say yes, welcome them to the university and tell them to follow you, and guide them to the main conference room. If they say no, wait for the next person. When you get to the conference room, announce your arrival at the conference room and wish them an enjoyable visit."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Start at the elevator.
    go_to("elevator")
    
    # Wait until someone arrives and ask if they are here for the tour.
    while True:
        if is_in_room("person"):
            response = ask("person", "Are you here for the tour?", ["Yes", "No"])
            if response == "Yes":
                # If they are here for the tour, welcome them and guide them.
                say("Welcome to the university! Please follow me.")
                go_to("main conference room")
                say("I have arrived at the main conference room. Enjoy your visit!")
                break
            # If they are not here for the tour, continue waiting for the next person.
        # Pause briefly before checking again.
        time.sleep(1)
"""

