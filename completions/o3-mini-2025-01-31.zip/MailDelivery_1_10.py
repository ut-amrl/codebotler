name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later
    start_loc = get_current_location()

    # Go to the mail room to pick up a mail bin.
    go_to("mail room")
    say("I have picked up a mail bin.")

    # Prepare a list to track offices that have mail.
    offices_with_mail = []

    # Get a list of all rooms and filter to those that are offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Check if the room name indicates an office. Exclude the mail room.
        if "office" in room and room != "mail room":
            go_to(room)
            # Ask if they have any mail to deliver.
            response = ask(room, "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                # Request them to put the mail in the bin.
                ask(room, "Could you please place the mail in the bin?", ["Ok"])
                offices_with_mail.append(room)

    # Return to the mail room with the mail.
    go_to("mail room")
    if offices_with_mail:
        message = "The mail are from the following offices: " + ", ".join(offices_with_mail)
    else:
        message = "No offices had mail to deliver."
    say(message)

    # Put the mail bin back.
    say("Mail bin has been put back.")
    
    # Return to the starting location.
    go_to(start_loc)
"""

