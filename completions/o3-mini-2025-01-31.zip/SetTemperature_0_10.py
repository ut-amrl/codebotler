name = "SetTemperature"

prompt = "The thermostat is set to 72 degrees. Go to Arjun's office and ask him if he'd like it to be warmer or colder. Come back and tell me what temperature I should set it to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 512,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Arjun's office")
    response = ask("Arjun", "Would you like the thermostat to be warmer or
"""

