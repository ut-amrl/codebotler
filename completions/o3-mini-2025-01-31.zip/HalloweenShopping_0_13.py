name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Record the starting location so we can return afterward.
    start_loc = get_current_location()
    
    # Get all available rooms
    rooms = get_all_rooms()
    
    # Prepare a dictionary to tally the number of treats needed.
    treat_totals = {"chocolate": 0, "caramel": 0, "gummy": 0}
    
    # Iterate over every room and check if it is an office.
    for room in rooms:
        if "office" in room:
            go_to(room)
            # Check if there is someone in the office.
            if is_in_room("person"):
                # Ask the person from 0 to 4 how many chocolate treats they would like.
                choc_response = ask("person", "How many chocolate treats would you like? (0-4)", ["0", "1", "2", "3", "4"])
                treat_totals["chocolate"] += int(choc_response)
                
                # Ask for caramel treats.
                caramel_response = ask("person", "How many caramel treats would you like? (0-4)", ["0", "1", "2", "3", "4"])
                treat_totals["caramel"] += int(caramel_response)
                
                # Ask for gummy treats.
                gummy_response = ask("person", "How many gummy treats would you like? (0-4)", ["0", "1", "2", "3", "4"])
                treat_totals["gummy"] += int(gummy_response)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Report the total number of each treat needed.
    message = ("We need to buy {} chocolate, {} caramel, "
               "and {} gummy treats").format(t
"""

