name = "LunchBreak"

prompt = "Ask if Alice and Bob in their offices are up for lunch. If yes, tell them that we'll meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joining = []
    
    # Ask Alice in her office
    go_to("Alice's office")
    response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if response == "Yes":
        say("We'll meet in the lobby in 5 minutes.")
        joining.append("Alice")
    
    # Ask Bob in his office
    go_to("Bob's office")
    response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if response == "Yes":
        say("We'll meet in the lobby in 5 minutes.")
        joining.append("Bob")
    
    # Return to the starting location and announce who is joining lunch.
    go_to(start_loc)
    if joining:
        participants = ", ".join(joining)
        say("The following are joining for lunch: " + participants)
    else:
        say("No one is joining for lunch.")
"""

