name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Go to the mail room and pick up a mail bin.
    go_to("mail room")
    # (Assume that simply going there allows us to pick a mail bin)
    
    # Prepare a list to record which offices had mail.
    offices_with_mail = []
    
    # Get a list of all rooms.
    all_rooms = get_all_rooms()
    
    # For every room that is an office, ask if they have any mail to deliver.
    for room in all_rooms:
        # We'll assume rooms with the word "office" in their name are offices.
        if "office" in room and room != "mail room":
            go_to(room)
            response = ask(room, "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                # Ask them to put the mail in the bin.
                ask(room, "Please put the mail in the bin", ["Done"])
                offices_with_mail.append(room)
    
    # After collecting the mail, return to the mail room.
    go_to("mail room")
    
    # Announce from which offices mail were received.
    if offices_with_mail:
        message = "Mail received from: " + ", ".join(offices_with_mail)
    else:
        message = "No mail was delivered."
    say(message)
"""

