name = "StaplerSupply"

prompt = "Tell me the name of every printer room that does not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    missing_stapler = []
    
    # Loop through rooms that are printer rooms (assuming "printer" in room name indicates a printer room)
    for room in all_rooms:
        if "printer" not in room.lower():
            continue
        go_to(room)
        if not is_in_room("stapler"):
            missing_stapler.append(room)
    
    go_to(start_loc)
    
    if missing_stapler:
        message = "The following printer rooms do not have a stapler: " + ", ".join(missing_stapler)
    else:
        message = "All printer rooms have a stapler."
    say(message)
"""

