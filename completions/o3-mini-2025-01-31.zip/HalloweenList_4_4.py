name = "HalloweenList"

prompt = "Go to every office with a person, and ask them if they would like a chocolate, caramel, or gummy, then come back and tell me how many of each people asked for."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0

    # Iterate over all rooms and check only offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" in room:  # assumes office rooms have "office" in their name
            go_to(room)
            # Check if there's a person in the office.
            if is_in_room("person"):
                response = ask("person", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
                if response == "chocolate":
                    chocolate_count += 1
                elif response == "caramel":
                    caramel_count += 1
                elif response == "gummy":
                    gummy_count += 1

    go_to(start_loc)
    final_message = ("Chocolates: " + str(chocolate_count) + ", " +
                     "Caramels: " + str(caramel_count) + ", " +
                     "Gummies: " + str(gummy_count))
    say(final_message)
"""

