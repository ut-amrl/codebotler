name = "HalloweenShopping"

prompt = "Go to every office and skip any office without a person in there. Otherwise, ask the person in the office to decide on how many, from zero to four, of the following they'd like: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy. "

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Record the starting location so we can return at the end.
    start_loc = get_current_location()
    
    # Get a list of all rooms.
    all_rooms = get_all_rooms()
    
    # Initialize counters for each type of candy.
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0
    
    # Define the options for selecting candy quantity.
    options = ["0", "1", "2", "3", "4"]
    
    # Loop over every room that is an office.
    for room in all_rooms:
        # Only consider rooms with "office" in their name.
        if "office" not in room.lower():
            continue
        
        # Go to the office.
        go_to(room)
        
        # Check if a person is in this office.
        if not is_in_room("person"):
            continue
        
        # Ask the person for the number of gummy they would like.
        gummy_response = ask("person", "How many gummy would you like (0-4)?", options)
        # Ask for caramel.
        caramel_response = ask("person", "How many caramel would you like (0-4)?", options)
        # Ask for chocolate.
        chocolate_response = ask("person", "How many chocolate would you like (0-4)?", options)
        
        # Convert the responses to integers and add them to totals.
        total_gummy += int(gummy_response)
        total_caramel += int(caramel_response)
        total_chocolate += int(chocolate_response)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Construct the final message.
    final_message = ("We need to buy {} gummy, {} caramel, and {} chocolate."
                     .format(total_gummy, total_caramel, total_chocolate))
    say(final_message)
"""

