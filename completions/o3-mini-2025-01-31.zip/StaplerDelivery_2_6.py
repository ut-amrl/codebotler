name = "StaplerDelivery"

prompt = "Check if there is a stapler in every printer room. For each visited room without a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get all rooms and iterate over those that are printer rooms.
    all_rooms = get_all_rooms()
    
    for room in all_rooms:
        # Check if the room is a printer room by keyword.
        if "printer room" in room.lower():
            go_to(room)
            # Check if a stapler is present in this printer room.
            if not is_in_room("stapler"):
                # No stapler found: deliver one from the supply room.
                go_to("supply room")
                say("Picked up a stapler for delivery")
                go_to(room)
                say("Delivered a stapler to " + room)
                
    # Task complete message (can be added here if needed)
    say("Completed checking all printer rooms and delivering staplers where needed.")
"""

