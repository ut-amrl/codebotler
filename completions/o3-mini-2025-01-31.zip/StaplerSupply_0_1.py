name = "StaplerSupply"

prompt = "Check every printer room for a stapler, and come back and tell me which ones do not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    rooms_without_stapler = []
    for room in all_rooms:
        # Check if the room is a printer room by checking if "printer" is in its name (case insensitive)
        if "printer" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                rooms_without_stapler.append(room)
    go_to(start_loc)
    if rooms_without_stapler:
        message = "The following printer rooms do not have a stapler: " + ", ".join(rooms_without_stapler)
    else:
        message = "All printer rooms have a stapler."
    say(message)
"""

