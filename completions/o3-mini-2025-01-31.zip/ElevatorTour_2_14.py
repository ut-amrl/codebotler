name = "ElevatorTour"

prompt = "Go to the elevator and wait for someone to arrive. Inquire if they are here for the tour, and if they say yes, welcome them to the university and tell them to follow you. Then take them to the main conference room. If they say no, wait for someone else. When you get to the conference room, announce your arrival at the conference room and wish them an enjoyable visit."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the elevator.
    go_to("elevator")
    
    # Wait for someone to arrive at the elevator.
    import time
    while True:
        # Check if there's a person present.
        if is_in_room("person"):
            # Inquire if they are here for the tour.
            response = ask("person", "Are you here for the tour?", ["Yes", "No"])
            if response == "Yes":
                # Welcome the person and tell them to follow.
                say("Welcome to the university. Please follow me.")
                # Take them to the main conference room.
                go_to("main conference room")
                # Announce the arrival at the conference room and wish them an enjoyable visit.
                say("I have arrived at the conference room. Enjoy your visit!")
                break
            # If they are not here for the tour, continue waiting.
        time.sleep(1)
"""

