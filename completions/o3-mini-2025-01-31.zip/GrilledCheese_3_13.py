name = "GrilledCheese"

prompt = "Compile the necessary ingredients for grilled cheese. Go to Zarko's office, ask him about his available items, and then report back to me which items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the necessary ingredients for a grilled cheese sandwich.
    necessary_ingredients = ["bread", "cheese", "butter"]
    missing_items = []
    
    # Go to Zarko's office to ask him about his available items.
    go_to("Zarko's office")
    
    # For each ingredient, ask Zarko if he has it.
    for item in necessary_ingredients:
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "No":
            missing_items.append(item)
    
    # Prepare the report message.
    if missing_items:
        missing_str = ", ".join(missing_items)
    else:
        missing_str = "none; Zarko has all the necessary items"
    
    # Report back the missing items.
    say("Zarko does not have: " + missing_str)
"""

