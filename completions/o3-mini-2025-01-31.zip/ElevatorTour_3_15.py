name = "ElevatorTour"

prompt = "Go to the elevator and wait for a person to show up. When someone shows up, ask them if they are here for the tour, and if they say yes, welcome them to the university and tell them to follow you. Then take them to the main conference room. If they say no, wait for the next person. When you get to the conference room, announce your arrival at the conference room and wish them an enjoyable visit."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the elevator and wait for someone to show up.
    go_to("elevator")
    
    # Loop until we find a person who is here for the tour.
    while True:
        if is_in_room("person"):
            # Ask the person if they are here for the tour.
            response = ask("person", "Are you here for the tour?", ["Yes", "No"])
            if response == "Yes":
                # Welcome the person, instruct them to follow, and take them to the main conference room.
                say("Welcome to the university! Please follow me.")
                go_to("main conference room")
                # Announce arrival at the conference room and wish them an enjoyable visit.
                say("We have arrived at the conference room. Enjoy your visit!")
                break
            # If the response is "No", continue waiting for the next person.
        # Optionally, wait a short amount of time before re-checking for a person.
        # time.sleep(1)  # Uncomment if a delay is needed.
"""

