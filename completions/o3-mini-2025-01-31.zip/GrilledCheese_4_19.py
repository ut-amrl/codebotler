name = "GrilledCheese"

prompt = "Put together a list of grilled cheese ingredients. Head to Zarko's office and inquire about his available ingredients. Return and inform me of what he is missing."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the required ingredients for a grilled cheese sandwich.
    ingredients = ["bread", "cheese", "butter"]
    missing = []
  
    # Store the starting location to return later.
    start_loc = get_current_location()
    
    # Go to Zarko's office to inquire about his ingredients.
    go_to("Zarko's office")
    
    # For each ingredient, ask if he has it.
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient} for the grilled cheese?", ["Yes", "No"])
        if response == "No":
            missing.append(ingredient)
    
    # Return to the original location.
    go_to(start_loc)
    
    # Inform what Zarko is missing.
    if missing:
        missing_text = ", ".join(missing)
        say("Zarko is missing: " + missing_text)
    else:
        say("Zarko has all the grilled cheese ingredients.")
"""

