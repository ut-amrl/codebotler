name = "StaplerDelivery"

prompt = "Check every printer room for a stapler, and deliver a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get a list of all rooms.
    all_rooms = get_all_rooms()
    # Iterate through each room to identify printer rooms.
    for room in all_rooms:
        # Check if the room name indicates it's a printer room.
        if "printer" in room.lower():
            go_to(room)
            # Check if a stapler is present in the printer room.
            if not is_in_room("stapler"):
                # Deliver a stapler: go to the supply room to get one.
                go_to("supply room")
                # (Assume the stapler is now picked up from the supply room)
                go_to(room)
                say("Stapler delivered to " + room)
"""

