name = "LunchBreak"

prompt = "Ask if Alice and Bob in their offices are up for lunch. If yes, tell them that we'll meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joiners = []
    # Ask Alice
    go_to("Alice's office")
    response_alice = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if response_alice == "Yes":
        joiners.append("Alice")
        say("We'll meet in the lobby in 5 minutes")
        
    # Ask Bob
    go_to("Bob's office")
    response_bob = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if response_bob == "Yes":
        joiners.append("Bob")
        say("We'll meet in the lobby in 5 minutes")
        
    go_to(start_loc)
    if joiners:
        say("Joining for lunch: " + ", ".join(joiners))
    else:
        say("No one is joining for lunch")
"""

