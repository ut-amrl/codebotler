name = "GrilledCheese"

prompt = "Compile the necessary ingredients for grilled cheese. Go to Zarko's office, ask him about his available items, and then report back to me which items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the necessary ingredients for grilled cheese.
    necessary_ingredients = ["bread", "cheese", "butter"]
    missing_ingredients = []
    
    # Save the current location to return later.
    start_loc = get_current_location()
    
    # Go to Zarko's office.
    go_to("Zarko's office")
    
    # Ask Zarko about each ingredient.
    for ingredient in necessary_ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(ingredient)
    
    # Assemble the report message.
    if missing_ingredients:
        missing_msg = ", ".join(missing_ingredients)
        report_message = "Zarko does not have: " + missing_msg
    else:
        report_message = "Zarko has all the necessary ingredients for grilled cheese."
    
    # Return to the original location and report back.
    go_to(start_loc)
    say(report_message)
"""

