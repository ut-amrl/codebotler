name = "ElevatorTour"

prompt = "Go to the elevator. Wait until someone shows up and ask them if they are here for the tour. If yes, welcome them to the university, tell them to follow you, and take them to the main conference room. If not, wait for the next person. When you get to the conference room, say you have arrived at the conference room and also say enjoy your visit here!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()  # Save the starting location if needed later.
    go_to("elevator")  # Go to the elevator.
    
    # Wait until a person shows up at the elevator.
    while True:
        if is_in_room("person"):
            # Ask the person if they are here for the tour.
            # Using "person" as the placeholder name since we don't have a specific identifier.
            answer = ask("person", "Are you here for the tour?", ["Yes", "No"])
            if answer == "Yes":
                # If the person is here for the tour, welcome them and instruct them to follow.
                say("Welcome to the university. Please follow me.")
                # Take them to the main conference room.
                go_to("main conference room")
                # Upon arrival, announce arrival and well wishes.
                say("I have arrived at the conference room")
                say("Enjoy your visit here!")
                break  # Exit the loop as the task is completed.
            # If the answer is "No", continue waiting for the next person.
        time.sleep(1)  # Wait a bit before checking again.
"""

