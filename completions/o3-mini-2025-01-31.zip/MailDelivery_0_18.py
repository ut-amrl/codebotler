name = "MailDelivery"

prompt = "Pick up a mail bin from the mail room. Go to every office and ask if they have any mail they'd like delivered. If so, ask them to put it in the mail bin. Finally, meet me in the mail room with all the mail. Place the mail bin back and tell me which offices they are from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the mail room and pick up a mail bin.
    go_to("mail room")
    
    # Prepare a list to record which offices have mail.
    offices_with_mail = []
    
    # Get all rooms and filter for offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            # Ask if they
"""

