name = "FindBackpack"

prompt = "Check where I left my backpack in all of the conference rooms and bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    backpack_found = False
    found_room = ""
    
    for room in all_rooms:
        if "conference" in room.lower():
            go_to(room)
            if is_in_room("backpack"):
                backpack_found = True
                found_room = room
                break

    if backpack_found:
        say("I found your backpack in " + found_room)
        # Assume picking the backpack up automatically
        go_to(start_loc)
        say("I have brought your backpack back to you")
    else:
        go_to(start_loc)
        say("I could not find your backpack in any conference room")
"""

