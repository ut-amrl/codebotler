name = "MovieMessenger"

prompt = "Ask Sally in her office if she wants to go to the cinema with Mark. Go to Mark's office and tell him Sally's answer. If Sally says yes, ask Mark whether he wants to leave at 4PM, 5PM, or 6PM - then go tell Sally what time Mark is leaving."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to Sally's office to ask if she wants to go to the cinema with Mark.
    go_to("Sally's office")
    sally_answer = ask("Sally", "Do you want to go to the cinema with Mark?", ["Yes", "No"])
    
    # Go to Mark's office to tell him Sally's answer.
    go_to("Mark's office")
    say("Sally said " + sally_answer)
    
    # If Sally agreed, ask Mark which time he wants to leave.
    if sally_answer == "Yes":
        mark_time = ask("Mark", "When do you want to leave?", ["4PM", "5PM", "6PM"])
        # Go back to Sally's office to inform her of Mark's chosen time.
        go_to("Sally's office")
        say("Mark is leaving at " + mark_time)
"""

