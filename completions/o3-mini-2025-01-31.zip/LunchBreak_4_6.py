name = "LunchBreak"

prompt = "Go to Alice's office and ask her if she is free for lunch. If she says yes, tell her that we will meet in the lobby in five minutes. Do the same for Bob. Come back and tell me who will join for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    lunch_participants = []
    
    # Check with Alice
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you free for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        lunch_participants.append("Alice")
        say("Alice, we will meet in the lobby in five minutes.")
        
    # Check with Bob
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you free for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        lunch_participants.append("Bob")
        say("Bob, we will meet in the lobby in five minutes.")
        
    # Return to original location and report
    go_to(start_loc)
    if lunch_participants:
        participants = ", ".join(lunch_participants)
        say(participants + " will join for lunch.")
    else:
        say("No one will join for lunch.")
"""

