name = "LunchTime"

prompt = "Ask Jill in her office whether she will be free to go for lunch tomorrow. If yes, offer her some reasonable time options to choose from, and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    
    availability = ask("Jill", "Will you be free to go for lunch tomorrow?", ["Yes", "No"])
    
    if availability == "Yes":
        time_option = ask("Jill", "Which time would work best for you?", ["12:00", "12:30", "1:00"])
        message = "Jill said she is free and would prefer lunch at " + time_option + "."
    else:
        message = "Jill said she is not free for lunch tomorrow."
    
    go_to(start_loc)
    say(message)
"""

