name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    
    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0

    for room in all_rooms:
        # Check only offices (rooms whose name contains "office")
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                # Ask the person in the office about their candy preferences.
                caramel_resp = ask("person", "How many caramel candies would you like? (choose 0-4)", ["0", "1", "2", "3", "4"])
                chocolate_resp = ask("person", "How many chocolate candies would you like? (choose 0-4)", ["0", "1", "2", "3", "4"])
                gummy_resp = ask("person", "How many gummy candies would you like? (choose 0-4)", ["0", "1", "2", "3", "4"])
                
                total_caramel += int(caramel_resp)
                total_chocolate += int(chocolate_resp)
                total_gummy += int(gummy_resp)

    go_to(start_loc)
    message = ("We need to buy {} caramel, {} chocolate, and {} gummy candies."
               .format(total_caramel, total_chocolate, total_gummy))
    say(message)
"""

