name = "GrilledCheese"

prompt = "Put together a list of grilled cheese ingredients. Head to Zarko's office and inquire about his available ingredients. Return and inform me of what he is missing."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the list of grilled cheese ingredients.
    ingredients = ["bread", "cheese", "butter"]
    missing_ingredients = []

    # Save the starting location.
    start_loc = get_current_location()
    
    # Go to Zarko's office.
    go_to("Zarko's office")
    
    # Inquire about each grilled cheese ingredient.
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(ingredient)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Inform the result.
    if missing_ingredients:
        missing_str = ", ".join(missing_ingredients)
        say("Zarko is missing: " + missing_str)
    else:
        say("Zarko has all the grilled cheese ingredients.")
"""

