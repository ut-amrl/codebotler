name = "WeatherPoll"

prompt = "Go wait for someone at the main entrance. Ask them if they feel it is hot out, then wait for the next person and ask the same question. Do this until you have ten responses, then come back and report the percentage of people who think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time

    start_loc = get_current_location()
    go_to("main entrance")
    
    total_responses = 0
    yes_count = 0
    
    # Continue until we have collected 10 responses.
    while total_responses < 10:
        # Wait for someone to be in the room.
        if is_in_room("person"):
            response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
            total_responses += 1
            if response == "Yes":
                yes_count += 1
            # Give time for the current person to leave.
            time.sleep(2)
        # Wait a bit before checking again.
        time.sleep(1)
    
    percentage = (yes_count / total_responses) * 100
    go_to(start_loc)
    say("Out of 10 people, " + str(percentage) + " percent think it is hot out.")
"""

