name = "GetDrink"

prompt = "Ask any visitor in the lobby if they would like a bottle of water, iced tea, or lemonade. Bring what they ask for from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later if needed.
    start_loc = get_current_location()
    
    # Go to the lobby and ask a visitor their drink preference.
    go_to("lobby")
    choice = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["bottle of water", "iced tea", "lemonade"])
    
    # Go to the kitchen to get the selected drink.
    go_to("kitchen")
    
    # Now, bring the selected drink back to the lobby.
    go_to("lobby")
    say("Here is your " + choice)
    
    # Optionally, return to the starting location.
    go_to(start_loc)
"""

