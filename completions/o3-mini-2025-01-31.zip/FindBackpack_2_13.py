name = "FindBackpack"

prompt = "Please find my backpack in each conference room and then bring it to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Record the starting location so we can bring the backpack(s) back here.
    start_loc = get_current_location()
    
    # Get a list of all rooms and filter for conference rooms.
    all_rooms = get_all_rooms()
    conference_rooms = [room for room in all_rooms if "conference" in room.lower()]
    
    # Iterate over each conference room.
    for room in conference_rooms:
        # Go to the current conference room.
        go_to(room)
        # Check if the backpack is in the room.
        if is_in_room("backpack"):
            # Assume that finding the backpack implies picking it up.
            # Bring the backpack back to the starting location.
            go_to(start_loc)
            say("I
"""

