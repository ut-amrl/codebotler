name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location to return at the end.
    start_loc = get_current_location()
    
    # Initialize totals for each candy.
    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0
    
    # Get the list of all rooms.
    all_rooms = get_all_rooms()
    
    # Filter out all offices.
    offices = [room for room in all_rooms if "office" in room.lower()]
    
    # Options for asking quantity.
    options = ["0", "1", "2", "3", "4"]
    
    # For each office, if someone is present, ask for their candy preferences.
    for office in offices:
        go_to(office)
        # Check if there is anyone in the office.
        if is_in_room("person"):
            # Ask for caramel.
            caramel_response = ask("person", "How many caramel would you like? (choose 0-4)", options)
            # Ask for chocolate.
            chocolate_response = ask("person", "How many chocolate would you like? (choose 0-4)", options)
            # Ask for gummy.
            gummy_response = ask("person", "How many gummy would you like? (choose 0-4)", options)
            
            # Convert responses to integers and update totals.
            total_caramel += int(caramel_response)
            total_chocolate += int(chocolate_response)
            total_gummy += int(gummy_response)

    # After processing all offices, go back to the starting location.
    go_to(start_loc)
    
    # Construct the final message.
    final_message = ("We need to buy {} caramel, {} chocolate, and {} gummy."
                     .format(total_caramel, total_chocolate, total_gummy))
    say(final_message)
"""

