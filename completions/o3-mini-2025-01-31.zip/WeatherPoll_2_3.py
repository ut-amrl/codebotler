name = "WeatherPoll"

prompt = "Go wait for someone at the main entrance. Ask them if they feel it is hot out, then wait for the next person and ask the same question. Do this until you have ten responses, then come back and report the percentage of people who think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    responses = 0
    yes_count = 0

    while responses < 10:
        # Wait until someone arrives at the main entrance.
        while not is_in_room("person"):
            time.sleep(1)
        
        # Ask the person if they think it is hot out.
        response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
        responses += 1
        if response == "Yes":
            yes_count += 1
        
        # Wait for the person to leave to be ready for the next person.
        while is_in_room("person"):
            time.sleep(1)
    
    # Calculate the percentage of people who said "Yes".
    percentage = (yes_count / responses) * 100
    
    go_to(start_loc)
    say("Percentage of people who think it is hot out: " + str(percentage) + "%")
"""

