name = "SetTemperature"

prompt = "The thermostat is currently set to 72 degrees. Go ask if Arjun thinks his office should be colder or warmer. Come back and tell me what temperature in degrees I should change the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # The current thermostat setting
    current_temp = 72
    start_loc = get_current_location()
    
    # Go to Arjun's office and ask his preference
    go_to("Arjun's office")
    response = ask("Arjun", "Do you think the office should be colder or warmer?", ["colder", "warmer"])
    
    # Decide on the new temperature.
    # Adjust by 2 degrees: lower if colder, increase if warmer.
    if response.lower() == "colder":
        new_temp = current_temp - 2
    else:
        new_temp = current_temp + 2
    
    # Return to starting location and report the new temperature.
    go_to(start_loc)
    say("You should change the thermostat to " + str(new_temp) + " degrees.")
"""

