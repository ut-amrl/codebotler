name = "WeatherPoll"

prompt = "Go wait for someone at the main entrance. Ask them if they feel it is hot out, then wait for the next person and ask the same question. Do this until you have ten responses, then come back and report the percentage of people who think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    responses_needed = 10
    responses_collected = 0
    hot_count = 0
    
    while responses_collected < responses_needed:
        # Wait for someone to be in the room
        while not is_in_room("person"):
            time.sleep(1)
        # Ask the person the question
        response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
        if response == "Yes":
            hot_count += 1
        responses_collected += 1
        # Optional wait for the next person to avoid repeatedly polling the same individual.
        time.sleep(1)
        
    percentage = (hot_count / responses_needed) * 100
    go_to(start_loc)
    say("Percentage of people who think it is hot out: " + str(percentage) + "%")
"""

