name = "StaplerSupply"

prompt = "Go to every printer room and check to see if there is a stapler. Come back and tell me which printer rooms do not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms_missing_stapler = []
    
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Check for printer room by looking for "printer" in the room name (case insensitive)
        if "printer" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                rooms_missing_stapler.append(room)
    
    go_to(start_loc)
    if rooms_missing_stapler:
        message = "The following printer rooms do not have a stapler: " + ", ".join(rooms_missing_stapler)
    else:
        message = "All printer rooms have a stapler."
    say(message)
"""

