name = "StaplerSupply"

prompt = "Check all printer rooms for staplers, and come back and tell me which ones do not have any staplers."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    printer_rooms_without_staplers = []
    
    # Iterate through all rooms and process those that are printer rooms.
    for room in all_rooms:
        if "printer" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                printer_rooms_without_staplers.append(room)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Formulate and say the result message.
    if printer_rooms_without_staplers:
        message = "The following printer rooms do not have staplers: " + ", ".join(printer_rooms_without_staplers)
    else:
        message = "All printer rooms have staplers."
    say(message)
"""

