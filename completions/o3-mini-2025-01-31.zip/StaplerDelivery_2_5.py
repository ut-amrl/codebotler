name = "StaplerDelivery"

prompt = "Check if there is a stapler in every printer room. For each visited room without a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get all rooms and filter those that are printer rooms.
    all_rooms = get_all_rooms()
    printer_rooms = [room for room in all_rooms if "printer" in room.lower()]
    
    # For each printer room, check for a stapler.
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            # If no stapler is present, pick one up from the supply room and deliver it.
            go_to("supply room")
            say("Picking up a stapler for " + room)
            go_to(room)
            say("Delivered a stapler from the supply room to " + room)
    
    say("Stapler check and delivery for all printer rooms is complete.")
"""

