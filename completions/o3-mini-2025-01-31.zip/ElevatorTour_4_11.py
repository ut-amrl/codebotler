name = "ElevatorTour"

prompt = "Go to the elevator, wait until someone arrives, and then ask them if they are here for the tour. If they say yes, welcome them to the university and tell them to follow you, and guide them to the main conference room. If they say no, wait for the next person. When you get to the conference room, announce your arrival at the conference room and wish them an enjoyable visit."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time  # Import time for waiting
    # Go to the elevator.
    go_to("elevator")
    
    # Wait until someone arrives at the elevator.
    while True:
        if is_in_room("person"):
            # Ask the arriving person if they are here for the tour.
            response = ask("person", "Are you here for the tour?", ["Yes", "No"])
            # If they say yes, welcome them and guide them.
            if response == "Yes":
                say("Welcome to the university! Please follow me.")
                go_to("main conference room")
                say("We have arrived at the conference room. Enjoy your visit!")
                break  # Exit the loop after guiding them.
            # If they say no, continue waiting for the next person.
        time.sleep(1)  # Wait a bit before checking again.
"""

