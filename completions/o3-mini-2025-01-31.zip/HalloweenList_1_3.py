name = "HalloweenList"

prompt = "Go to every office, and if there is a person there, ask them if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices = [room for room in get_all_rooms() if "office" in room]
    
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0

    for office in offices:
        go_to(office)
        if is_in_room("person"):
            # Ask the person in the office their candy preference.
            response = ask("occupant", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
            if response == "chocolate":
                chocolate_count += 1
            elif response == "caramel":
                caramel_count += 1
            elif response == "gummy":
                gummy_count += 1

    go_to(start_loc)
    message = ("We need to buy {} chocolate(s), {} caramel(s), and {} gummy(s)."
               .format(chocolate_count, caramel_count, gummy_count))
    say(message)
"""

