name = "SetTemperature"

prompt = "The thermostat is set to 72 degrees. Go to Arjun's office and ask if he would like the temperature to be set to a warmer or colder value. Return and tell me what temperature in degrees I should set the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    current_temperature = 72
    start_loc = get_current_location()
    go_to("Arjun's office")
    response = ask("Arjun", "Would you like the temperature to be set to a warmer or colder value?", ["warmer", "colder"])
    
    # Adjust the temperature by 2 degrees depending on response.
    if response == "warmer":
        new_temperature = current_temperature + 2
    else:
        new_temperature = current_temperature - 2
        
    go_to(start_loc)
    say("Set the thermostat to " + str(new_temperature) + " degrees.")
"""

