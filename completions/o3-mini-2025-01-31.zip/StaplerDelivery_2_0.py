name = "StaplerDelivery"

prompt = "Check if there is a stapler in every printer room. For each visited room without a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    for room in rooms:
        # Check for printer rooms by checking if "printer" is in the room name (case insensitive)
        if "printer" not in room.lower():
            continue

        # Go to the printer room and check for a stapler.
        go_to(room)
        if not is_in_room("stapler"):
            # Stapler missing: go to the supply room to fetch one.
            go_to("supply room")
            # (Assuming that physically picking up the stapler is implicit upon visiting the supply room.)
            # Deliver the stapler to the printer room.
            go_to(room)
            say("A stapler has been delivered to " + room)
    go_to(start_loc)
"""

