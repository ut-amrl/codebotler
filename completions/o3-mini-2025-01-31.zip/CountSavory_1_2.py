name = "CountSavory"

prompt = "Visit all offices. If anyone is present; ask them to choose from the options of cupcake, ham sandwich, donut, or beef jerky. Let me know how many people selected a savory option when you return."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Initialize savory selection counter.
    savory_count = 0
    
    # Get a list of all rooms.
    rooms = get_all_rooms()
    
    # Iterate through all rooms to find offices.
    for room in rooms:
        if "office" in room.lower():
            # Go to the office.
            go_to(room)
            # Check if there's anyone present.
            if is_in_room("person"):
                # Ask the person to choose an option.
                response = ask("person", 
                               "Please choose one option: cupcake, ham sandwich, donut, or beef jerky.", 
                               ["cupcake", "ham sandwich", "donut", "beef jerky"])
                # Ham sandwich and beef jerky are savory options.
                if response in ["ham sandwich", "beef jerky"]:
                    savory_count += 1
    
    # Return to the starting location.
    go_to(start_loc)
    # Let the user know how many people selected a savory option.
    say("Number of people who selected a savory option: " + str(savory_count))
"""

