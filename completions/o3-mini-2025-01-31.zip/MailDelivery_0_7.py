name = "MailDelivery"

prompt = "Pick up a mail bin from the mail room. Go to every office and ask if they have any mail they'd like delivered. If so, ask them to put it in the mail bin. Finally, meet me in the mail room with all the mail. Place the mail bin back and tell me which offices they are from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Step 1: Pick up the mail bin from the mail room.
    go_to("mail room")
    say("I have picked up the mail bin.")
    
    # List to store the names of offices that have mail.
    offices_with_mail = []
    
    # Step 2: Visit every office.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" not in room:
            continue  # Only consider offices.
        go_to(room)
        # Ask if the office has any mail they'd like delivered.
        response = ask("Office occupant", "Do you have any mail you'd like delivered?", ["Yes", "No"])
        if response == "Yes":
            # Ask them to place the mail in the mail bin.
            ask("Office occupant", "Please place your mail in the mail bin.", ["OK"])
            offices_with_mail.append(room)
    
    # Step 3: Return to the mail room to meet with the collected mail.
    go_to("mail room")
    say("I have arrived in the mail room with the mail.")
    
    # Step 4: Place the mail bin back and report which offices contributed mail.
    message = "Placing the mail bin back. "
    if offices_with_mail:
        message += "Mail was collected from these offices: " + ", ".join(offices_with_mail)
    else:
        message += "No offices had mail for delivery."
    say(message)
"""

