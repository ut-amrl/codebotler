name = "SetTemperature"

prompt = "The thermostat is currently set to 72 degrees. Go ask if Arjun thinks his office should be colder or warmer. Come back and tell me what temperature in degrees I should change the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # The thermostat is currently set to 72 degrees.
    initial_temp = 72
    start_loc = get_current_location()
    
    go_to("Arjun's office")
    response = ask("Arjun", "Should your office be colder or warmer?", ["colder", "warmer"])
    
    # Adjust the temperature based on Arjun's response.
    if response == "colder":
        new_temp = initial_temp - 2  # Lower by 2 degrees if colder.
    elif response == "warmer":
        new_temp = initial_temp + 2  # Raise by 2 degrees if warmer.
    else:
        new_temp = initial_temp  # Default to current temperature.
    
    go_to(start_loc)
    say("You should change the thermostat to " + str(new_temp) + " degrees")
"""

