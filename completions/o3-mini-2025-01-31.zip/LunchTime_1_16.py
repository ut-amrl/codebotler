name = "LunchTime"

prompt = "Go to Jill's office and ask her whether she's free to go for lunch tomorrow. If yes, ask her when (give her some reasonable times), and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    
    response = ask("Jill", "Are you free to go for lunch tomorrow?", ["Yes", "No"])
    
    if response == "Yes":
        time_response = ask("Jill", "When would you like to go for lunch tomorrow?", ["11am", "12pm", "1pm"])
        message = "Jill said she's free for lunch tomorrow at " + time_response
    else:
        message = "Jill said she's not free for lunch tomorrow"
    
    go_to(start_loc)
    say(message)
"""

