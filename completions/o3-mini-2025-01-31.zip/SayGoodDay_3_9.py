name = "SayGoodDay"

prompt = "Head to each lab and in case there's a person present, bid them a Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # First, gather all rooms and filter for labs (assumes lab rooms have "lab" in their name)
    all_rooms = get_all_rooms()
    lab_rooms = [room for room in all_rooms if "lab" in room.lower()]
    
    # Visit each lab and if a person is there, bid them a Good Day!
    for lab in lab_rooms:
        go_to(lab)
        if is_in_room("person"):
            say("Good Day!")
"""

