name = "WeatherPoll"

prompt = "Go to the main entrance. When someone shows up, ask them if they feel that it's hot out. Do this until you collect ten people's responses. Come back and tell me which percent of people think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    total_responses = 0
    hot_count = 0
    
    # Continue asking until we've collected 10 responses.
    while total_responses < 10:
        # Check if there's a person present.
        if is_in_room("person"):
            # Ask the person if they feel it's hot out.
            response = ask("person", "Do you feel that it's hot out?", ["Yes", "No"])
            total_responses += 1
            if response == "Yes":
                hot_count += 1
            # Wait a moment before asking the next person.
            time.sleep(1)
        else:
            # Wait a bit for someone to show up.
            time.sleep(1)
            
    # Calculate the percentage of people who think it's hot.
    percentage = (hot_count / total_responses) * 100
    
    # Return to the starting location and announce the result.
    go_to(start_loc)
    say("Percentage of people who think it's hot out: " + str(int(percentage)) + "%")
"""

