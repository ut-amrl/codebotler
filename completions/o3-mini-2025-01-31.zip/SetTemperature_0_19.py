name = "SetTemperature"

prompt = "The thermostat is set to 72 degrees. Go to Arjun's office and ask him if he'd like it to be warmer or colder. Come back and tell me what temperature I should set it to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 512,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Record our starting position
    start_loc = get_current_location()
    
    # Go to Arjun's office to ask his preference
    go_to("Arjun's office")
    response = ask("Arjun", "Would you like it to be warmer or colder?", ["warmer", "colder"])
    
    # The thermostat is currently set to 72 degrees.
    current_temp = 72
    if response == "warmer":
"""

