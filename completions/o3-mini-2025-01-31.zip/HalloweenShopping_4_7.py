name = "HalloweenShopping"

prompt = "Go to every office and skip any office without a person in there. Otherwise, ask the person in the office to decide on how many, from zero to four, of the following they'd like: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy. "

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0

    rooms = get_all_rooms()
    for room in rooms:
        # Process only rooms that are offices.
        if "office" not in room.lower():
            continue

        go_to(room)
        # Check if there is a person in the office.
        if not is_in_room("person"):
            continue
        
        # Guess the occupant's name from the room name (e.g., "Alice's office" → "Alice")
        if "'s" in room:
            person = room.split("'s")[0]
        else:
            person = "the occupant"
        
        # Ask the person about each candy type.
        gummy_resp = ask(person, "How many gummy candies would you like? (choose from 0 to 4)", ["0", "1", "2", "3", "4"])
        caramel_resp = ask(person, "How many caramel candies would you like? (choose from 0 to 4)", ["0", "1", "2", "3", "4"])
        chocolate_resp = ask(person, "How many chocolate candies would you like? (choose from 0 to 4)", ["0", "1", "2", "3", "4"])
        
        # Add the responses after converting them to numbers.
        total_gummy += int(gummy_resp)
        total_caramel += int(caramel_resp)
        total_chocolate += int(chocolate_resp)
    
    # Return to the starting location.
    go_to(start_loc)
    message = ("We need to buy {} gummy, {} caramel, and {} chocolate."
               .format(total_gummy, total_caramel, total_chocolate))
    say(message)
"""

