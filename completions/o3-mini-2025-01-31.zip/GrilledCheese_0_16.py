name = "GrilledCheese"

prompt = "Compile a list of ingredients for grilled cheese. Go to Zarko's office, and ask him which of them he has. Come back and tell me what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Compile the list of ingredients for grilled cheese.
    ingredients = ["bread", "cheese", "butter"]
    missing_ingredients = []
    
    # Save the current location so we can return afterwards.
    start_loc = get_current_location()
    
    # Go to Zarko's office.
    go_to("Zarko's office")
    
    # Ask Zarko for each ingredient if he has it.
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(ingredient)
    
    # Return to the original location.
    go_to(start_loc)
    
    # Announce which ingredients Zarko does not have.
    if missing_ingredients:
        say("Zarko does not have: " + ", ".join(missing_ingredients))
    else:
        say("Zarko has all the ingredients for grilled cheese.")
"""

