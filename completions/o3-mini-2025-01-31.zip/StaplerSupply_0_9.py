name = "StaplerSupply"

prompt = "Check every printer room for a stapler, and come back and tell me which ones do not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    missing_stapler_rooms = []
    # Retrieve all rooms
    all_rooms = get_all_rooms()
    # Check each room that is a printer room
    for room in all_rooms:
        # Assuming printer rooms have "printer room" in their name.
        if "printer room" in room.lower():
            go_to(room)
            # Check if a stapler is in the room
            if not is_in_room("stapler"):
                missing_stapler_rooms.append(room)
    # Go back to the starting location before reporting
    go_to(start_loc)
    # Prepare the message for the rooms without a stapler
    if missing_stapler_rooms:
        message = "The following printer rooms do not have a stapler: " + ", ".join(missing_stapler_rooms)
    else:
        message = "All printer rooms have a stapler."
    say(message)
"""

