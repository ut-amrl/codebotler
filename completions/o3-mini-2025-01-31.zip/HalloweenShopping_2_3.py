name = "HalloweenShopping"

prompt = "Visit every office. If there is a person in the office, ask the person to select 0 to 4 for each of the following categories: gummy, chocolate, or caramel. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return at the end.
    start_loc = get_current_location()
    
    # Get a list of all rooms.
    rooms = get_all_rooms()
    
    total_gummy = 0
    total_chocolate = 0
    total_caramel = 0

    # Iterate over each room and check if it's an office.
    for room in rooms:
        # We consider rooms with "office" in the name as offices.
        if "office" in room:
            go_to(room)
            # Check if there's a person in the office.
            if is_in_room("person"):
                # Ask the person for each candy category (gummy, chocolate, caramel).
                ans_gummy = int(ask("person", "Select a number from 0 to 4 for gummy", ["0", "1", "2", "3", "4"]))
                ans_chocolate = int(ask("person", "Select a number from 0 to 4 for chocolate", ["0", "1", "2", "3", "4"]))
                ans_caramel = int(ask("person", "Select a number from 0 to 4 for caramel", ["0", "1", "2", "3", "4"]))
                
                total_gummy += ans_gummy
                total_chocolate += ans_chocolate
                total_caramel += ans_caramel
    
    # Return to the starting location
    go_to(start_loc)
    
    # Report the total amounts needed.
    say("We need to buy {} gummy, {} chocolate, and {} caramel.".format(total_gummy, total_chocolate, total_caramel))
"""

