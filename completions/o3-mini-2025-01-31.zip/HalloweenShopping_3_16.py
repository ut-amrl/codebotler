name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Initialize totals for each candy type.
    totals = {"gummy": 0, "caramel": 0, "chocolate": 0}
    
    # Retrieve all rooms.
    all_rooms = get_all_rooms()
    
    # Iterate over rooms that are offices.
    for room in all_rooms:
        # Assuming offices have the word "office" in their name.
        if "office" not in room.lower():
            continue
        
        go_to(room)
        
        # Check if there's a person in the office.
        if not is_in_room("person"):
            continue  # Skip this office if no person is present.
        
        # Ask the person how many of each candy they would like.
        for candy in totals.keys():
            # Prepare the question.
            question = "How many {} would you like? (choose from 0, 1, 2, 3, or 4)".format(candy)
            response = ask("person", question, ["0", "1", "2", "3", "4"])
            
            try:
                num = int(response)
            except ValueError:
                num = 0
            totals[candy] += num

    # Return to the requester.
    go_to(start_loc)
    
    # Construct the message with the total amounts.
    message = ("We need to buy {} gummy, {} caramel, and {} chocolate. "
               "Task completed."
               ).format(totals["gummy"], totals["caramel"], totals["chocolate"])
    say(message)
"""

