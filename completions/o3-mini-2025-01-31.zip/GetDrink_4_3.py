name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. If they want a bottle of water, bring it to them from the kitchen. If they want iced tea, bring it to them from the kitchen. If they want lemonade, bring it to them from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby and ask the visitor for their beverage choice.
    go_to("lobby")
    beverage = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["Bottle of Water", "Iced Tea", "Lemonade"])
    
    # Go to the kitchen to get the selected beverage.
    go_to("kitchen")
    # (Assuming that picking up the beverage is implicit when at the kitchen.)
    
    # Bring the beverage to the visitor.
    go_to("lobby")
    say("Here is your " + beverage)
"""

