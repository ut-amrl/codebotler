name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return to it later.
    start_loc = get_current_location()
    
    # Counters for the requested items.
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0
    
    # Get a list of all rooms.
    all_rooms = get_all_rooms()
    
    # Iterate through each room; we only consider offices.
    for room in all_rooms:
        # Check if the room name indicates it's an office.
        if "office" not in room.lower():
            continue
        
        go_to(room)
        
        # Check if a person is present in the office.
        if not is_in_room("person"):
            continue
        
        # Ask the person for the quantity of each item.
        gummy_response = ask("person", "How many gummies would you like?", ["0", "1", "2", "3", "4"])
        caramel_response = ask("person", "How many caramels would you like?", ["0", "1", "2", "3", "4"])
        chocolate_response = ask("person", "How many chocolates would you like?", ["0", "1", "2", "3", "4"])
        
        # Convert the responses to integers and add to the totals.
        total_gummy += int(gummy_response)
        total_caramel += int(caramel_response)
        total_chocolate += int(chocolate_response)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Summarize the totals and report back.
    message = ("We need to buy {} gummies, {} caramels, and {} chocolates."
               .format(total_gummy, total_caramel, total_chocolate))
    say(message)
"""

