name = "StaplerDelivery"

prompt = "Check if there is a stapler in every printer room. For each visited room without a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so the robot can return after deliveries.
    start_loc = get_current_location()
    
    # Get all rooms and filter for rooms that have "printer room" in their names.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "printer room" in room:
            # Go to the printer room.
            go_to(room)
            # Check if a stapler is present.
            if not is_in_room("stapler"):
                # If no stapler is present, deliver one.
                # First, go to the supply room to pick up a stapler.
                go_to("supply room")
                # Then return to the printer room.
                go_to(room)
                # Announce that the stapler has been delivered.
                say("Stapler delivered to " + room)
    
    # Return to the starting location.
    go_to(start_loc)
"""

