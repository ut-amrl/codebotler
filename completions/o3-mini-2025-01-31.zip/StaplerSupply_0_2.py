name = "StaplerSupply"

prompt = "Check every printer room for a stapler, and come back and tell me which ones do not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    missing_stapler_rooms = []
    all_rooms = get_all_rooms()
    
    # Loop through each room and check if it's a printer room
    for room in all_rooms:
        # Assuming printer rooms have "printer" in their name (case insensitive).
        if "printer" in room.lower():
            go_to(room)
            # Check if a stapler is present in the current room
            if not is_in_room("stapler"):
                missing_stapler_rooms.append(room)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Report the results.
    if missing_stapler_rooms:
        message = ("The following printer rooms do not have a stapler: " +
                   ", ".join(missing_stapler_rooms))
    else:
        message = "All printer rooms have a stapler."
        
    say(message)
"""

