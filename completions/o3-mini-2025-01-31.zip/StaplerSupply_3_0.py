name = "StaplerSupply"

prompt = "Check all printer rooms for staplers, and come back and tell me which ones do not have any staplers."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    printer_rooms = [room for room in get_all_rooms() if "printer" in room.lower()]
    rooms_without_staplers = []
    
    for room in printer_rooms:
        go_to(room)
        # Check if a stapler is in the current room
        if not is_in_room("stapler"):
            rooms_without_staplers.append(room)
    
    go_to(start_loc)
    
    if rooms_without_staplers:
        message = "The following printer rooms do not have any staplers: " + ", ".join(rooms_without_staplers)
    else:
        message = "All printer rooms have staplers."
    
    say(message)
"""

