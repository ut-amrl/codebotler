name = "LunchTime"

prompt = "Ask Jill in her office whether she will be free to go for lunch tomorrow. If yes, offer her some reasonable time options to choose from, and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    
    # Go to Jill's office.
    go_to("Jill's office")
    
    # Ask Jill if she will be free for lunch tomorrow.
    response = ask("Jill", "Will you be free to go for lunch tomorrow?", ["Yes", "No"])
    
    # If Jill is free, ask her to choose a lunch time.
    if response == "Yes":
        time_option = ask("Jill", "What time would you prefer for lunch?", ["12:00", "12:30", "1:00"])
        final_message = "Jill said she'll be free for lunch tomorrow at " + time_option + "."
    else:
        final_message = "Jill said she won't be free for lunch tomorrow."
    
    # Return to the original location.
    go_to(start_loc)
    
    # Announce the final message.
    say(final_message)
"""

