name = "StaplerDelivery"

prompt = "Check if there is a stapler in every printer room. For each visited room without a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get a list of all rooms.
    all_rooms = get_all_rooms()
    
    # For each room that is a printer room, check if there is a stapler.
    for room in all_rooms:
        # Check if the room is a printer room by checking its name.
        if "printer room" in room.lower():
            # Go to the printer room.
            go_to(room)
            # Check if a stapler is in the room.
            if not is_in_room("stapler"):
                # If there is no stapler, go to the supply room.
                go_to("supply room")
                # Deliver a stapler from the supply room to the printer room.
                say("Delivering a stapler to " + room)
                # After picking up the stapler, go back to the printer room.
                go_to(room)
"""

