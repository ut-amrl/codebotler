name = "CountSavory"

prompt = "Visit all offices. If anyone is present; ask them to choose from the options of cupcake, ham sandwich, donut, or beef jerky. Let me know how many people selected a savory option when you return."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    savory_count = 0
    all_rooms = get_all_rooms()
    
    # Iterate through rooms and target those that are offices.
    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            if is_in_room("person"):
                response = ask("person", "Please choose one: cupcake, ham sandwich, donut, or beef jerky.", 
                               ["cupcake", "ham sandwich", "donut", "beef jerky"])
                # Count savory selections: ham sandwich and beef jerky.
                if response in ["ham sandwich", "beef jerky"]:
                    savory_count += 1
                    
    go_to(start_loc)
    say("Number of people who selected a savory option: " + str(savory_count))
"""

