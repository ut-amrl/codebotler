name = "LunchTime"

prompt = "Go to Jill's office and ask her whether she's free to go for lunch tomorrow. If yes, ask her when (give her some reasonable times), and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    answer = ask("Jill", "Are you free to go for lunch tomorrow?", ["Yes", "No"])
    if answer == "Yes":
        time_response = ask("Jill", "What time works for you?", ["12:00", "12:30", "1:00"])
        final_message = "Jill is free and suggested " + time_response + " for lunch tomorrow."
    else:
        final_message = "Jill is not free for lunch tomorrow."
    go_to(start_loc)
    say(final_message)
"""

