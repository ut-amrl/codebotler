name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0

    # Get all rooms and iterate over those identified as offices.
    rooms = get_all_rooms()
    for room in rooms:
        if "office" in room.lower():
            go_to(room)
            # Check if there is someone in the office.
            if is_in_room("person"):
                # Ask the person for the number of each treat (0-4).
                caramel = int(ask("the person", "How many caramel would you like? (choose 0-4)", ["0", "1", "2", "3", "4"]))
                chocolate = int(ask("the person", "How many chocolate would you like? (choose 0-4)", ["0", "1", "2", "3", "4"]))
                gummy = int(ask("the person", "How many gummy would you like? (choose 0-4)", ["0", "1", "2", "3", "4"]))
                total_caramel += caramel
                total_chocolate += chocolate
                total_gummy += gummy

    # After checking all offices, return to the original location.
    go_to(start_loc)
    # Report the total number of each treat needed.
    say("We need to buy " + str(total_caramel) + " caramel, " +
        str(total_chocolate) + " chocolate, and " +
        str(total_gummy) + " gummy.")
"""

