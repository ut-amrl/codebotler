name = "CountSavory"

prompt = "Visit all offices. If anyone is present; ask them to choose from the options of cupcake, ham sandwich, donut, or beef jerky. Let me know how many people selected a savory option when you return."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()

    # Counter for the number of people who selected a savory option.
    savory_count = 0

    # Obtain all rooms and filter to process only offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" not in room:
            continue  # skip non-office rooms

        go_to(room)
        
        # Check if anyone is present.
        if is_in_room("person"):
            # Ask the person for their meal choice.
            response = ask("person", 
                           "Please choose one: cupcake, ham sandwich, donut, or beef jerky", 
                           ["cupcake", "ham sandwich", "donut", "beef jerky"])
            
            # Count as savory if the selection is either ham sandwich or beef jerky.
            if response in ["ham sandwich", "beef jerky"]:
                savory_count += 1

    # Return to the starting location.
    go_to(start_loc)
    
    # Inform about how many selected a savory option.
    say("The number of people who selected a savory option is " + str(savory_count))
"""

