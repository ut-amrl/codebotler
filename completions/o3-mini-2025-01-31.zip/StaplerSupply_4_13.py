name = "StaplerSupply"

prompt = "Tell me the name of every printer room that does not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    printer_rooms_without_stapler = []
    
    # Iterate through each room and check for the criteria.
    for room in all_rooms:
        # Consider rooms that have "printer room" in their name (case-insensitive).
        if "printer room" in room.lower():
            go_to(room)
            # Check if the stapler is not present in the room.
            if not is_in_room("stapler"):
                printer_rooms_without_stapler.append(room)
    
    # Return to original location before reporting.
    go_to(start_loc)
    
    # Construct message based on the results.
    if printer_rooms_without_stapler:
        message = "The following printer rooms do not have a stapler: " + ", ".join(printer_rooms_without_stapler)
    else:
        message = "All printer rooms have a stapler."
    
    say(message)
"""

