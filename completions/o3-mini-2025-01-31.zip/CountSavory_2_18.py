name = "CountSavory"

prompt = "Go through each office; if someone is there, ask about their preference among cupcake, donut, beef jerky, or ham sandwich. Report the number of individuals who opted for a savory item after returning."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location to come back later
    start_loc = get_current_location()
    savory_count = 0
    all_rooms = get_all_rooms()
    
    # Loop through each room and consider those that are offices
    for room in all_rooms:
        if "office" not in room.lower():
            continue  # Skip non-office rooms
        
        go_to(room)
        
        # Check if someone is present in this office
        if is_in_room("person"):
            # Ask the person about their preference
            response = ask("person", "What do you prefer: cupcake, donut, beef jerky, or ham sandwich?", 
                           ["cupcake", "donut", "beef jerky", "ham sandwich"])
            
            # Count if the choice is one of the savory items
            if response in ["beef jerky", "ham sandwich"]:
                savory_count += 1
    
    # Return to the original starting location
    go_to(start_loc)
    
    # Report the number of individuals who selected a savory option
    say("Number of individuals who opted for a savory item: " + str(savory_count))
"""

