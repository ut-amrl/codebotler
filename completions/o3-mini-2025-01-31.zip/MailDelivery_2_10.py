name = "MailDelivery"

prompt = "Grab a mail bin from the mail room. Go to every office, and ask if they have any mail to deliver. Ask them to put all mail in the bin if there is any. Put the mail bin back in the mail room and report which offices the mail is from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location for later (if needed)
    start_loc = get_current_location()
    
    # Step 1: Grab a mail bin from the mail room.
    go_to("mail room")
    say("Grabbing the mail bin.")
    
    # Step 2: For every office, ask if there's any mail to deliver.
    offices_with_mail = []
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # We'll assume offices have "office" in their name.
        if "office" in room.lower():
            go_to(room)
            response = ask(room, "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                # Ask them to put all mail in the bin.
                ask(room, "Please put all the mail in the bin.", ["Done"])
                offices_with_mail.append(room)
    
    # Step 3: Return the mail bin back to the mail room.
    go_to("mail room")
    say("Placing the mail bin back.")
    
    # Step 4: Report which offices the mail is from.
    if offices_with_mail:
        message = "Mail received from: " + ", ".join(offices_with_mail)
    else:
        message = "No offices reported any mail."
    say(message)
"""

