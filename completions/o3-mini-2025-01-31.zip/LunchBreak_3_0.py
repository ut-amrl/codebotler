name = "LunchBreak"

prompt = "Ask Alice and Bob if they are up for lunch. If they say yes, tell them that we will meet in the lobby in five minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joiners = []

    # Ask each person if they are up for lunch
    for person in ["Alice", "Bob"]:
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            joiners.append(person)
            say("We will meet in the lobby in five minutes")

    # Return to the original location
    go_to(start_loc)

    # Report who is joining for lunch
    if joiners:
        message = ", ".join(joiners) + " are joining for lunch"
    else:
        message = "No one is joining for lunch"
    say(message)
"""

