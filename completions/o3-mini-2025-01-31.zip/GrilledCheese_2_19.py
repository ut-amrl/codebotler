name = "GrilledCheese"

prompt = "Put together a compilation of grilled cheese ingredients. Head to Zarko's office, inquire about his available ingredients, and then update me on what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the grilled cheese ingredients we are looking for.
    required_ingredients = ["bread", "cheese", "butter"]
    missing_ingredients = []

    # Remember the starting location.
    start_loc = get_current_location()

    # Go to Zarko's office.
    go_to("Zarko's office")

    # For each ingredient, ask Zarko if he has it.
    for ingredient in required_ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(ingredient)

    # Go back to the original location.
    go_to(start_loc)
    
    # Update on which ingredients Zarko does not have.
    if missing_ingredients:
        say("Zarko does not have: " + ", ".join(missing_ingredients))
    else:
        say("Zarko has all the grilled cheese ingredients.")
"""

