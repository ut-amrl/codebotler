name = "StaplerDelivery"

prompt = "Check every printer room for a stapler, and deliver a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Loop through all rooms to find printer rooms.
    rooms = get_all_rooms()
    for room in rooms:
        # Check if the room is a printer room (case-insensitive check)
        if "printer" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                # If the printer room lacks a stapler, bring one from the supply room.
                go_to("supply room")
                # Assume robot picks up a stapler here.
                go_to(room)
                say("A stapler has been delivered to " + room)
"""

