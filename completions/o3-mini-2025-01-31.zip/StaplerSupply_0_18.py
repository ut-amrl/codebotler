name = "StaplerSupply"

prompt = "Check every printer room for a stapler, and come back and tell me which ones do not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    missing_stapler_rooms = []
    
    # Iterate through all rooms and check if it's a printer room.
    for room in all_rooms:
        if "printer" in room.lower():  # Considering room names that contain "printer"
            go_to(room)
            if not is_in_room("stapler"):
                missing_stapler_rooms.append(room)
    
    # Return to starting location.
    go_to(start_loc)
    
    # Construct the message.
    if missing_stapler_rooms:
        message = "The following printer rooms do not have a stapler: " + ", ".join(missing_stapler_rooms)
    else:
        message = "All printer rooms have a stapler."
    
    say(message)
"""

