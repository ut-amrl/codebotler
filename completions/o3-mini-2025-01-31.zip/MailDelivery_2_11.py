name = "MailDelivery"

prompt = "Grab a mail bin from the mail room. Go to every office, and ask if they have any mail to deliver. Ask them to put all mail in the bin if there is any. Put the mail bin back in the mail room and report which offices the mail is from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the mail room and grab the mail bin.
    go_to("mail room")
    # (Assume the mail bin is grabbed now.)
    
    # List to store offices with mail.
    offices_with_mail = []
    
    # Retrieve a list of all rooms.
    all_rooms = get_all_rooms()
"""

