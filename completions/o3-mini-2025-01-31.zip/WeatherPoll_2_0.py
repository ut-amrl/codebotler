name = "WeatherPoll"

prompt = "Go wait for someone at the main entrance. Ask them if they feel it is hot out, then wait for the next person and ask the same question. Do this until you have ten responses, then come back and report the percentage of people who think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    
    responses = []
    import time
    while len(responses) < 10:
        # Wait until someone is in the room.
        if is_in_room("person"):
            response = ask("person", "Do you think it is hot out?", ["Yes", "No"])
            responses.append(response)
            # Wait a moment after getting a response to allow for the next person.
            time.sleep(1)
        else:
            time.sleep(1)
    
    yes_count = sum(1 for resp in responses if resp == "Yes")
    percent_yes = (yes_count / 10) * 100
    go_to(start_loc)
    say("Percentage of people who think it's hot out: " + str(percent_yes) + "%")
"""

