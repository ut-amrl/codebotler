name = "WeatherPoll"

prompt = "Go to the main entrance. If there is no one there, wait for someone. Ask them if they feel it is hot out. Ask 10 people this same question until you have 10 replies. Finally, come back and tell me the percentage of people that think it's hot outside."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    # Wait until someone is present at the main entrance.
    while not is_in_room("person"):
        time.sleep(1)
    
    responses = []
    # Ask 10 people the question "Do you feel it is hot out?" until we have 10 replies.
    while len(responses) < 10:
        # Wait for a person to be available if currently none.
        while not is_in_room("person"):
            time.sleep(1)
        # Ask the person and expect a "Yes" or "No" response.
        response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
        responses.append(response)
    
    # Calculate the percentage of people that think it's hot outside.
    yes_count = responses.count("Yes")
    percentage = (yes_count / 10.0) * 100
    
    # Return to the starting location and report the result.
    go_to(start_loc)
    say(f"{percentage}% of people think it's hot outside")
"""

