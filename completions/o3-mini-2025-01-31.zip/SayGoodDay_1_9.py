name = "SayGoodDay"

prompt = "Visit each lab and if someone is present, greet them with a pleasant Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get a list of all rooms.
    all_rooms = get_all_rooms()
    
    # Filter only rooms that are labs (case insensitive matching)
    lab_rooms = [room for room in all_rooms if "lab" in room.lower()]
    
    # Visit each lab
    for lab in lab_rooms:
        go_to(lab)
        
        # Check if someone is present in the lab
        if is_in_room("person"):
            say("Good Day!")
"""

