name = "GrilledCheese"

prompt = "Compile a list of ingredients for grilled cheese. Go to Zarko's office, and ask him which of them he has. Come back and tell me what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Compiled list of ingredients for a grilled cheese sandwich.
    ingredients = ["bread", "cheese", "butter"]
    start_loc = get_current_location()
    
    # Go to Zarko's office to ask him which ingredients he has.
    go_to("Zarko's office")
    missing_ingredients = []
    for item in ingredients:
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(item)
    
    # Return to the starting location and report what he does not have.
    go_to(start_loc)
    if missing_ingredients:
        missing_str = ", ".join(missing_ingredients)
        say("Zarko does not have: " + missing_str)
    else:
        say("Zarko has all the ingredients for grilled cheese.")
"""

