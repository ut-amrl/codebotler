name = "LunchBreak"

prompt = "Ask Alice in her office if she is up for lunch, and if yes, tell her that we will meet in the lobby in 5 minutes. Do the same for Bob. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location to come back later.
    start_loc = get_current_location()
    joining = []
    
    # List of persons and the locations of their offices.
    persons = [("Alice", "Alice's office"), ("Bob", "Bob's office")]
    
    for person, office in persons:
        go_to(office)
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        # If the person agrees, notify them about the meeting.
        if response == "Yes":
            say("We will meet in the lobby in 5 minutes.")
            joining.append(person)
    
    # Return to the starting location and announce who is joining.
    go_to(start_loc)
    if joining:
        say(", ".join(joining) + " are joining for lunch.")
    else:
        say("No one is joining for lunch.")
"""

