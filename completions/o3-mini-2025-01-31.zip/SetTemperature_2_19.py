name = "SetTemperature"

prompt = "The thermostat is currently set to 72 degrees. Go ask if Arjun thinks his office should be colder or warmer. Come back and tell me what temperature in degrees I should change the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Record our starting location.
    start_loc = get_current_location()
    
    # Go to Arjun's office and ask his opinion.
    go_to("Arjun's office")
    response = ask("Arjun", "Should your office be colder or warmer?", ["Colder", "Warmer"])
    
    # Based on Arjun's answer, calculate a new thermostat temperature.
    # The thermostat is currently 72 degrees.
    # If he wants colder, lower the temperature; if warmer, increase it.
    if response == "Colder":
        new_temp = 68  # example temperature for colder
    else:
        new_temp = 76  # example temperature for warmer
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Tell the user what temperature to set the thermostat to.
    say("Set the thermostat to " + str(new_temp) + " degrees.")
"""

