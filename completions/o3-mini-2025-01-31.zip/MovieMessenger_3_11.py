name = "MovieMessenger"

prompt = "Go to Sally's office and ask her if she wants to go to the cinema with Mark. Tell Mark what Sally said, and if yes, ask Mark whether he wants to leave at 4PM, 5PM, or 6PM, and then go back to Sally's office and tell her what Mark said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to Sally's office and ask her about going to the cinema with Mark.
    go_to("Sally's office")
    sally_response = ask("Sally", "Do you want to go to the cinema with Mark?", ["Yes", "No"])
    
    # Go to Mark's office to inform him of Sally's response.
    go_to("Mark's office")
    say("Sally said: " + sally_response)
    
    # If Sally said yes, ask Mark for his preferred departure time.
    mark_response = ""
    if sally_response == "Yes":
        mark_response = ask("Mark", "What time do you want to leave?", ["4PM", "5PM", "6PM"])
    
    # Return to Sally's office and inform her of Mark's answer.
    go_to("Sally's office")
    if sally_response == "Yes":
        say("Mark said: " + mark_response)
    else:
        say("Mark was informed that you declined the cinema invitation.")
"""

