name = "SetTemperature"

prompt = "Go to Arjun's office and ask him if he would like his office to be warmer or colder. The thermostat says the temperature in the office is currently 72 degrees. Come back and tell me what temperature I should reset it to based on Arjun's preferences."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location.
    start_loc = get_current_location()

    # Go to Arjun's office.
    go_to("Arjun's office")
    
    # Ask Arjun whether he would like his office to be warmer or colder.
    response = ask("Arjun", "Would you like your office to be warmer or colder?", ["warmer", "colder"])
    
    # The thermostat currently reads 72 degrees.
    current_temperature = 72
    
    # Adjust the temperature based on his preference.
    # Here we choose to adjust the temperature by 2 degrees.
    if response == "warmer":
        new_temperature = current_temperature + 2
    else:
        new_temperature = current_temperature - 2
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Tell the requester the new temperature setting.
    say("Based on Arjun's preference, the thermostat should be reset to " + str(new_temperature) + " degrees.")
"""

