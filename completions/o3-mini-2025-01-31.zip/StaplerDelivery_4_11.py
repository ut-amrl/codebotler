name = "StaplerDelivery"

prompt = "Check if every printer room has a stapler. If not, put a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    
    # Iterate through all rooms, and identify printer rooms by checking if their name includes "printer room"
    for room in rooms:
        if "printer room" in room.lower():
            go_to(room)
            # Check if the printer room has a stapler
            if not is_in_room("stapler"):
                # If not, go to the supply room to get a stapler
                go_to("supply room")
                say("Picked up a stapler")
                # Bring the stapler to the printer room
                go_to(room)
                say("Placed a stapler in " + room)
                
    go_to(start_loc)
    say("Task Completed")
"""

