name = "ElevatorTour"

prompt = "Go to the elevator and wait for someone to arrive. Inquire if they are here for the tour, and if they say yes, welcome them to the university and tell them to follow you. Then take them to the main conference room. If they say no, wait for someone else. When you get to the conference room, announce your arrival at the conference room and wish them an enjoyable visit."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the elevator and wait for someone to arrive.
    go_to("elevator")
    
    # Wait until someone is detected in the elevator area.
    while True:
        if is_in_room("person"):
            # Ask the arrived person if they are here for the tour.
            response = ask("person", "Are you here for the tour?", ["Yes", "No"])
            if response == "Yes":
                # If they are here for the tour, welcome them and ask them to follow you.
                say("Welcome to the university! Please follow me.")
                break
        # Optionally wait a bit before checking again.
        # time.sleep(1)  # Uncomment if waiting a short period is needed.
    
    # Take the person to the main conference room.
    go_to("main conference room")
    
    # Upon arriving, announce the arrival and wish them an enjoyable visit.
    say("We have arrived at the conference room. Enjoy your visit!")
"""

