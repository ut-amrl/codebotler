name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a beef jerky, cupcake, ham sandwich, or donut. Come back and tell me how many people preferred a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return later.
    start_loc = get_current_location()
    savory_count = 0
    # Define the options to offer.
    options = ["beef jerky", "cupcake", "ham sandwich", "donut"]
    # Identify offices by filtering rooms containing "office".
    all_rooms = get_all_rooms()
    office_rooms = [room for room in all_rooms if "office" in room.lower()]
    
    # Go to every office and ask if someone is there.
    for office in office_rooms:
        go_to(office)
        if is_in_room("person"):
            response = ask("person", "Would you like a beef jerky, cupcake, ham sandwich, or donut?", options)
            if response in ["beef jerky", "ham sandwich"]:
                savory_count += 1
                
    # Return to the starting location and report the number.
    go_to(start_loc)
    say(f"{savory_count} people preferred a savory option.")
"""

