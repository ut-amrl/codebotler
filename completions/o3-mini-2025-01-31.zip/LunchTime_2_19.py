name = "LunchTime"

prompt = "Visit Jill's office and ask her if she would like to go for lunch tomorrow. If yes, ask her when (offer some reasonable lunch time options). Let me know what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    go_to("Jill's office")
    decision = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    if decision == "Yes":
        time_choice = ask("Jill", "When would you like to go for lunch tomorrow?", ["12:00", "12:30", "1:00"])
        message = "Jill said yes and she would like to have lunch at " + time_choice + "."
    else:
        message = "Jill said no to going for lunch tomorrow."
    say(message)
"""

