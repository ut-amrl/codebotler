name = "StaplerDelivery"

prompt = "Go to every printer room and check if there is a stapler. For each visited room that does not have a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Check if the room is a printer room (case-insensitive match).
        if "printer" in room.lower():
            go_to(room)
            # Check if there is a stapler in the printer room.
            if not is_in_room("stapler"):
                # Go to the supply room to get a stapler.
                go_to("supply room")
                say("Picked up a stapler from the supply room.")
                # Deliver the stapler to the printer room.
                go_to(room)
                say("Stapler delivered to " + room)
    # Return to the starting location.
    go_to(start_loc)
"""

