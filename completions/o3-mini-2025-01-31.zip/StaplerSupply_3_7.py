name = "StaplerSupply"

prompt = "Check all printer rooms for staplers, and come back and tell me which ones do not have any staplers."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    missing_staplers = []
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # We assume printer rooms have "printer" in their room name (case insensitive)
        if "printer" in room.lower():
            go_to(room)
            # Check if there's at least one stapler in the room.
            if not is_in_room("stapler"):
                missing_staplers.append(room)
    go_to(start_loc)
    if missing_staplers:
        message = "The following printer rooms do not have staplers: " + ", ".join(missing_staplers)
    else:
        message = "All printer rooms have staplers."
    say(message)
"""

