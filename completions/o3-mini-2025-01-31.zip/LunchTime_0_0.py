name = "LunchTime"

prompt = "Go to Jill's office and ask her if she'd like to go for lunch tomorrow. If yes, ask her at what time (offer her some reasonable options). Come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Go to Jill's office.
    go_to("Jill's office")
    
    # Ask if she would like to go for lunch tomorrow.
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    
    # If she says "Yes", ask at what time.
    if response == "Yes":
        time_response = ask("Jill", "At what time would you like to have lunch? Please choose one:", 
                            ["11:00 AM", "12:00 PM", "1:00 PM"])
        final_message = "Jill said Yes, she would like to go for lunch at " + time_response + "."
    else:
        final_message = "Jill said No."
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Tell the user what Jill said.
    say(final_message)
"""

