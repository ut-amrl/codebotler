name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0

    all_rooms = get_all_rooms()
    
    for room in all_rooms:
        # Process only offices (assuming offices contain "office" in their name)
        if "office" not in room.lower():
            continue

        go_to(room)
        if is_in_room("person"):
            # Ask about caramel
            resp = ask("person", "How many caramel would you like? (choose from 0-4)", ["0", "1", "2", "3", "4"])
            total_caramel += int(resp)
            # Ask about chocolate
            resp = ask("person", "How many chocolate would you like? (choose from 0-4)", ["0", "1", "2", "3", "4"])
            total_chocolate += int(resp)
            # Ask about gummy
            resp = ask("person", "How many gummy would you like? (choose from 0-4)", ["0", "1", "2", "3", "4"])
            total_gummy += int(resp)

    go_to(start_loc)
    message = ("We need to buy {} caramel, {} chocolate, "
               "and {} gummy.").format(total_caramel, total_chocolate, total_gummy)
    say(message)
"""

