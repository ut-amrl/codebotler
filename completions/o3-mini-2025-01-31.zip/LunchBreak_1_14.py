name = "LunchBreak"

prompt = "Ask Alice in her office if she is up for lunch, and if yes, tell her that we will meet in the lobby in 5 minutes. Do the same for Bob. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    participants = []
    
    for person in ["Alice", "Bob"]:
        # Go to the person's office
        go_to(f"{person}'s office")
        # Ask if they are up for lunch
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            # Confirm meeting details
            say("We will meet in the lobby in 5 minutes")
            participants.append(person)
    
    # Return to the starting location
    go_to(start_loc)
    
    # Report which people are joining for lunch
    if participants:
        participants_list = ", ".join(participants)
        say("Joining for lunch: " + participants_list)
    else:
        say("No one is joining for lunch.")
"""

