name = "CountSavory"

prompt = "Go through each office; if someone is there, ask about their preference among cupcake, donut, beef jerky, or ham sandwich. Report the number of individuals who opted for a savory item after returning."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    savory_choices = ["beef jerky", "ham sandwich"]
    savory_count = 0

    # Filter rooms that are offices (assuming the room name contains "office")
    offices = [room for room in all_rooms if "office" in room.lower()]

    for office in offices:
        go_to(office)
        # Check if someone is in the office; assuming "person" represents a person in the room.
        if is_in_room("person"):
            response = ask("occupant", "What is your preference? (cupcake, donut, beef jerky, ham sandwich)", 
                           ["cupcake", "donut", "beef jerky", "ham sandwich"])
            if response in savory_choices:
                savory_count += 1

    go_to(start_loc)
    say("The number of individuals who opted for a savory item is " + str(savory_count))
"""

