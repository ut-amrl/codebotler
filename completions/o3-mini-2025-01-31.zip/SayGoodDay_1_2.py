name = "SayGoodDay"

prompt = "Visit each lab and if someone is present, greet them with a pleasant Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get the list of all rooms
    all_rooms = get_all_rooms()
    # Filter rooms that are labs (assuming "lab" is in the room name)
    labs = [room for room in all_rooms if "lab" in room.lower()]
    
    # Visit each lab
    for lab in labs:
        go_to(lab)
        # If someone is present in the lab, greet them
        if is_in_room("person"):
            say("Good Day!")
"""

