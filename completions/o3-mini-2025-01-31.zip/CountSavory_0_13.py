name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a cupcake, ham sandwich, donut, or beef jerky. Come back and tell me how many people chose a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location of the robot.
    start_loc = get_current_location()
    
    # Get all rooms.
    all_rooms = get_all_rooms()
    
    # Initialize counter for savory options (ham sandwich and beef jerky).
    savory_count = 0
    
    # Loop through all rooms.
    for room in all_rooms:
        # Check if the room is an office.
        if "office" in room.lower():
            go_to(room)
            # If there is someone present in the office.
            if is_in_room("person"):
                # Ask the person about their preferred snack.
                response = ask("person", 
                               "Would you like a cupcake, ham sandwich, donut, or beef jerky?", 
                               ["cupcake", "ham sandwich", "donut", "beef jerky"])
                # If they chose a savory option, count it.
                if response in ["ham sandwich", "beef jerky"]:
                    savory_count += 1
                    
    # Return to the starting location.
    go_to(start_loc)
    
    # Announce the number of people who chose a savory option.
    say("The number of people who chose a savory option is " + str(savory_count))
"""

