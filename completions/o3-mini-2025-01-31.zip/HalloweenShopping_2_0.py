name = "HalloweenShopping"

prompt = "Visit every office. If there is a person in the office, ask the person to select 0 to 4 for each of the following categories: gummy, chocolate, or caramel. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    total_gummy = 0
    total_chocolate = 0
    total_caramel = 0

    # Get all rooms and visit only those that are offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            # Check if there's a person in the office.
            if is_in_room("person"):
                gummy_resp = ask("person", "Select a number (0-4) for gummy:", ["0", "1", "2", "3", "4"])
                chocolate_resp = ask("person", "Select a number (0-4) for chocolate:", ["0", "1", "2", "3", "4"])
                caramel_resp = ask("person", "Select a number (0-4) for caramel:", ["0", "1", "2", "3", "4"])
                total_gummy += int(gummy_resp)
                total_chocolate += int(chocolate_resp)
                total_caramel += int(caramel_resp)
                
    go_to(start_loc)
    say("We need to buy {} gummy, {} chocolate, and {} caramel.".format(total_gummy,
          total_chocolate, total_caramel))
"""

