name = "LunchTime"

prompt = "Go to Jill's office and ask her whether she's free to go for lunch tomorrow. If yes, ask her when (give her some reasonable times), and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    response = ask("Jill", "Are you free to go for lunch tomorrow?", ["Yes", "No"])
    
    # Initialize the message with Jill's response
    message = "Jill's answer: " + response
    if response == "Yes":
        time_response = ask("Jill", "When are you free to go for lunch tomorrow?", ["12 PM", "1 PM", "2 PM"])
        message += " and she is free at " + time_response
    go_to(start_loc)
    say(message)
"""

