name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save starting location so we can return later.
    start_loc = get_current_location()
    
    # Counters for the candy items.
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0
    
    # Get the list of all rooms.
    all_rooms = get_all_rooms()
    
    # Iterate over each room, considering only rooms that are offices.
    for room in all_rooms:
        # Check if the word "office" is in the room name (case insensitive).
        if "office" not in room.lower():
            continue
        
        # Go to the office.
        go_to(room)
        
        # Check if there is a person present. If not, skip this office.
        if not is_in_room("person"):
            continue
        
        # Ask the person in the office for how many of each candy they'd like.
        # We assume the answer is one of the strings "0", "1", "2", "3", or "4".
        response_gummy = ask("person", "How many gummies would you like?", ["0", "1", "2", "3", "4"])
        response_caramel = ask("person", "How many caramels would you like?", ["0", "1", "2", "3", "4"])
        response_chocolate = ask("person", "How many chocolates would you like?", ["0", "1", "2", "3", "4"])
        
        # Convert responses to integers and add to the totals.
        total_gummy += int(response_gummy)
        total_caramel += int(response_caramel)
        total_chocolate += int(response_chocolate)
    
    # After visiting all offices, return to the starting location.
    go_to(start_loc)
    
    # Say the final summary message.
    say("We need to buy {} gummies, {} caramels, and {} chocolates.".format(total_gummy, total_caramel, total_chocolate))
"""

