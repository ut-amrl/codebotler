name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. If they want a bottle of water, bring it to them from the kitchen. If they want iced tea, bring it to them from the kitchen. If they want lemonade, bring it to them from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby and ask the visitor for their drink preference.
    go_to("lobby")
    response = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["Bottle of water", "Iced tea", "Lemonade"])
    
    # Regardless of the choice, fetch the drink from the kitchen.
    go_to("kitchen")
    
    # Then return to the lobby to deliver the drink.
    go_to("lobby")
    say("Here is your " + response)
"""

