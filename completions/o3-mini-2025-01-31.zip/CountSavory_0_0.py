name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a cupcake, ham sandwich, donut, or beef jerky. Come back and tell me how many people chose a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    savory_count = 0

    # Get all rooms and filter for offices based on the word "office"
    all_rooms = get_all_rooms()
    offices = [room for room in all_rooms if "office" in room.lower()]

    # Visit each office and ask the person there if needed.
    for office in offices:
        go_to(office)
        if is_in_room("person"):
            response = ask("person",
                           "Would you like a cupcake, ham sandwich, donut, or beef jerky?",
                           ["cupcake", "ham sandwich", "donut", "beef jerky"])
            # Count savory selections: ham sandwich and beef jerky are savory options.
            if response in ["ham sandwich", "beef jerky"]:
                savory_count += 1

    # Return to starting location and announce the result.
    go_to(start_loc)
    say("The number of people who chose a savory option is " + str(savory_count))
"""

