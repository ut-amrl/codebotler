name = "StaplerDelivery"

prompt = "Make sure there is a stapler in each printer room. Otherwise, bring a stapler from the supply room to each printer room that currently lacks one."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    
    # Iterate through all rooms and check for printer rooms.
    for room in all_rooms:
        # Assuming a printer room's name contains the word "printer" (case-insensitive).
        if "printer" in room.lower():
            go_to(room)
            # Check if a stapler is present in the current printer room.
            if not is_in_room("stapler"):
                # If no stapler, bring one from the supply room.
                go_to("supply room")
                say("Picking up a stapler for " + room)
                go_to(room)
                say("Stapler delivered to " + room)
            else:
                say("Stapler is already present in " + room)
    
    go_to(start_loc)
"""

