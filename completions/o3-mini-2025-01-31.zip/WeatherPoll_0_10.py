name = "WeatherPoll"

prompt = "Go to the main entrance, and wait for someone to show up. Ask them if they feel it is hot out. Repeat this until you have 10 responses, and then come back and tell me what percent of people think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    
    responses = 0
    yes_count = 0

    # Loop until we have 10 responses
    while responses < 10:
        # Wait until someone shows up
        if is_in_room("person"):
            # Ask the person if they think it's hot out.
            answer = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
            responses += 1
            if answer == "Yes":
                yes_count += 1
        # Optionally, add a small delay here if required to avoid busy-waiting.
        # For example: time.sleep(1)  (assuming time has been imported)

    # Calculate the percentage of people who think it's hot out.
    percent_hot = (yes_count / 10) * 100

    # Return to start location and report the result.
    go_to(start_loc)
    say("Out of 10 responses, " + str(percent_hot) + " percent of people think it's hot out.")
"""

