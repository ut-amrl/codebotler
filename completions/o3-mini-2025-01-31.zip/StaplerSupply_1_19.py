name = "StaplerSupply"

prompt = "Go to every printer room and check to see if there is a stapler. Come back and tell me which printer rooms do not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    rooms_without_stapler = []
    
    # Get the list of all rooms
    all_rooms = get_all_rooms()
    
    # Iterate through each room and check if it's a printer room (case-insensitive search).
    for room in all_rooms:
        if "printer" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                rooms_without_stapler.append(room)
    
    # Return to the starting location.
    go_to(start_location)
    
    # Construct the message.
    if rooms_without_stapler:
        message = "The following printer rooms do not have a stapler: " + ", ".join(rooms_without_stapler)
    else:
        message = "All printer rooms have a stapler."
    
    say(message)
"""

