name = "ElevatorTour"

prompt = "Go to the elevator, and wait until someone shows up. Ask them if they are here for the tour. If yes, welcome them to the university, tell them to follow you, and take them to the main conference room. If not, wait for the next person. When you get to the conference room, say you have arrived at the conference room and wish them an enjoyable visit."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the elevator and wait for someone to show up.
    go_to("elevator")
    
    while True:
        # Wait until a person is detected in the elevator.
        if is_in_room("person"):
            # Ask the person if they are here for the tour.
            response = ask("person", "Are you here for the tour?", ["Yes", "No"])
            if response == "Yes":
                # If yes, welcome them and tell them to follow.
                say("Welcome to the university. Please follow me.")
                # Take them to the main conference room.
                go_to("main conference room")
                # Upon arriving in the conference room, announce arrival.
                say("We have arrived at the conference room. Enjoy your visit!")
                break
            # If the answer is "No", continue waiting for the next person.
        # Adding a short wait before checking again.
        time.sleep(1)
"""

