name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Initialize counters for each candy type.
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0

    # Get all rooms and iterate over those that are offices.
    for room in get_all_rooms():
        if "office" not in room.lower():
            continue  # Skip non-office rooms.
        
        go_to(room)
        
        # Check if there is a person in the office.
        if not is_in_room("person"):
            continue  # Skip if there's no person.
        
        # Ask the person in the office how many of each type they want.
        response_gummy = ask("person", "How many gummies would you like?", ["0", "1", "2", "3", "4"])
        response_caramel = ask("person", "How many caramels would you like?", ["0", "1", "2", "3", "4"])
        response_chocolate = ask("person", "How many chocolates would you like?", ["0", "1", "2", "3", "4"])
        
        # Convert responses from string to integer and add them to the totals.
        total_gummy += int(response_gummy)
        total_caramel += int(response_caramel)
        total_chocolate += int(response_chocolate)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Construct and say the result message.
    result_message = ("We need to buy " + str(total_gummy) + " gummies, " +
                      str(total_caramel) + " caramels, and " +
                      str(total_chocolate) + " chocolates.")
    say(result_message)
"""

