name = "HalloweenList"

prompt = "Go to every office, and if there is anyone there, ask if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    # Counters for each treat request
    count = {"chocolate": 0, "caramel": 0, "gummy": 0}

    all_rooms = get_all_rooms()
    # Iterate through all rooms, checking only those with "office" in the name.
    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            # Check if there is someone in the room.
            if is_in_room("person"):
                response = ask("person", "Would you like a chocolate, caramel, or gummy?", 
                               ["chocolate", "caramel", "gummy"])
                if response in count:
                    count[response] += 1

    # Go back to the starting location
    go_to(start_loc)
    
    # Construct a message summarizing the orders.
    message = ("Orders: " +
               "chocolate: " + str(count["chocolate"]) + ", " +
               "caramel: " + str(count["caramel"]) + ", " +
               "gummy: " + str(count["gummy"]))
    say(message)
"""

