name = "HalloweenList"

prompt = "Find every occupied office and ask their occupants whether they would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    # Counters for each candy type
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0

    # Process each room that has "office" in its name
    for room in all_rooms:
        if "office" in room:
            go_to(room)
            # Check if the office is occupied
            if is_in_room("person"):
                # Ask the occupant for their choice
                response = ask("occupant", "Would you like a chocolate, caramel, or gummy?", 
                               ["chocolate", "caramel", "gummy"])
                if response == "chocolate":
                    chocolate_count += 1
                elif response == "caramel":
                    caramel_count += 1
                elif response == "gummy":
                    gummy_count += 1

    # Report the totals back to you
    message = ("We need to buy {} chocolates, {} caramels, and {} gummies."
               .format(chocolate_count, caramel_count, gummy_count))
    say(message)
    go_to(start_loc)
"""

