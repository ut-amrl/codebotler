name = "WeatherPoll"

prompt = "Go to the main entrance. If there is no one there, wait for someone. Ask them if they feel it is hot out. Ask 10 people this same question until you have 10 replies. Finally, come back and tell me the percentage of people that think it's hot outside."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    # Wait until at least one person arrives at the main entrance.
    while not is_in_room("person"):
        time.sleep(1)
    
    responses_count = 0
    yes_count = 0
    
    # Ask 10 people whether they feel it is hot out.
    while responses_count < 10:
        # Wait until there is at least one person present.
        while not is_in_room("person"):
            time.sleep(1)
        response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
        responses_count += 1
        if response == "Yes":
            yes_count += 1
    
    # Calculate the percentage of people that think it's hot outside.
    percentage = (yes_count / responses_count) * 100
    
    # Return to the starting location and announce the result.
    go_to(start_loc)
    say(str(percentage) + "% of people think it's hot outside.")
"""

