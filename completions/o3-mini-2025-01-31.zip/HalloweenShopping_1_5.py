name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location to return later.
    start_loc = get_current_location()
    
    # Initialize totals for each candy.
    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0
    
    # Get a list of all rooms.
    all_rooms = get_all_rooms()
    
    # Loop through each room and check if it's an office.
    # We'll assume office rooms have the substring "office".
    for room in all_rooms:
        if "office" not in room.lower():
            continue

        # Go to the office.
        go_to(room)
        
        # Check if there's anyone in the room.
        # We'll assume that if there is any person, is_in_room("person") returns True.
        if not is_in_room("person"):
            continue
        
        # Try to determine the name of the person in the office.
        # If the room name is like "Alice's office", extract "Alice". Otherwise use "there".
        person_name = "there"
        if "'s office" in room:
            person_name = room.split("'s office")[0]
        
        # Ask the person how many of each item they'd like.
        # Options for each are from "0" to "4".
        options = ["0", "1", "2", "3
"""

