name = "HalloweenList"

prompt = "Check with every occupied office to see if the occupant would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the initial location to return later.
    start_loc = get_current_location()
    # Initialize counters for each candy type.
    candy_counts = {"chocolate": 0, "caramel": 0, "gummy": 0}
    
    # Get a list of all rooms.
    rooms = get_all_rooms()
    
    # Iterate through each room and check only offices.
    for room in rooms:
        if "office" not in room:
            continue
        
        go_to(room)
        
        # Check if the office is occupied (a person is present).
        if is_in_room("person"):
            # Determine the occupant's name from the room's name if possible.
            if "'s office"
"""

