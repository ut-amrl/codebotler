name = "StaplerSupply"

prompt = "Go find all printer rooms that do not have a stapler. Come back and tell me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    printer_rooms_without_stapler = []
    
    # Identify printer rooms from the list of all rooms
    for room in rooms:
        if "printer" in room.lower():
            # Go to the printer room
            go_to(room)
            # Check if there is a stapler in the room
            if not is_in_room("stapler"):
                printer_rooms_without_stapler.append(room)
    
    # Return to the starting location
    go_to(start_loc)
    
    # Report the findings
    if printer_rooms_without_stapler:
        message = "The following printer rooms do not have a stapler: " + ", ".join(printer_rooms_without_stapler)
    else:
        message = "All printer rooms have a stapler."
        
    say(message)
"""

