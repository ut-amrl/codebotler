name = "HalloweenList"

prompt = "Go to every office, and if there is anyone there, ask if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location so we can come back later.
    start_loc = get_current_location()
    
    # Counters for each candy type.
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0
    
    # Get all rooms and iterate over them to find offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Consider a room an office if its name contains "office" (case-insensitive).
        if "office" not in room.lower():
            continue
        
        # Go to the office.
        go_to(room)
        
        # Check if there is anyone there.
        if is_in_room("person"):
            # Ask the person their candy preference.
            response = ask("person", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
            if response == "chocolate":
                chocolate_count += 1
            elif response == "caramel":
                caramel_count += 1
            elif response == "gummy":
                gummy_count += 1
                
    # After visiting all offices, return to the starting location.
    go_to(start_loc)
    
    # Tell how many of each candy that needs to be bought.
    message = ("We need to buy {} chocolates, {} caramels, and {} gummies."
               .format(chocolate_count, caramel_count, gummy_count))
    say(message)
"""

