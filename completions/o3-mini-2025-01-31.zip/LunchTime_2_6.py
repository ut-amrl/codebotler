name = "LunchTime"

prompt = "Visit Jill's office and ask her if she would like to go for lunch tomorrow. If yes, ask her when (offer some reasonable lunch time options). Let me know what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Visit Jill's office
    go_to("Jill's office")
    
    # Ask if she would like to go for lunch tomorrow
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    
    # If Jill agrees, ask her for a specific time with some lunch time options
    if response == "Yes":
        time_choice = ask("Jill", "Great! What time works for you? Options:", ["12:00", "12:30", "1:00"])
        detailed_response = "Yes, and she suggested " + time_choice
    else:
        detailed_response = "No"
    
    # Let the user know what she said
    say("Jill said: " + detailed_response)
"""

