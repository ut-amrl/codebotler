name = "SetTemperature"

prompt = "The thermostat is currently set to 72 degrees. Go ask if Arjun thinks his office should be colder or warmer. Come back and tell me what temperature in degrees I should change the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Arjun's office")
    response = ask("Arjun", "Do you think your office should be colder or warmer?", ["colder", "warmer"])
    # Adjust temperature based on Arjun's response.
    if response == "colder":
        new_temp = 70  # Decrease by 2 degrees
    else:
        new_temp = 74  # Increase by 2 degrees
    go_to(start_loc)
    say("Change the thermostat to " + str(new_temp) + " degrees.")
"""

