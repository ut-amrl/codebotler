name = "MailDelivery"

prompt = "Grab a mail bin from the mail room. Go to every office, and ask if they have any mail to deliver. Ask them to put all mail in the bin if there is any. Put the mail bin back in the mail room and report which offices the mail is from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Grab a mail bin from the mail room (assume it's now in our possession)
    go_to("mail room")
    
    mail_offices = []
    all_rooms = get_all_rooms()
    
    # Visit every office to check for mail
    for room in all_rooms:
        # Assuming offices have "office" in their name
        if "office" in room.lower():
            go_to(room)
            response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                # Ask them to put all mail in the bin
                ask("", "Please put all mail in the bin.", ["OK"])
                mail_offices.append(room)
    
    # Return the mail bin to the mail room
    go_to("mail room")
    
    # Report back which offices the mail is from
    if mail_offices:
        report = "Mail received from: " + ", ".join(mail_offices)
    else:
        report = "No mail was delivered from any office."
    say(report)
"""

