name = "WeatherPoll"

prompt = "Go to the main entrance. If there is no one there, wait for someone. Ask them if they feel it is hot out. Ask 10 people this same question until you have 10 replies. Finally, come back and tell me the percentage of people that think it's hot outside."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    # Save the initial location
    start_loc = get_current_location()
    # Go to the main entrance
    go_to("main entrance")
    
    responses = 0
    hot_count = 0
    # Ask 10 people at the main entrance until we have 10 replies
    while responses < 10:
        # Wait for someone to be present in the room
        while not is_in_room("person"):
            time.sleep(1)  # wait until a person shows up

        # Ask the person if they feel it's hot outside
        response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
        responses += 1
        
        if response == "Yes":
            hot_count += 1
        
        # Wait until the person leaves so that we ask a different individual
        while is_in_room("person"):
            time.sleep(1)
    
    # Calculate the percentage of people who think it's hot outside
    percentage = (hot_count / 10) * 100
    
    # Return to the starting location
    go_to(start_loc)
    
    # Announce the result
    say("Percentage of people who think it's hot outside: " + str(percentage) + "%")
"""

