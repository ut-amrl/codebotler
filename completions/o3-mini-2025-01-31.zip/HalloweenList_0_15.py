name = "HalloweenList"

prompt = "Go to every office, and if there is anyone there, ask if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Counters for each treat.
    count_chocolate = 0
    count_caramel = 0
    count_gummy = 0

    # Identify all offices among all rooms.
    offices = []
    for room in get_all_rooms():
        # Assuming any room with "office" in its name is an office.
        if "office" in room.lower():
            offices.append(room)
    
    # Visit each office.
    for office in offices:
        go_to(office)
        # Check if there is any person in the current office.
        if is_in_room("person"):
            # Ask the person their treat preference.
            response = ask("person", "Would you like a chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
            if response == "chocolate":
                count_chocolate += 1
            elif response == "caramel":
                count_caramel += 1
            elif response == "gummy":
                count_gummy += 1

    # Return to the starting location.
    go_to(start_loc)
    
    # Report the totals.
    say("We need to buy {} chocolates, {} caramels, and {} gummies.".format(count_chocolate, count_caramel, count_gummy))
"""

