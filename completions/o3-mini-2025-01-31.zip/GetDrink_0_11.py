name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. Bring what they ask for from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Start from the current location.
    start_loc = get_current_location()
    
    # Go to the lobby.
    go_to("lobby")
    
    # Ask the visitor which drink they would like.
    drink = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["bottle of water", "iced tea", "lemonade"])
    
    # Bring the selected drink from the kitchen.
    go_to("kitchen")
    
    # Assuming the robot picks up the drink here.
    # Return to the lobby to deliver it.
    go_to("lobby")
    say("Here is your " + drink)
"""

