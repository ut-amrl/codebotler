name = "MovieMessenger"

prompt = "Ask Sally if she wants to go to the cinema with Mark. Tell Mark what Sally said, and if yes, ask Mark whether he wants to leave at 4PM, 5PM, or 6PM. If Sally said yes, go tell Sally what time Mark is leaving."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Ask Sally if she wants to go to the cinema with Mark.
    sally_response = ask("Sally", "Do you want to go to the cinema with Mark?", ["Yes", "No"])
    
    # Tell Mark what Sally said.
    go_to("Mark's office")
    say("Sally said " + sally_response)
    
    # If Sally said yes, ask Mark for his preferred departure time.
    if sally_response == "Yes":
        mark_time = ask("Mark", "When do you want to leave?", ["4PM", "5PM", "6PM"])
        # Go back to Sally's office to tell her what time Mark is leaving.
        go_to("Sally's office")
        say("Mark will leave at " + mark_time)
"""

