name = "LunchTime"

prompt = "Visit Jill's office and ask her if she would like to go for lunch tomorrow. If yes, ask her when (offer some reasonable lunch time options). Let me know what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    time_response = ""
    if response == "Yes":
        time_response = ask("Jill", "When would you like to go for lunch?", ["11am", "12pm", "1pm"])
    
    message = "Jill said " + response
    if time_response:
        message += " and suggested " + time_response + " for lunch."
    say(message)
    
    go_to(start_loc)
"""

