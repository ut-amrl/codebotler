name = "GrilledCheese"

prompt = "Compile the necessary ingredients for grilled cheese. Go to Zarko's office, ask him about his available items, and then report back to me which items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the necessary ingredients for a grilled cheese sandwich.
    required_items = ["bread", "cheese", "butter"]
    missing_items = []
    
    # Save the current location to return later.
    start_loc = get_current_location()
    
    # Go to Zarko's office.
    go_to("Zarko's office")
    
    # Ask Zarko if he has each of the required ingredients.
    for item in required_items:
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "No":
            missing_items.append(item)
    
    # Return to the original location.
    go_to(start_loc)
    
    # Compile and report the response.
    if missing_items:
        message = "Zarko does not have " + ", ".join(missing_items) + "."
    else:
        message = "Zarko has all the necessary items."
    
    say(message)
"""

