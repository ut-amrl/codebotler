name = "GrilledCheese"

prompt = "Compile the necessary ingredients for grilled cheese. Go to Zarko's office, ask him about his available items, and then report back to me which items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the necessary ingredients for grilled cheese.
    ingredients = ["bread", "cheese", "butter"]
    
    # Go to Zarko's office.
    go_to("Zarko's office")
    
    missing = []
    
    # Ask Zarko about each ingredient.
    for item in ingredients:
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "No":
            missing.append(item)
    
    # Report back which items he does not have.
    if missing:
        message = "Zarko does not have: " + ", ".join(missing)
    else:
        message = "Zarko has all the necessary items for grilled cheese."
        
    say(message)
"""

