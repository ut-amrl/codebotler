name = "SayGoodDay"

prompt = "Visit each lab and if someone is present, greet them with a pleasant Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    
    # Visit each lab. We assume that lab names include the word "lab" (case insensitive).
    for room in all_rooms:
        if "lab" in room.lower():
            go_to(room)
            # Check if someone is present in the lab
            if is_in_room("person"):
                say("Good Day!")
                
    # Optionally return to the original location
    go_to(start_loc)
"""

