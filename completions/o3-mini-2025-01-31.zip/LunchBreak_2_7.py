name = "LunchBreak"

prompt = "Go to Alice's and Bob's offices and ask each of them if they are up for lunch. If they say yes, tell them that we will meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    participants = []

    for person in ["Alice", "Bob"]:
        go_to(f"{person}'s office")
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            say("We will meet in the lobby in 5 minutes")
            participants.append(person)
    
    go_to(start_loc)

    if participants:
        message = "The following people are joining for lunch: " + ", ".join(participants)
    else:
        message = "No one is joining for lunch"
    
    say(message)
"""

