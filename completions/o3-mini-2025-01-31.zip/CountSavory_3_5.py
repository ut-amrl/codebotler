name = "CountSavory"

prompt = "Go visit each office. If there is a person in the office, inquire about their liking for cupcake, ham sandwich, beef jerky, or donut. Come back and tell me of the count of people who went for a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location.
    start_loc = get_current_location()
    
    # Initialize the count for savory choices.
    savory_count = 0
    
    # Retrieve all rooms and filter for offices.
    all_rooms = get_all_rooms()
    offices = [room for room in all_rooms if "office" in room]
    
    # Visit each office.
    for office in offices:
        go_to(office)
        # Check if there's a person in the office.
        if is_in_room("person"):
            # Ask their snack preference.
            response = ask("person", "Which snack would you like: cupcake, ham sandwich, beef jerky, or donut?", 
                           ["cupcake", "ham sandwich", "beef jerky", "donut"])
            # Count savory options (ham sandwich or beef jerky).
            if response in ["ham sandwich", "beef jerky"]:
                savory_count += 1
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Inform the user of the count.
    say("The count of people who went for a savory option is " + str(savory_count))
"""

