name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    
    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0

    # Get all rooms and filter for those that are offices.
    all_rooms = get_all_rooms()
    offices = [room for room in all_rooms if "office" in room]

    for office in offices:
        go_to(office)
        # Check if there's anyone in the office.
        if is_in_room("person"):
            caramel_resp = ask("person", "How many caramel would you like? (0-4)", ["0", "1", "2", "3", "4"])
            chocolate_resp = ask("person", "How many chocolate would you like? (0-4)", ["0", "1", "2", "3", "4"])
            gummy_resp = ask("person", "How many gummy would you like? (0-4)", ["0", "1", "2", "3", "4"])
            
            total_caramel += int(caramel_resp)
            total_chocolate += int(chocolate_resp)
            total_gummy += int(gummy_resp)

    # Return to the original location.
    go_to(start_loc)
    message = ("We need to buy " + str(total_caramel) + " caramel, " +
               str(total_chocolate) + " chocolate, and " +
               str(total_gummy) + " gummy.")
    say(message)
"""

