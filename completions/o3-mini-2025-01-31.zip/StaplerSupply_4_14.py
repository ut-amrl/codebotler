name = "StaplerSupply"

prompt = "Tell me the name of every printer room that does not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get the list of all rooms.
    all_rooms = get_all_rooms()
    
    # This will store the names of printer rooms without a stapler.
    printer_rooms_missing_stapler = []
    
    # Check each room to see if it's a printer room and if it does not contain a stapler.
    for room in all_rooms:
        # Consider room a printer room if its name contains "printer" (case insensitive).
        if "printer" not in room.lower():
            continue
        
        # Go to the printer room.
        go_to(room)
        
        # If a stapler is not present in the room, record the room's name.
        if not is_in_room("stapler"):
            printer_rooms_missing_stapler.append(room)
    
    # Report the findings.
    if printer_rooms_missing_stapler:
        message = "The following printer rooms do not have a stapler: " + ", ".join(printer_rooms_missing_stapler)
    else:
        message = "All printer rooms have staplers."
    
    say(message)
"""

