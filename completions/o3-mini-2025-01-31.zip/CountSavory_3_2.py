name = "CountSavory"

prompt = "Go visit each office. If there is a person in the office, inquire about their liking for cupcake, ham sandwich, beef jerky, or donut. Come back and tell me of the count of people who went for a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    savory_count = 0
    # Get all rooms and visit those that are offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" not in room:
            continue
        go_to(room)
        # Check if there's a person present in the office.
        if is_in_room("person"):
            response = ask("person", 
                           "Which do you prefer: cupcake, ham sandwich, beef jerky, or donut?", 
                           ["cupcake", "ham sandwich", "beef jerky", "donut"])
            if response in ["ham sandwich", "beef jerky"]:
                savory_count += 1
    go_to(start_loc)
    say("The count of people who chose a savory option is " + str(savory_count))
"""

