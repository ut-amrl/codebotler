name = "LunchTime"

prompt = "Go to Jill's office and ask her if she'd like to go for lunch tomorrow. If yes, ask her at what time (offer her some reasonable options). Come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to come back later
    start_loc = get_current_location()
    
    # Go to Jill's office
    go_to("Jill's office")
    
    # Ask Jill if she would like to go for lunch tomorrow
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    
    # Initialize variable to store final message
    if response == "Yes":
        # Ask her what time she'd like to have lunch, with reasonable time options
        time_response = ask("Jill", "What time would you like to have lunch tomorrow?", ["12:00 PM", "12:30 PM", "1:00 PM"])
        final_message = "Jill said yes to lunch and suggested " + time_response
    else:
        final_message = "Jill said no to lunch tomorrow"
    
    # Return to the starting location
    go_to(start_loc)
    
    # Tell the original requester what Jill said
    say(final_message)
"""

