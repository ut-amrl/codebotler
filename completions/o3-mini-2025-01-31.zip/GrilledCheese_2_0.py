name = "GrilledCheese"

prompt = "Put together a compilation of grilled cheese ingredients. Head to Zarko's office, inquire about his available ingredients, and then update me on what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the current location to return later if needed.
    start_loc = get_current_location()
    
    # Define the essential grilled cheese ingredients.
    ingredients = ["bread", "cheese", "butter"]
    missing = []
    
    # Go to Zarko's office.
    go_to("Zarko's office")
    
    # Ask Zarko about each ingredient.
    for
"""

