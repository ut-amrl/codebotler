name = "WeatherPoll"

prompt = "Go wait for someone at the main entrance. Ask them if they feel it is hot out, then wait for the next person and ask the same question. Do this until you have ten responses, then come back and report the percentage of people who think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    # Remember starting location to come back later.
    start_loc = get_current_location()
    
    # Go to the main entrance to start collecting responses.
    go_to("main entrance")
    
    total_responses = 0
    hot_count = 0
    
    # Loop until 10 responses are collected.
    while total_responses < 10:
        # Wait until someone is in the room.
        if is_in_room("person"):
            # Ask the person if they feel it is hot out.
            response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
            total_responses += 1
            if response == "Yes":
                hot_count += 1
            # Wait a moment to ensure the next individual arrives.
            time.sleep(2)
        else:
            # Poll every second for someone to show up.
            time.sleep(1)
    
    # Calculate percentage of people who think it is hot.
    percentage = (hot_count / total_responses) * 100
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Report the percentage.
    say("Percentage of people who think it is hot out: " + str(percentage) + "%")
"""

