name = "CountSavory"

prompt = "Go through each office; if someone is there, ask about their preference among cupcake, donut, beef jerky, or ham sandwich. Report the number of individuals who opted for a savory item after returning."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later
    start_loc = get_current_location()
    
    # Counter for savory preferences.
    savory_count = 0
    
    # Get all rooms and filter those that are offices.
    all_rooms = get_all_rooms()
    office_rooms = [room for room in all_rooms if "office" in room.lower()]
    
    for office in office_rooms:
        go_to(office)
        # Check if someone is in the current office.
        if is_in_room("person"):
            # Ask for their snack preference.
            response = ask("", "Which snack do you prefer?", ["cupcake", "donut", "beef jerky", "ham sandwich"])
            # Count if the selected option is savory.
            if response in ["beef jerky", "ham sandwich"]:
                savory_count += 1
    # Return to the starting location.
    go_to(start_loc)
    
    # Report the count.
    say("Number of individuals that opted for a savory item: " + str(savory_count))
"""

