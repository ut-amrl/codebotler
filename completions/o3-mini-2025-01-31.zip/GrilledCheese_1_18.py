name = "GrilledCheese"

prompt = "Create a list of ingredients needed to make grilled cheese. Visit Zarko's office and inquire which of them he possesses. Return and inform me of the items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the ingredients needed for grilled cheese.
    ingredients = ["bread", "cheese", "butter"]
    possessed = []
    
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Visit Zarko's office.
    go_to("Zarko's office")
    
    # Inquire about each ingredient.
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response == "Yes":
            possessed.append(ingredient)
    
    # Determine the ingredients Zarko does not have.
    missing = [item for item in ingredients if item not in possessed]
    
    # Return to the original location.
    go_to(start_loc)
    
    # Inform the user of the missing items.
    if missing:
        say("Zarko does not have: " + ", ".join(missing))
    else:
        say("Zarko has all the ingredients needed for grilled cheese.")
"""

