name = "GrilledCheese"

prompt = "Create a list of ingredients needed to make grilled cheese. Visit Zarko's office and inquire which of them he possesses. Return and inform me of the items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the ingredients needed for grilled cheese
    ingredients = ["bread", "cheese", "butter"]
    missing_items = []
    
    # Save the current location to return later
    start_loc = get_current_location()
    
    # Visit Zarko's office to inquire about each ingredient
    go_to("Zarko's office")
    for item in ingredients:
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "No":
            missing_items.append(item)
    
    # Return to original location
    go_to(start_loc)
    
    # Inform the user about the ingredients Zarko does not have
    if missing_items:
        say("Zarko does not have: " + ", ".join(missing_items))
    else:
        say("Zarko has all the ingredients needed for grilled cheese.")
"""

