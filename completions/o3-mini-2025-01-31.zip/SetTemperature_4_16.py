name = "SetTemperature"

prompt = "The thermostat is set to 72 degrees. Go to Arjun's office and ask if he would like the temperature to be set to a warmer or colder value. Return and tell me what temperature in degrees I should set the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # The current thermostat setting is 72 degrees.
    starting_location = get_current_location()
    
    # Go to Arjun's office to ask his preference.
    go_to("Arjun's office")
    response = ask("Arjun", "Would you like the temperature to be set to a warmer or colder value?", ["warmer", "colder"])
    
    # Calculate the new temperature.
    # For this example, warmer means increasing the temperature by 1 degree
    # and colder means decreasing it by 1 degree.
    if response == "warmer":
        new_temperature = 72 + 1
    else:
        new_temperature = 72 - 1
    
    # Return to the starting location and inform the requester.
    go_to(starting_location)
    say("Set the thermostat to " + str(new_temperature) + " degrees.")
"""

