name = "WeatherPoll"

prompt = "Go to the main entrance, and if there is no one there, wait for someone to show up. Ask them if they feel it is hot out. Wait for the next person and ask the same question again. Do this 10 times. Come back and report the percentage of people who think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    count_hot = 0
    people_asked = 0

    # Ask 10 different people
    while people_asked < 10:
        # Wait until someone is present at the main entrance.
        while not is_in_room("person"):
            time.sleep(1)
        # A person has arrived, ask the question.
        response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
        if response == "Yes":
            count_hot += 1
        people_asked += 1
        
        # Wait until the person leaves before proceeding.
        while is_in_room("person"):
            time.sleep(1)
    
    # Compute the percentage of people who think it's hot.
    percentage = (count_hot / 10) * 100
    go_to(start_loc)
    say("Percentage of people who think it's hot out: " + str(percentage) + "%")
"""

