name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return at the end.
    start_loc = get_current_location()
    
    # Initialize totals for each candy type.
    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0

    # Get all rooms and iterate through those that are offices
"""

