name = "MailDelivery"

prompt = "Take a mail bin from the mail room. For every office, ask if there is any mail to deliver and if someone says yes, ask them to put all mail in the bin. Finally find me at the mail room. Put the mail bin away, and tell me which offices had mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Pick up the mail bin from the mail room.
    go_to("mail room")
    say("Picked up the mail bin.")
    
    # Prepare list to store offices that had mail.
    offices_with_mail = []
    
    # Get all rooms and filter for offices.
    all_rooms = get_all_rooms()
    # Assuming offices have the substring "office" in their name,
    # and that "mail room" is not considered an office.
    office_rooms = [room for room in all_rooms if "office" in room.lower() and room.lower() != "mail room"]
    
    # For every office, ask if there is any mail to deliver.
    for office in office_rooms:
        go_to(office)
        # Ask if there is any mail to deliver.
        response = ask("office occupant", "Is there any mail to deliver in " + office + "?", ["Yes", "No"])
        if response == "Yes":
            # Ask them to put all mail in the bin.
            ask("office occupant", "Please put all mail in the bin.", ["Okay"])
            offices_with_mail.append(office)
    
    # Finally, go back to the mail room.
    go_to("mail room")
    # Put the mail bin away.
    say("Putting the mail bin away.")
    
    # Tell the requester which offices had mail.
    if offices_with_mail:
        message = "The following offices had mail: " + ", ".join(offices_with_mail)
    else:
        message = "No offices had mail."
    say(message)
"""

