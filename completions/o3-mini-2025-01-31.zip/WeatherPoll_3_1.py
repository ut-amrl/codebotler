name = "WeatherPoll"

prompt = "Go to the main entrance. If there is no one there, wait for someone. Ask them if they feel it is hot out. Ask 10 people this same question until you have 10 replies. Finally, come back and tell me the percentage of people that think it's hot outside."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    total_responses = 0
    yes_responses = 0
    
    # Continue until we have 10 responses.
    while total_responses < 10:
        # Wait until at least one person is present.
        if not is_in_room("person"):
            time.sleep(1)
            continue
        
        # Ask the person if it's hot out.
        response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
        total_responses += 1
        if response == "Yes":
            yes_responses += 1
    
    # Calculate the percentage of people who think it's hot.
    percentage = (yes_responses / total_responses) * 100
    go_to(start_loc)
    say("Percentage of people that think it's hot outside: " + str(percentage) + "%")
"""

