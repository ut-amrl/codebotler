name = "MailDelivery"

prompt = "Find a mail bin in the mail room and carry it with you. Collect mail from every office by asking if there is any mail they'd like delivered. If yes, ask them to put it in the bin. Return the bin to the mail room and say which offices sent mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Start in the mail room to pick up the mail bin.
    go_to("mail room")
    # Assume the mail bin is found and we are now carrying it.
    
    # Get a list of all rooms and filter for offices, excluding the mail room.
    all_rooms = get_all_rooms()
    offices = [room for room in all_rooms if "office" in room.lower() and room.lower() != "mail room"]
    offices_that_sent_mail = []
    
    # Visit each office to collect mail.
    for office in offices:
        go_to(office)
        response = ask("office occupant", "Is there any mail you'd like delivered?", ["Yes", "No"])
        if response == "Yes":
            # Ask them to put the mail in the bin.
            ask("office occupant", "Please put your mail in the bin.", ["Ok"])
            offices_that_sent_mail.append(office)
    
    # Return to the mail room with the mail bin.
    go_to("mail room")
    
    # Announce which offices sent mail.
    if offices_that_sent_mail:
        message = "Mail was collected from: " + ", ".join(offices_that_sent_mail)
    else:
        message = "No offices sent any mail."
    say(message)
"""

