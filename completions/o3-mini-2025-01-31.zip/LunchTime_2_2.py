name = "LunchTime"

prompt = "Visit Jill's office and ask her if she would like to go for lunch tomorrow. If yes, ask her when (offer some reasonable lunch time options). Let me know what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to Jill's office
    go_to("Jill's office")
    
    # Ask Jill if she would like to go for lunch tomorrow
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    
    if response == "Yes":
        # If she says yes, ask her when with reasonable lunch time options
        lunch_time = ask("Jill", "Great! What time would you like to go for lunch tomorrow?", 
                         ["11:30", "12:00", "12:30", "1:00"])
        final_message = "Jill said yes and she would like to go for lunch at " + lunch_time + "."
    else:
        final_message = "Jill said no, she does not want to go for lunch tomorrow."
    
    # Tell me what she said
    say(final_message)
"""

