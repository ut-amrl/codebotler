name = "StaplerSupply"

prompt = "Check all printer rooms for staplers, and come back and tell me which ones do not have any staplers."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    printer_rooms_without_staplers = []
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Assume that printer rooms include "printer" in their names.
        if "printer" in room.lower():
            go_to(room)
            # Check for the presence of a stapler in the room.
            if not is_in_room("stapler"):
                printer_rooms_without_staplers.append(room)
    # Return to the starting location.
    go_to(start_loc)
    # Report which printer rooms do not have any staplers.
    if printer_rooms_without_staplers:
        message = "The following printer rooms do not have any staplers: " + ", ".join(printer_rooms_without_staplers)
    else:
        message = "All printer rooms have staplers."
    say(message)
"""

