name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so the robot can come back later.
    start_loc = get_current_location()
    
    # Initialize counters for each treat.
    total_chocolate = 0
    total_caramel = 0
    total_gummy = 0
    
    # Get all rooms and filter for those that are offices.
    all_rooms = get_all_rooms()
    office_rooms = [room for room in all_rooms if "office" in room.lower()]
    
    # For each office, if there's someone there, ask them for the treat counts.
    for office in office_rooms:
        go_to(office)
        # Check if there is anyone in the office.
        if is_in_room("person"):
            # Ask the occupant about each treat.
            choc_resp = ask("occupant", "How many chocolate treats would you like?", ["0", "1", "2", "3", "4"])
            car_resp = ask("occupant", "How many caramel treats would you like?", ["0", "1", "2", "3", "4"])
            gummy_resp = ask("occupant", "How many gummy treats would you like?", ["0", "1", "2", "3", "4"])
            
            # Convert responses from strings to integers and accumulate.
            total_chocolate += int(choc_resp)
            total_caramel += int(car_resp)
            total_gummy += int(gummy_resp)
    
    # After checking all offices, go back to the starting location.
    go_to(start_loc)
    
    # Tell the requester the total number of each treat needed.
    say("We need to buy {} chocolate treats, {} caramel treats, and {} gummy treats.".format(
        total_chocolate, total_caramel, total_gummy))
"""

