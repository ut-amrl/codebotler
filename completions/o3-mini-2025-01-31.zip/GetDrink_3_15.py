name = "GetDrink"

prompt = "Go to the lobby and ask any person there if they want iced tea, lemonade or a bottle of water. Bring whatever they asked for back from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby and ask a person their drink preference.
    go_to("lobby")
    drink_choice = ask("person", "Would you like iced tea, lemonade, or a bottle of water?", ["iced tea", "lemonade", "bottle of water"])
    
    # Go to the kitchen to pick up the selected drink.
    go_to("kitchen")
    say("Picked up " + drink_choice)
    
    # Bring the drink back from the kitchen.
    go_to("lobby")
    say("Here is your " + drink_choice)
"""

