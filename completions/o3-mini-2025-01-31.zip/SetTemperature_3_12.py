name = "SetTemperature"

prompt = "Go to Arjun's office and ask him if he would like his office to be warmer or colder. The thermostat says the temperature in the office is currently 72 degrees. Come back and tell me what temperature I should reset it to based on Arjun's preferences."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # The current temperature in the office is known to be 72 degrees.
    current_temperature = 72

    # Go to Arjun's office.
    go_to("Arjun's office")
    
    # Ask him if he would like his office to be warmer or colder.
    response = ask("Arjun", "Would you like your office to be warmer or colder?", ["warmer", "colder"])
    
    # Determine the new temperature based on his preference.
    if response.lower() == "warmer":
        new_temperature = current_temperature + 1
    else:
        new_temperature = current_temperature - 1

    # Return to the starting location.
    original_location = get_current_location()
    go_to(original_location)
    
    # Send a message with the temperature adjustment recommendation.
    say("Reset the thermostat to " + str(new_temperature) + " degrees based on Arjun's preference.")
"""

