name = "SayGoodDay"

prompt = "Visit every lab space and when encountering an individual, tell them a Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Retrieve all rooms and filter those which are lab spaces.
    all_rooms = get_all_rooms()
    lab_spaces = [room for room in all_rooms if "lab" in room.lower()]
    
    # Visit each lab space.
    for lab in lab_spaces:
        go_to(lab)
        # Check if there is a person in the lab space.
        if is_in_room("person"):
            say("Good Day!")
    
    # Optionally, indicate that the task is completed.
    say("Task completed")
"""

