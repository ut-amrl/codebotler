name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Record initial location to return later
    start_loc = get_current_location()
    
    # Initialize counters for each candy type
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0
    
    # Get list of all rooms and iterate over those that are offices
    for room in get_all_rooms():
        # Check if the room name includes "office"
        if "office" not in room:
            continue
        
        go_to(room)
        
        # Check if there is a person in this office. If not, skip.
        if not is_in_room("person"):
            continue
        
        # Ask the person how many items they want for each candy type.
        gummy_response = ask("person", "How many gummies would you like?", ["0", "1", "2", "3", "4"])
        caramel_response = ask("person", "How many caramels would you like?", ["0", "1", "2", "3", "4"])
        chocolate_response = ask("person", "How many chocolates would you like?", ["0", "1", "2", "3", "4"])
        
        # Convert responses to integers and add to totals
        total_gummy += int(gummy_response)
        total_caramel += int(caramel_response)
        total_chocolate += int(chocolate_response)
    
    # Return to the original location
    go_to(start_loc)
    
    # Report the totals
    say("We need to buy {} gummies, {} caramels, and {} chocolates".format(total_gummy, total_caramel, total_chocolate))
"""

