name = "StaplerDelivery"

prompt = "Check if every printer room has a stapler. If not, put a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get the list of all rooms.
    all_rooms = get_all_rooms()
    
    # Filter out printer rooms. We assume printer rooms have "printer room" in their name.
    printer_rooms = [room for room in all_rooms if "printer room" in room.lower()]
    
    # For each printer room, check if there is a stapler.
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            # If no stapler is in the room, go to the supply room to get one.
            go_to("supply room")
            say("Retrieving a stapler from the supply room")
            # Then, return to that printer room and place the stapler.
            go_to(room)
            say("Placed a stapler in " + room)
    say("All printer rooms have been checked and staplers have been placed where needed.")
"""

