name = "CountSavory"

prompt = "Go visit each office. If there is a person in the office, inquire about their liking for cupcake, ham sandwich, beef jerky, or donut. Come back and tell me of the count of people who went for a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    savory_count = 0

    # Get a list of all rooms and filter for offices.
    all_rooms = get_all_rooms()
    office_rooms = [room for room in all_rooms if "office" in room.lower()]

    for office in office_rooms:
        go_to(office)
        # Check if a person is present in the office.
        if is_in_room("person"):
            # Ask the person about their food preference.
            response = ask("person", "What would you like to eat?", 
                           ["cupcake", "ham sandwich", "beef jerky", "donut"])
            # Count savory options: ham sandwich and beef jerky.
            if response in ["ham sandwich", "beef jerky"]:
                savory_count += 1

    go_to(start_loc)
    say("The count of people who went for a savory option is " + str(savory_count))
"""

