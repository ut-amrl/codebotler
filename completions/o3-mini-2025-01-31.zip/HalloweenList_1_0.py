name = "HalloweenList"

prompt = "Go to every office, and if there is a person there, ask them if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    
    # Counters for each treat
    counts = {"chocolate": 0, "caramel": 0, "gummy": 0}
    
    # Loop through each room that is an office
    for room in rooms:
        # Assume offices have "office" in their name.
        if "office" in room.lower():
            go_to(room)
            # Check if there is a person in the room.
            if is_in_room("person"):
                answer = ask("person", "Would you like a chocolate, caramel or gummy?", ["chocolate", "caramel", "gummy"])
                if answer in counts:
                    counts[answer] += 1
    
    # Return to the starting location
    go_to(start_loc)
    
    # Construct the result message.
    message = ("We need to buy {} chocolates, {} caramels, and {} gummies."
               .format(counts["chocolate"], counts["caramel"], counts["gummy"]))
    say(message)
"""

