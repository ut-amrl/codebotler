name = "GrilledCheese"

prompt = "Create a list of ingredients needed to make grilled cheese. Visit Zarko's office and inquire which of them he possesses. Return and inform me of the items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the ingredients needed for grilled cheese
    ingredients = ["bread", "cheese", "butter"]
    missing = []
    
    # Store the starting location so we can return later.
    start_location = get_current_location()
    
    # Visit Zarko's office to ask him about each ingredient.
    go_to("Zarko's office")
    for item in ingredients:
        # Ask Zarko if he has the ingredient.
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "No":
            missing.append(item)
    
    # Return to the starting location.
    go_to(start_location)
    
    # Inform about the items Zarko does not have.
    if missing:
        missing_message = "Zarko does not have: " + ", ".join(missing)
    else:
        missing_message = "Zarko has all the ingredients for grilled cheese."
    say(missing_message)
"""

