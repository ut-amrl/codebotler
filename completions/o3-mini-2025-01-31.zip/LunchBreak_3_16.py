name = "LunchBreak"

prompt = "Ask Alice and Bob if they are up for lunch. If they say yes, tell them that we will meet in the lobby in five minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    
    # Ask Alice and Bob if they are up for lunch
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    
    # For those who said yes, tell them to meet in the lobby in five minutes.
    if alice_response == "Yes":
        say("Alice, we will meet in the lobby in five minutes")
    if bob_response == "Yes":
        say("Bob, we will meet in the lobby in five minutes")
    
    # Return to the starting location
    go_to(start_loc)
    
    # Tell the supervisor who is joining for lunch.
    joiners = []
    if alice_response == "Yes":
        joiners.append("Alice")
    if bob_response == "Yes":
        joiners.append("Bob")
    
    if joiners:
        joiners_list = ", ".join(joiners)
        say("The following people are joining for lunch: " + joiners_list)
    else:
"""

