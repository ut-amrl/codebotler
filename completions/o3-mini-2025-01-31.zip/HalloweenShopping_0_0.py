name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    chocolate_total = 0
    caramel_total = 0
    gummy_total = 0

    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Check if the room is an office by seeing if "office" is in its name.
        if "office" in room.lower():
            go_to(room)
            # If there is anyone in the office, ask them for their treat preferences.
            if is_in_room("person"):
                choc_response = ask("person", "How many chocolate treats would you like from 0 to 4?", ["0", "1", "2", "3", "4"])
                car_response = ask("person", "How many caramel treats would you like from 0 to 4?", ["0", "1", "2", "3", "4"])
                gummy_response = ask("person", "How many gummy treats would you like from 0 to
"""

