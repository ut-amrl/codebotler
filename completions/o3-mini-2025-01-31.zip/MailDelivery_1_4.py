name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Start at the mail room to pick up the mail bin.
    go_to("mail room")
    
    # List to keep track of offices that have mail.
    offices_with_mail = []
    
    # Get a list of all rooms.
    all_rooms = get_all_rooms()
    
    # Visit every office and check for mail delivery.
    for room in all_rooms:
        # Consider a room as an office if its name contains "office".
        if "office" not in room.lower():
            continue
        
        go_to(room)
        
        # Ask if there's any mail to deliver.
        response = ask(room, "Do you have any mail to deliver?", ["Yes", "No"])
        if response == "Yes":
            # If yes, ask them to put the mail in the bin.
            ask(room, "Could you please put the mail in the bin?", ["Yes", "No"])
            offices_with_mail.append(room)
    
    # Return to the mail room.
    go_to("mail room")
    
    # Announce which offices delivered mail.
    if offices_with_mail:
        message = "Mail received from: " + ", ".join(offices_with_mail)
    else:
        message = "No mail was delivered by any office."
    say(message)
    
    # Put the mail bin back.
    say("Mail bin has been returned.")
"""

