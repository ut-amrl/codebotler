name = "LunchTime"

prompt = "Ask Jill in her office whether she will be free to go for lunch tomorrow. If yes, offer her some reasonable time options to choose from, and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    # Go to Jill's office
    go_to("Jill's office")
    
    # Ask if she's free for lunch tomorrow
    response = ask("Jill", "Will you be free to go for lunch tomorrow?", ["Yes", "No"])
    
    # If she is free, ask for a time option
    if response == "Yes":
        time_response = ask("Jill", "Great! Which time works best for you?", ["12:00", "12:30", "1:00"])
        final_response = f"Yes, and she prefers {time_response}."
    else:
        final_response = "No"
    
    # Return to the starting location and report Jill's response
    go_to(start_loc)
    say("Jill said: " + final_response)
"""

