name = "LunchBreak"

prompt = "Go to Alice's and Bob's offices and ask each of them if they are up for lunch. If they say yes, tell them that we will meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # List to store the names of people joining for lunch.
    joiners = []
    
    # List of people with corresponding office locations.
    people = [("Alice", "Alice's office"), ("Bob", "Bob's office")]
    
    # Visit each person's office and ask if they are up for lunch.
    for person, office in people:
        go_to(office)
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            # Confirm with the person.
            say("We will meet in the lobby in 5 minutes")
            joiners.append(person)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Report back who is joining for lunch.
    if joiners:
        say("The following people are joining for lunch: " + ", ".join(joiners))
    else:
        say("No one is joining for lunch.")
"""

