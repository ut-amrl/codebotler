name = "FindBackpack"

prompt = "Check where I left my backpack in all of the conference rooms and bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting point to bring the backpack back here
    start_loc = get_current_location()
    rooms = get_all_rooms()
    backpack_found = False
    
    # Search through all rooms that are conference rooms
    for room in rooms:
        # Check if the room name contains "conference" (case insensitive)
        if "conference" in room.lower():
            go_to(room)
            if is_in_room("backpack"):
                backpack_found = True
                say("I found your backpack in " + room)
                break  # Stop searching once the backpack is found
    
    if backpack_found:
        # Bring the backpack back to the user by returning to the starting location
        go_to(start_loc)
        say("I brought your backpack back to you")
    else:
        say("I could not find your backpack in the conference rooms")
"""

