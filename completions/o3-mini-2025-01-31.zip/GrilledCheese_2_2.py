name = "GrilledCheese"

prompt = "Put together a compilation of grilled cheese ingredients. Head to Zarko's office, inquire about his available ingredients, and then update me on what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    # Define the grilled cheese ingredients compilation.
    ingredients = ["bread", "cheese", "butter"]
    missing = []
    
    go_to("Zarko's office")
    for item in ingredients:
        response = ask("Zarko", f"Do you have {item} for making a grilled cheese?", ["Yes", "No"])
        if response == "No":
            missing.append(item)
    
    # Construct update message for missing ingredients.
    if missing:
        message = "Zarko does not have: " + ", ".join(missing)
    else:
        message = "Zarko has all the grilled cheese ingredients."
    
    go_to(start_loc)
    say(message)
"""

