name = "StaplerSupply"

prompt = "Check all printer rooms for staplers, and come back and tell me which ones do not have any staplers."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save current location to return later.
    start_loc = get_current_location()
    
    # Get all rooms and filter those that are printer rooms.
    all_rooms = get_all_rooms()
    printer_rooms = [room for room in all_rooms if "printer" in room.lower()]
    
    # List to keep track of printer rooms without staplers.
    rooms_without_staplers = []
    
    # Check each printer room for staplers.
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            rooms_without_staplers.append(room)
    
    # Return to the original location.
    go_to(start_loc)
    
    # Tell the requester which printer rooms do not have any staplers.
    if rooms_without_staplers:
        message = "The following printer rooms do not have any staplers: " + ", ".join(rooms_without_staplers)
    else:
        message = "All printer rooms have at least one stapler."
    say(message)
"""

