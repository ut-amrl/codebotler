name = "MailDelivery"

prompt = "Pick up a mail bin from the mail room. Go to every office and ask if they have any mail they'd like delivered. If so, ask them to put it in the mail bin. Finally, meet me in the mail room with all the mail. Place the mail bin back and tell me which offices they are from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Pick up the mail bin from the mail room.
    go_to("mail room")
    # The robot now has the mail bin.
    offices_with_mail = []
    
    # Retrieve all rooms and filter to get offices.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # We assume office rooms contain "office" in their name.
        if "office" in room.lower() and room.lower() != "mail room":
            go_to(room)
            # Ask if they have any mail they'd like delivered.
            response = ask(room, "Do you have any mail you'd like delivered?", ["Yes", "No"])
            if response == "Yes":
                # Ask them to put their mail in the mail bin.
                say("Please put your mail in the mail bin.")
                offices_with_mail.append(room)
    
    # After visiting all offices, return to the mail room.
    go_to("mail room")
    
    # Place the mail bin back.
    # Finally, tell the requester which offices the mail is from.
    if offices_with_mail:
        message = "The mail is from the following offices: " + ", ".join(offices_with_mail)
    else:
        message = "No offices had mail to be delivered."
    say("Mail bin is placed back. " + message)
"""

