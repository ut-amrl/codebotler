name = "LunchBreak"

prompt = "Ask Alice and Bob if they are up for lunch. If they say yes, tell them that we will meet in the lobby in five minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can come back later.
    start_loc = get_current_location()
    
    # List to store the names of those who are up for lunch.
    attendees = []
    
    # Ask Alice if she's up for lunch.
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("Hi Alice, we'll meet in the lobby in five minutes.")
        attendees.append("Alice")
        
    # Ask Bob if he's up for lunch.
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("Hi Bob, we'll meet in the lobby in five minutes.")
        attendees.append("Bob")
    
    # Return to the original starting location.
    go_to(start_loc)
    
    # Report who is joining for lunch.
    if attendees:
        message = "Joining for lunch: " + ", ".join(attendees)
    else:
        message = "No one is joining for lunch."
    say(message)
"""

