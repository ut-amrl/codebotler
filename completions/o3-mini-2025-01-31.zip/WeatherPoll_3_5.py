name = "WeatherPoll"

prompt = "Go to the main entrance. If there is no one there, wait for someone. Ask them if they feel it is hot out. Ask 10 people this same question until you have 10 replies. Finally, come back and tell me the percentage of people that think it's hot outside."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    responses = []
    while len(responses) < 10:
        # Wait until someone is in the room if no one is around.
        if not is_in_room("person"):
            time.sleep(1)
            continue
        # Ask the person if they feel it is hot out.
        response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
        responses.append(response)
    
    # Calculate the percentage of people who think it's hot outside.
    yes_count = sum(1 for r in responses if r == "Yes")
    percentage = (yes_count / 10) * 100
    
    go_to(start_loc)
    say("Percentage of people that think it's hot outside: " + str(percentage) + "%")
"""

