name = "HalloweenShopping"

prompt = "Visit every office. If there is a person in the office, ask the person to select 0 to 4 for each of the following categories: gummy, chocolate, or caramel. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    total_gummy = 0
    total_chocolate = 0
    total_caramel = 0
    
    # Gather all rooms and filter for offices (case-insensitive search for "office").
    rooms = get_all_rooms()
    office_rooms = [room for room in rooms if "office" in room.lower()]
    
    # Options for asking the quantity (0 to 4).
    options = ["0", "1", "2", "3", "4"]
    
    # Visit each office.
    for office in office_rooms:
        go_to(office)
        # Check if there's a person present.
        if is_in_room("person"):
            # Ask the occupant for their desired quantity for each candy.
            gummy_response = ask("office occupant", "Please select a number from 0 to 4 for gummy:", options)
            chocolate_response = ask("office occupant", "Please select a number from 0 to 4 for chocolate:", options)
            caramel_response = ask("office occupant", "Please select a number from 0 to 4 for caramel:", options)
            
            # Convert responses to integers and add to totals.
            total_gummy += int(gummy_response)
            total_chocolate += int(chocolate_response)
            total_caramel += int(caramel_response)
    
    # After visiting all offices, return to the starting location.
    go_to(start_loc)
    
    # Announce the total amounts needed.
    message = ("We need to buy {} gummy, {} chocolate, and {} caramel."
               .format(total_gummy, total_chocolate, total_caramel))
    say(message)
"""

