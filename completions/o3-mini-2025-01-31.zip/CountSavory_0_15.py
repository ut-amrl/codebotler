name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a cupcake, ham sandwich, donut, or beef jerky. Come back and tell me how many people chose a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location to return later.
    start_loc = get_current_location()
    
    # Get all rooms and filter for offices.
    all_rooms = get_all_rooms()
    offices = [room for room in all_rooms if "office" in room.lower()]
    
    savory_count = 0
    
    # Iterate over every office.
    for office in offices:
        go_to(office)
        # Check if there is someone in the office.
        if is_in_room("person"):
            # Ask the person for their food choice.
            response = ask("person", "Would you like a cupcake, ham sandwich, donut, or beef jerky?", 
                           ["cupcake", "ham sandwich", "donut", "beef jerky"])
            # Count if a savory option was chosen.
            if response in ["ham sandwich", "beef jerky"]:
                savory_count += 1
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Tell the requester how many people chose a savory option.
    say(str(savory_count) + " people chose a savory option")
"""

