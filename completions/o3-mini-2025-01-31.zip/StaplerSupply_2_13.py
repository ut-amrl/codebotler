name = "StaplerSupply"

prompt = "Go find all printer rooms that do not have a stapler. Come back and tell me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the current location so we can come back later.
    start_loc = get_current_location()
    
    # Get all rooms and filter out those that are printer rooms (case-insensitive check).
    printer_rooms = [room for room in get_all_rooms() if "printer" in room.lower()]
    
    # List to store printer rooms that do not have a stapler.
    rooms_without_stapler = []
    
    # Check each printer room for a stapler.
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            rooms_without_stapler.append(room)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Announce the result.
    if rooms_without_stapler:
        rooms_list = ", ".join(rooms_without_stapler)
        say("The following printer rooms do not have a stapler: " + rooms_list)
    else:
        say("All printer rooms have a stapler.")
"""

