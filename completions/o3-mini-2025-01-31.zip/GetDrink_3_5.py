name = "GetDrink"

prompt = "Go to the lobby and ask any person there if they want iced tea, lemonade or a bottle of water. Bring whatever they asked for back from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Start by going to the lobby.
    go_to("lobby")
    
    # Ask a person in the lobby which beverage they would like.
    beverage = ask("person", "Would you like iced tea, lemonade or a bottle of water?", 
                   ["iced tea", "lemonade", "a bottle of water"])
    
    # Go to the kitchen to fetch the requested beverage.
    go_to("kitchen")
    say("Picking up " + beverage)
    
    # Bring the beverage back to the lobby.
    go_to("lobby")
    say("Here is your " + beverage)
"""

