name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return there later.
    start_loc = get_current_location()
    
    # Initialize totals for each candy type.
    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0
    
    # Get all rooms and filter for those that are offices (case insensitive).
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" not in room.lower():
            continue
        
        # Go to this office.
        go_to(room)
        
        # Check if anyone is in the office.
        if is_in_room("person"):
            # Ask the occupant for their candy preferences.
            # For caramel.
            caramel_response = ask("person", 
                                     "How many caramel candies would you like? Choose a number from 0 to 4.", 
                                     ["0", "1", "2", "3", "4"])
            # For chocolate.
            chocolate_response = ask("person", 
                                     "How many chocolate candies would you like? Choose a number from 0 to 4.", 
                                     ["0", "1", "2", "3", "4"])
            # For gummy.
            gummy_response = ask("person", 
                                 "How many gummy candies would you like? Choose a number from 0 to 4.", 
                                 ["0", "1", "2", "3", "4"])
            
            # Update the totals.
            total_caramel += int(caramel_response)
            total_chocolate += int(chocolate_response)
            total_gummy += int(gummy_response)
    
    # After processing all offices, return to the starting location.
    go_to(start_loc)
    
    # Construct and say the summary message.
    message = ("We need to buy a total of " +
               str(total_caramel) + " caramel candies, " +
               str(total_chocolate) + " chocolate candies, and " +
               str(total_gummy) + " gummy candies.")
    say(message)
"""

