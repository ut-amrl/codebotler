name = "GetDrink"

prompt = "Go to the lobby. Ask if the visitor wants: a bottle of water, iced tea, or lemonade. Go to the kitchen and bring the visitor back what they asked for."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the lobby and ask the visitor for their drink choice.
    go_to("lobby")
    drink = ask("visitor", "Which drink would you like: a bottle of water, iced tea, or lemonade?", 
                ["bottle of water", "iced tea", "lemonade"])
    
    # Go to the kitchen to pick up the selected drink.
    go_to("kitchen")
    
    # Bring the drink back to the lobby.
    go_to("lobby")
    say("Here is your " + drink)
"""

