name = "GrilledCheese"

prompt = "Put together a compilation of grilled cheese ingredients. Head to Zarko's office, inquire about his available ingredients, and then update me on what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Zarko's office")
    
    # Define the typical grilled cheese ingredients.
    ingredients = ["bread", "cheese", "butter"]
    missing_ingredients = []

    # Ask Zarko for each ingredient
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient} needed for a grilled cheese?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(ingredient)

    # Return to the original location before updating
    go_to(start_loc)
    
    # Construct an update message based on the missing ingredients.
    if missing_ingredients:
        message = "Zarko does not have the following ingredients: " + ", ".join(missing_ingredients)
    else:
        message = "Zarko has all the grilled cheese ingredients."
    
    say(message)
"""

