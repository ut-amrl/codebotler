name = "SetTemperature"

prompt = "Ask Arjun in his office if he would like it to be warmer or colder. The thermostat is currently set to 72 degrees. Come back and tell me what temperature I should set the thermostat to based on what Arjun says."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location
    start_loc = get_current_location()
    
    # Go to Arjun's office to ask for his preference
    go_to("Arjun's office")
    response = ask("Arjun", "Would you like it to be warmer or colder?", ["Warmer", "Colder"])
    
    # The thermostat is currently set to 72 degrees.
    current_temp = 72
    if response == "Warmer":
        new_temp = current_temp + 2
    else:
        new_temp = current_temp - 2
    
    # Return to the starting location
    go_to(start_loc)
    say("Set the thermostat to " + str(new_temp) + " degrees")
"""

