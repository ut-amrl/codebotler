name = "WeatherPoll"

prompt = "Go to the main entrance. When someone shows up, ask them if they feel that it's hot out. Do this until you collect ten people's responses. Come back and tell me which percent of people think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    responses = []
    # Collect responses until we have 10
    while len(responses) < 10:
        # Check periodically if someone is in the room
        if is_in_room("person"):
            response = ask("person", "Do you feel that it's hot out?", ["Yes", "No"])
            responses.append(response)
        time.sleep(1)
    
    # Calculate the percentage of "Yes" responses
    yes_count = responses.count("Yes")
    percentage = (yes_count / 10) * 100
    
    # Return to the starting location and report the percentage
    go_to(start_loc)
    say("Percentage of people who think it's hot out: " + str(percentage) + "%")
"""

