name = "GrilledCheese"

prompt = "Put together a list of grilled cheese ingredients. Head to Zarko's office and inquire about his available ingredients. Return and inform me of what he is missing."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Step 1: Create the list of required grilled cheese ingredients.
    required_ingredients = ["bread", "cheese", "butter"]
    missing_ingredients = []
    
    # Record current location to return later.
    start_loc = get_current_location()
    
    # Step 2: Go to Zarko's office to inquire about his available ingredients.
    go_to("Zarko's office")
    
    # For each ingredient, ask Zarko if he has it.
    for ingredient in required_ingredients:
        answer = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if answer == "No":
            missing_ingredients.append(ingredient)
    
    # Step 3: Return to the starting location.
    go_to(start_loc)
    
    # Step 4: Inform the user what Zarko is missing.
    if missing_ingredients:
        say("Zarko is missing: " + ", ".join(missing_ingredients))
    else:
        say("Zarko has all the required ingredients for a grilled cheese.")
"""

