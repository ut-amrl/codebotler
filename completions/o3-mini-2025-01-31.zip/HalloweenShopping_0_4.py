name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return later.
    start_loc = get_current_location()

    # Initialize counters for the treats.
    orders = {"chocolate": 0, "caramel": 0, "gummy": 0}

    # Get all rooms and iterate over each office.
    all_rooms = get_all_rooms()
    for room in all_rooms:
        # Check if the room name indicates an office.
        if "office" in room.lower():
            go_to(room)
            # If there's someone in the office, ask them for their treat choices.
            if is_in_room("person"):
                for treat in orders:
                    question = ("How many " + treat +
                                " treats would you like? Choose from 0, 1, 2, 3, or 4")
                    response = ask("person", question, ["0", "1", "2", "3", "4"])
                    orders[treat] += int(response)

    # Return to the starting location.
    go_to(start_loc)

    # Tell the user the total number of treats needed.
    message = ("We need to buy {} chocolate, {} caramel, and {} gummy treats."
               .format(orders["chocolate"], orders["caramel"], orders["gummy"]))
    say(message)
"""

