name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Pick up the mail bin from the mail room.
    go_to("mail room")
    say("Picked up the mail bin")
    
    # Retrieve all rooms and filter for offices.
    all_rooms = get_all_rooms()
    offices_with_mail = []
    
    # Ask each office if they have mail to deliver.
    for room in all_rooms:
        # Check if the room name indicates an office
        if "office" in room and room != "mail room":
            go_to(room)
            response = ask("Office occupant", "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                # Ask them to put the mail in the bin.
                ask("Office occupant", "Please put the mail in the bin.", ["Done"])
                offices_with_mail.append(room)
    
    # Return to the mail room with the mail bin.
    go_to("mail room")
    
    # Inform at the mail room which offices provided mail.
    if offices_with_mail:
        mail_message = "Mail received from: " + ", ".join(offices_with_mail)
    else:
        mail_message = "No offices had mail to deliver."
    say(mail_message)
    
    # Put the mail bin back.
    say("Mail bin returned")
"""

