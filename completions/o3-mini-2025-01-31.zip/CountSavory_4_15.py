name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a beef jerky, cupcake, ham sandwich, or donut. Come back and tell me how many people preferred a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    savory_count = 0

    # Loop through each room that is an office.
    for room in rooms:
        if "office" in room.lower():
            go_to(room)
            # Check if there is someone in this office.
            if is_in_room("person"):
                response = ask("person", "Would you like a beef jerky, cupcake, ham sandwich, or donut?", 
                               ["beef jerky", "cupcake", "ham sandwich", "donut"])
                # Count savory options.
                if response in ["beef jerky", "ham sandwich"]:
                    savory_count += 1

    # Return to the starting location.
    go_to(start_loc)
    say(str(savory_count) + " people preferred a savory option")
"""

