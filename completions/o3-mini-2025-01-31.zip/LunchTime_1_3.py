name = "LunchTime"

prompt = "Go to Jill's office and ask her whether she's free to go for lunch tomorrow. If yes, ask her when (give her some reasonable times), and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    availability = ask("Jill", "Are you free to go for lunch tomorrow?", ["Yes", "No"])
    if availability == "Yes":
        time_choice = ask("Jill", "When are you free?", ["11 AM", "12 PM", "1 PM", "2 PM"])
        result_message = "Jill is free for lunch tomorrow at " + time_choice + "."
    else:
        result_message = "Jill is not free to go for lunch tomorrow."
    go_to(start_loc)
    say(result_message)
"""

