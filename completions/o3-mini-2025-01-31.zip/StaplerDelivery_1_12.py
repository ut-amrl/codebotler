name = "StaplerDelivery"

prompt = "Go to every printer room and check if there is a stapler. For each visited room that does not have a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get the list of all rooms.
    all_rooms = get_all_rooms()
    
    # Filter out the printer rooms; assume a room is a printer room if its name contains "printer room".
    printer_rooms = [room for room in all_rooms if "printer room" in room.lower()]
    
    # For each printer room, check if there is a stapler.
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            # If there is no stapler, go to the supply room to pick one up.
            go_to("supply room")
            # (Assume that picking up a stapler is implicit when in the supply room.)
            # Now, return to the printer room to deliver the stapler.
            go_to(room)
            say("Delivered a stapler to " + room)
    
    # Optionally, announce task completion.
    say("Stapler delivery task completed.")
"""

