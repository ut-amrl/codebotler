name = "LunchBreak"

prompt = "Ask if Alice and Bob in their offices are up for lunch. If yes, tell them that we'll meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    lunch_participants = {}
    
    # Define the people and their respective offices
    people_offices = {
        "Alice": "Alice's office",
        "Bob": "Bob's office"
    }
    
    # Ask each person if they're up for lunch
    for person, office in people_offices.items():
        go_to(office)
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            # If they are, inform them about meeting in the lobby
            say("We'll meet in the lobby in 5 minutes.")
            lunch_participants[person] = True
        else:
            lunch_participants[person] = False
    
    # Return to the original location
    go_to(start_loc)
    
    # Prepare a list of people joining for lunch
    joining = [person for person, is_joining in lunch_participants.items() if is_joining]
    if joining:
        joining_message = ", ".join(joining)
    else:
        joining_message = "no one"
    
    # Inform the current location about who is joining for lunch
    say("The following people are joining for lunch: " + joining_message)
"""

