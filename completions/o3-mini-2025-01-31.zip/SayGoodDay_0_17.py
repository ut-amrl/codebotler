name = "SayGoodDay"

prompt = "Go to every lab and if there is a person there, say Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Retrieve all rooms and filter for rooms that have "lab" in their name, case-insensitive.
    all_rooms = get_all_rooms()
    lab_rooms = [room for room in all_rooms if "lab" in room.lower()]
    
    for lab in lab_rooms:
        go_to(lab)
        if is_in_room("person"):
            say("Good Day!")
"""

