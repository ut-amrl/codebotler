name = "LunchBreak"

prompt = "Ask Alice and Bob if they are up for lunch. If they say yes, tell them that we will meet in the lobby in five minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting point so we can come back later.
    start_loc = get_current_location()
    
    # List to store the names of people joining for lunch.
    joining = []
    
    # List of people to ask.
    people = ["Alice", "Bob"]
    
    # Ask each person if they're up for lunch.
    for person in people:
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        # If they say "Yes",
"""

