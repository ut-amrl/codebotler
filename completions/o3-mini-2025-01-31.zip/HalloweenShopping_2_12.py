name = "HalloweenShopping"

prompt = "Visit every office. If there is a person in the office, ask the person to select 0 to 4 for each of the following categories: gummy, chocolate, or caramel. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Record the starting location so we can return here at the end.
    start_loc = get_current_location()
    
    # Counters for each candy type.
    total_gummy = 0
    total_chocolate = 0
    total_caramel = 0
    
    # Get the list of all rooms.
    all_rooms = get_all_rooms()
    
    # Define the options for the candy selections.
    options = ["0", "1", "2", "3", "4"]
    
    # Iterate through each room that could be an office.
    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            # Check if a person is present in the office.
            if is_in_room("person"):
                # Ask the resident about each type of candy.
                gummy_response = ask("person", "For gummy, please select a number (0-4):", options)
                chocolate_response = ask("person", "For chocolate, please select a number (0-4):", options)
                caramel_response = ask("person", "For caramel, please select a number (0-4):", options)
                
                # Accumulate the responses into totals.
                total_gummy += int(gummy_response)
                total_chocolate += int(chocolate_response)
                total_caramel += int(caramel_response)
    
    # Return to the original location.
    go_to(start_loc)
    
    # Construct the final message.
    final_message = (
        "We need to buy {} gummy, {} chocolate, and {} caramel."
        .format(total_gummy, total_chocolate, total_caramel)
    )
    
    # Tell the result.
    say(final_message)
"""

