name = "MailDelivery"

prompt = "Pick up a mail bin from the mail room. Go to every office and ask if they have any mail they'd like delivered. If so, ask them to put it in the mail bin. Finally, meet me in the mail room with all the mail. Place the mail bin back and tell me which offices they are from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Pick up the mail bin from the mail room.
    go_to("mail room")
    say("Picked up the mail bin.")
    
    # Get list of all rooms and filter out the offices.
    all_rooms = get_all_rooms()
    offices_with_mail = []
    for room in all_rooms:
        # Assume an office has the word "office" in its name and isn't the mail room.
        if "office" in room.lower() and room.lower() != "mail room":
            go_to(room)
            response = ask("", "Do you have any mail you'd like delivered?", ["Yes", "No"])
            if response == "Yes":
                # Ask them to put the mail in the mail bin.
                ask("", "Please put your mail in the mail bin.", ["Ok"])
                offices_with_mail.append(room)
    
    # Return to the mail room with the mail.
    go_to("mail room")
    # Place the mail bin back and report which offices had mail.
    message = "Mail delivered from: " + ", ".join(offices_with_mail) if offices_with_mail else "No offices had mail."
    say(message)
"""

