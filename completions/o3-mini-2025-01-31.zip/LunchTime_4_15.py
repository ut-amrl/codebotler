name = "LunchTime"

prompt = "Ask Jill in her office if she want to go for lunch tomorrow. If yes, give her some reasonable time options and ask her to choose a time. Finally come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    
    initial_response = ask("Jill", "Do you want to go for lunch tomorrow?", ["Yes", "No"])
    
    if initial_response == "Yes":
        time_response = ask("Jill", "Great! What time works for you?", ["12:00", "12:30", "1:00"])
        final_message = "Yes, lunch at " + time_response
    else:
        final_message = "No"
    
    go_to(start_loc)
    say("Jill said: " + final_message)
"""

