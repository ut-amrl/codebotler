name = "SetTemperature"

prompt = "The thermostat is currently set to 72 degrees. Go ask if Arjun thinks his office should be colder or warmer. Come back and tell me what temperature in degrees I should change the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location so we can return after asking Arjun.
    start_loc = get_current_location()
    
    # Go to Arjun's office to ask his opinion.
    go_to("Arjun's office")
    
    # Ask Arjun if his office should be colder or warmer.
    response = ask("Arjun", "Should your office be colder or warmer?", ["colder", "warmer"])
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Calculate the new thermostat setting based on his response.
    # The thermostat is currently set to 72 degrees.
    # If Arjun says "colder", lower by 2 degrees (to 70). If "warmer", raise by 2 degrees (to 74).
    if response == "colder":
        new_temperature = 70
    else:
        new_temperature = 74
    
    # Tell the user the new temperature to change the thermostat to.
    say("Set the thermostat to " + str(new_temperature) + " degrees.")
"""

