name = "StaplerDelivery"

prompt = "Make sure there is a stapler in each printer room. Otherwise, bring a stapler from the supply room to each printer room that currently lacks one."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    
    # Iterate over all rooms to check each printer room
    for room in rooms:
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                # If there is no stapler, bring one from the supply room.
                go_to("supply room")
                # Assume that we pick up a stapler here.
                go_to(room)
                say("A stapler has been delivered to " + room)
            else:
                say("The stapler is present in " + room)
    
    go_to(start_loc)
"""

