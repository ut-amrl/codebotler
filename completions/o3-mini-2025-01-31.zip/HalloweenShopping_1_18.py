name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0

    # Go through each room that is an office.
    for room in get_all_rooms():
        if "office" not in room.lower():
            continue  # skip non-office rooms
        
        go_to(room)
        # Check if anyone is present in the office.
        if is_in_room("person"):
            # Ask the person for their choices.
            caramel_response = ask("office occupant", "How many caramel would you like (choose 0-4)?", ["0", "1", "2", "3", "4"])
            chocolate_response = ask("office occupant", "How many chocolate would you like (choose 0-4)?", ["0", "1", "2", "3", "4"])
            gummy_response = ask("office occupant", "How many gummy would you like (choose 0-4)?", ["0", "1", "2", "3", "4"])
            
            # Convert the responses to integers and add to the running totals.
            total_caramel += int(caramel_response)
            total_chocolate += int(chocolate_response)
            total_gummy += int(gummy_response)
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Announce the total quantities needed.
    say("We need to buy " + str(total_caramel) +
        " caramel, " + str(total_chocolate) +
        " chocolate, and " + str(total_gummy) + " gummy.")
"""

