name = "HalloweenShopping"

prompt = "Go to every office and skip any office without a person in there. Otherwise, ask the person in the office to decide on how many, from zero to four, of the following they'd like: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy. "

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    
    # Initialize totals for each type
    totals = {"gummy": 0, "caramel": 0, "chocolate": 0}
    
    # Get all rooms and loop through those that are offices
    for room in get_all_rooms():
        if "office" not in room.lower():
            continue
        
        go_to(room)
        
        # Skip the office if there is no person present
        if not is_in_room("person"):
            continue
        
        # Attempt to extract the occupant's name from the room name, e.g. "Arjun's office"
        occupant = "person"
        if "'s" in room:
            occupant = room.split("'s")[0]
        
        # For each treat, ask how many they would like with options from 0 to 4
        for treat in ["gummy", "caramel", "chocolate"]:
            question = "How many {} would you like? (Choose from 0 to 4)".format(treat)
            response = ask(occupant, question, ["0", "1", "2", "3", "4"])
            totals[treat] += int(response)
    
    # Return to the starting location
    go_to(start_location)
    
    # Prepare the final message with the total numbers
    message = ("We need to buy {} gummy(s), {} caramel(s), and {} chocolate(s)."
               .format(totals["gummy"], totals["caramel"], totals["chocolate"]))
    say(message)
"""

