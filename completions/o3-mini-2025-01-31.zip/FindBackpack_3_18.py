name = "FindBackpack"

prompt = "Go through every conference room and find my backpack, then bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    backpack_found = False
    rooms = get_all_rooms()
    
    for room in rooms:
        # Check if the room name indicates it is a conference room.
        if "conference" in room.lower():
            go_to(room)
            if is_in_room("backpack"):
                backpack_found = True
                break

    if backpack_found:
        # Bring the backpack back by returning to the starting location.
        go_to(start_loc)
        say("Here is your backpack.")
    else:
        go_to(start_loc)
        say("I did not find your backpack.")
"""

