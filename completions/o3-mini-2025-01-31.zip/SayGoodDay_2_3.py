name = "SayGoodDay"

prompt = "Go through all the labs, and if there's a person inside, say 'Good Day!' to them."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Retrieve all rooms and filter the ones that are labs.
    all_rooms = get_all_rooms()
    labs = [room for room in all_rooms if "lab" in room.lower()]
    
    # Iterate through each lab.
    for lab in labs:
        go_to(lab)
        # If there is a person in the room, greet them.
        if is_in_room("person"):
            say("Good Day!")
"""

