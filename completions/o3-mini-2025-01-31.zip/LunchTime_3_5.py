name = "LunchTime"

prompt = "Ask Jill in her office whether she will be free to go for lunch tomorrow. If yes, offer her some reasonable time options to choose from, and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    
    free_response = ask("Jill", "Will you be free to go for lunch tomorrow?", ["Yes", "No"])
    
    if free_response == "Yes":
        time_response = ask("Jill", "Great! What time works best for you for lunch tomorrow?", ["11:30", "12:00", "12:30"])
        final_message = "Yes, I'm free. How about " + time_response + "?"
    else:
        final_message = "No"
    
    go_to(start_loc)
    say("Jill said: " + final_message)
"""

