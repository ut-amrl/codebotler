name = "GrilledCheese"

prompt = "Put together a compilation of grilled cheese ingredients. Head to Zarko's office, inquire about his available ingredients, and then update me on what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Define the essential grilled cheese ingredients.
    ingredients = ["bread", "cheese", "butter"]
    missing = []
    
    # Save current location to come back later.
    start_loc = get_current_location()
    
    # Go to Zarko's office.
    go_to("Zarko's office")
    
    # Ask Zarko about each grilled cheese ingredient.
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient} for making grilled cheese?", ["Yes", "No"])
        if response == "No":
            missing.append(ingredient)
    
    # Construct the update message.
    if missing:
        message = "Zarko is missing: " + ", ".join(missing)
    else:
        message = "Zarko has all the grilled cheese ingredients."
    
    # Update the supervisor.
    say(message)
    
    # Return to the original location.
    go_to(start_loc)
"""

