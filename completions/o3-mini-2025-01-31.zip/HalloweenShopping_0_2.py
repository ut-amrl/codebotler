name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Start at the current location so we can come back later.
    start_loc = get_current_location()
    
    total_chocolate = 0
    total_caramel = 0
    total_gummy = 0
    
    # Get a list of all rooms
    all_rooms = get_all_rooms()
    
    # Iterate over every room that is an office
    for room in all_rooms:
        # Check if the room name contains "office"
        if "office" in room.lower():
            go_to(room)
            # Check if there is anyone in the room
            if is_in_room("person"):
                # Ask for the number of each treat using options "0" to "4"
                chocolate = ask("occupant", "How many chocolates would you like? (0-4)", ["0", "1", "2", "3", "4"])
                caramel   = ask("occupant", "How many caramels would you like? (0-4)", ["0", "1", "2", "3", "4"])
                gummy     = ask("occupant", "How many gummies would you like? (0-4)", ["0", "1", "2", "3", "4"])
                
                # Convert responses to integers and add to the totals
                total_chocolate += int(chocolate)
                total_caramel   += int(caramel)
                total_gummy     += int(gummy)
    
    # After visiting all offices, go back to the starting location
    go_to(start_loc)
    # Announce the total numbers needed for each treat
    say("We need to buy " + str(total_chocolate) + " chocolates, " + 
        str(total_caramel) + " caramels, and " + 
        str(total_gummy) + " gummies.")
"""

