name = "LunchTime"

prompt = "Visit Jill's office and ask her if she would like to go for lunch tomorrow. If yes, ask her when (offer some reasonable lunch time options). Let me know what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Visit Jill's office
    go_to("Jill's office")
    
    # Ask if she would like to go for lunch tomorrow.
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    
    # Initialize a message variable to record what Jill said.
    if response == "Yes":
        # If yes, ask her when using reasonable lunch time options.
        time_choice = ask("Jill", "When would you like to have lunch tomorrow?", ["11am", "12pm", "1pm"])
        final_message = "Jill said yes and she would like to have lunch at " + time_choice + "."
    else:
        final_message = "Jill said no to lunch tomorrow."
    
    # Let me know what she said.
    say(final_message)
"""

