name = "FindBackpack"

prompt = "Check where I left my backpack in all of the conference rooms and bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember the starting location (assumed to be where "me" is)
    start_loc = get_current_location()
    
    # Get a list of all rooms and filter for conference rooms.
    all_rooms = get_all_rooms()
    found_backpack = False
    backpack_room = None
    
    for room in all_rooms:
        # Check if the room's name contains "conference" (case insensitive)
        if "conference" in room.lower():
            go_to(room)
            if is_in_room("backpack"):
                found_backpack = True
                backpack_room = room
                break  # Stop searching once the backpack is found.
    
    if found_backpack:
        # Bring the backpack back to the starting location.
        go_to(start_loc)
        say("I have brought your backpack from " + backpack_room)
    else:
        # If not found, inform the user.
        go_to(start_loc)
        say("I could not find your backpack in any conference room.")
"""

