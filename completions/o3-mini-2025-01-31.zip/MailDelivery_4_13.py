name = "MailDelivery"

prompt = "Take a mail bin from the mail room. For every office, ask if there is any mail to deliver and if someone says yes, ask them to put all mail in the bin. Finally find me at the mail room. Put the mail bin away, and tell me which offices had mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Remember our starting location in case it's needed later.
    start_loc = get_current_location()
    
    # Step 1: Go to the mail room and take the mail bin.
    go_to("mail room")
    # (Assume that being in the mail room means the mail bin is now in hand.)
    
    # Prepare a list to
"""

