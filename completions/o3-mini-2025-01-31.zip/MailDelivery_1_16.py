name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to the mail room and pick up the mail bin.
    go_to("mail room")
    # Assume we've picked up the mail bin here.
    
    # Get all rooms and filter for offices (rooms with "office" in the name, excluding the mail room).
    all_rooms = get_all_rooms()
    offices = [room for room in all_rooms if "office" in room.lower() and room.lower() != "mail room"]
    
    mail_offices = []
    
    # For each office, ask if they have mail to deliver.
    for office in offices:
        go_to(office)
        reply = ask(office, "Do you have any mail to deliver?", ["Yes", "No"])
        if reply == "Yes":
            # Ask them to put their mail in the bin.
            _ = ask(office, "Please put your mail in the
"""

