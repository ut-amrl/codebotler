name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Step 1: Go to the mail room and pick up a mail bin.
    go_to("mail room")
    say("Picked up a mail bin.")
    
    # Step 2: Ask at every office if they have mail to deliver.
    offices_with_mail = []
    # Assume that all
"""

