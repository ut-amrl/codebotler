name = "SayGoodDay"

prompt = "Visit each lab and if someone is present, greet them with a pleasant Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Get a list of all rooms and filter only the labs
    all_rooms = get_all_rooms()
    labs = [room for room in all_rooms if "lab" in room.lower()]
    
    # Visit each lab, check if someone is present, and greet them if so
    for lab in labs:
        go_to(lab)
        if is_in_room("person"):
            say("Good Day!")
"""

