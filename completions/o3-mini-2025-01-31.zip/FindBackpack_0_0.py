name = "FindBackpack"

prompt = "Check where I left my backpack in all of the conference rooms and bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the starting location where the backpack should be brought back to.
    start_loc = get_current_location()
    
    # Get all available rooms.
    all_rooms = get_all_rooms()
    
    # Filter out the conference rooms (assuming the room name includes the word "conference")
    conference_rooms = [room for room in all_rooms if "conference" in room.lower()]
    
    backpack_found = False
    found_room = ""
    
    # Check each conference room for the backpack
    for room in conference_rooms:
        go_to(room)
        if is_in_room("backpack"):
            backpack_found = True
            found_room = room
            break
    
    # If the backpack is found, assume it is picked up, then return to starting location.
    if backpack_found:
        # Bring the backpack back by going to the starting location.
        go_to(start_loc)
        say("I have brought your backpack from " + found_room)
    else:
        say("Your backpack was not found in any conference room")
"""

