name = "GrilledCheese"

prompt = "Put together a list of grilled cheese ingredients. Head to Zarko's office and inquire about his available ingredients. Return and inform me of what he is missing."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Step 1: Define the grilled cheese ingredients
    ingredients = ["bread", "cheese", "butter"]

    # Save the starting location.
    start_loc = get_current_location()

    # Step 2: Go to Zarko's office.
    go_to("Zarko's office")
    
    # Step 3: Inquire about the availability of each ingredient.
    available = {}
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        available[ingredient] = (response == "Yes")
    
    # Identify which ingredients are missing.
    missing = [item for item, has_item in available.items() if not has_item]
    
    # Step 4: Return to the starting location.
    go_to(start_loc)
    
    # Step 5: Inform what ingredients he is missing.
    if missing:
        say("Zarko is missing: " + ", ".join(missing))
    else:
        say("Zarko has all the grilled cheese ingredients.")
"""

