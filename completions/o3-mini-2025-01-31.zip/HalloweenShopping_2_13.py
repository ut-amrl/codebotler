name = "HalloweenShopping"

prompt = "Visit every office. If there is a person in the office, ask the person to select 0 to 4 for each of the following categories: gummy, chocolate, or caramel. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()

    # Initialize counters for each candy category.
    total_gummy = 0
    total_chocolate = 0
    total_caramel = 0

    # Iterate over all rooms and filter for offices.
    for room in get_all_rooms():
        if "office" not in room.lower():
            continue

        go_to(room)
        # Check if there is a person in the office.
        if is_in_room("person"):
            # Ask the person to select a number from 0 to 4 for each candy category.
            gummy_response = ask("person", "Select a number (0-4) for gummy", ["0", "1", "2", "3", "4"])
            chocolate_response = ask("person", "Select a number (0-4) for chocolate", ["0", "1", "2", "3", "4"])
            caramel_response = ask("person", "Select a number (0-4) for caramel", ["0", "1", "2", "3", "4"])

            total_gummy += int(gummy_response)
            total_chocolate += int(chocolate_response)
            total_caramel += int(caramel_response)

    # Return to the starting location.
    go_to(start_loc)
    
    # Communicate the result.
    say("We need to buy {} gummy, {} chocolate, and {} caramel candies.".format(
        total_gummy, total_chocolate, total_caramel))
"""

