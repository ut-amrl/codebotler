name = "LunchBreak"

prompt = "Ask Alice and Bob if they are up for lunch. If they say yes, tell them that we will meet in the lobby in five minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Record the starting location to return later.
    start_loc = get_current_location()

    # List to keep track of people joining for lunch.
    joining = []

    # Define the people to ask.
    for person in ["Alice", "Bob"]:
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            joining.append(person)
            say("We will meet in the lobby in five minutes, " + person)

    # Return to the starting location.
    go_to(start_loc)

    # Tell the user who all are joining for lunch.
    if joining:
        message = "Joining for lunch: " + ", ".join(joining)
    else:
        message = "No one is joining for lunch."
    say(message)
"""

