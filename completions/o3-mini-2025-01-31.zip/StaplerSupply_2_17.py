name = "StaplerSupply"

prompt = "Go find all printer rooms that do not have a stapler. Come back and tell me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    missing_stapler_rooms = []
    for room in get_all_rooms():
        # Identify printer rooms by checking if "printer" is in the room name (case-insensitive).
        if "printer" in room.lower():
            go_to(room)
            # Check if the room does not have a stapler.
            if not is_in_room("stapler"):
                missing_stapler_rooms.append(room)
    go_to(start_loc)
    if missing_stapler_rooms:
        message = "The following printer rooms do not have a stapler: " + ", ".join(missing_stapler_rooms)
    else:
        message = "All printer rooms have a stapler."
    say(message)
"""

