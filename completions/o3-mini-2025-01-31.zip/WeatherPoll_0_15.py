name = "WeatherPoll"

prompt = "Go to the main entrance, and wait for someone to show up. Ask them if they feel it is hot out. Repeat this until you have 10 responses, and then come back and tell me what percent of people think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    
    responses = []
    while len(responses) < 10:
        # Check if someone is in the room
        if is_in_room("person"):
            # Ask the person if they feel it is hot out
            answer = ask("", "Do you feel it is hot out?", ["Yes", "No"])
            responses.append(answer)
        time.sleep(1)
    
    # Compute percent of people who think it's hot out
    yes_count = responses.count("Yes")
    percent = (yes_count * 100) / len(responses)
    
    # Return to the start location and report the result
    go_to(start_loc)
    say("Approximately " + str(percent) + "% of people think it is hot out.")
"""

