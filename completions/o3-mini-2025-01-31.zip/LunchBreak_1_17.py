name = "LunchBreak"

prompt = "Ask Alice in her office if she is up for lunch, and if yes, tell her that we will meet in the lobby in 5 minutes. Do the same for Bob. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Record our starting location to return later.
    start_loc = get_current_location()
    lunch_joiners = []
    
    # Process Alice's response.
    go_to("Alice's office")
    response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if response == "Yes":
        say("We will meet in the lobby in 5 minutes.")
        lunch_joiners.append("Alice")
    
    # Process Bob's response.
    go_to("Bob's office")
    response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if response == "Yes":
        say("We will meet in the lobby in 5 minutes.")
        lunch_joiners.append("Bob")
    
    # Return to the starting location.
    go_to(start_loc)
    
    # Report who is joining for lunch.
    if lunch_joiners:
        say("Joining for lunch: " + ", ".join(lunch_joiners))
    else:
        say("No one is joining for lunch.")
"""

