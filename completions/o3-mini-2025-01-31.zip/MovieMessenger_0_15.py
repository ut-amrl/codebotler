name = "MovieMessenger"

prompt = "Ask Sally in her office if she wants to go to the cinema with Mark. Go to Mark's office and tell him Sally's answer. If Sally says yes, ask Mark whether he wants to leave at 4PM, 5PM, or 6PM - then go tell Sally what time Mark is leaving."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Go to Sally's office to ask her the invitation question.
    go_to("Sally's office")
    sally_response = ask("Sally", "Do you want to go to the cinema with Mark?", ["Yes", "No"])
    
    # Go to Mark's office and tell him Sally's answer.
    go_to("Mark's office")
    say("Sally said: " + sally_response)
    
    # If Sally said yes, ask Mark for the departure time.
    if sally_response == "Yes":
        mark_time = ask("Mark", "Do you want to leave at 4PM, 5PM, or 6PM?", ["4PM", "5PM", "6PM"])
        go_to("Sally's office")
        say("Mark is leaving at " + mark_time)
"""

