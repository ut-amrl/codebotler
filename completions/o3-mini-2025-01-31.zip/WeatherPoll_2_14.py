name = "WeatherPoll"

prompt = "Go wait for someone at the main entrance. Ask them if they feel it is hot out, then wait for the next person and ask the same question. Do this until you have ten responses, then come back and report the percentage of people who think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time  # needed to add delays during waiting
    
    start_loc = get_current_location()
    go_to("main entrance")
    
    responses = []
    while len(responses) < 10:
        # Wait until someone is in the room
        while not is_in_room("person"):
            time.sleep(1)
        # Ask the person the question and store their response
        response = ask("person", "Do you feel it is hot out?", ["Yes", "No"])
        responses.append(response)
        
        # Wait a short while to ensure the current person leaves before the next check
        time.sleep(2)
    
    # Calculate percentage of people who said "Yes"
    yes_count = responses.count("Yes")
    percentage = (yes_count / 10) * 100
    
    # Go back from the entrance to report the results
    go_to(start_loc)
    say("Percentage of people who think it is hot out: " + str(percentage) + "%")
"""

