name = "StaplerDelivery"

prompt = "Check if every printer room has a stapler. If not, put a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    
    for room in all_rooms:
        # Identify printer rooms by checking for the substring "printer" (case insensitive)
        if "printer" in room.lower():
            go_to(room)
            # Check if a stapler is present in the printer room
            if not is_in_room("stapler"):
                # Go to the supply room and "pick up" a stapler
                go_to("supply room")
                say("Picked up a stapler from the supply room.")
                # Return to the printer room and "place" the stapler
                go_to(room)
                say("Placed a stapler in " + room + ".")
    
    go_to(start_loc)
"""

