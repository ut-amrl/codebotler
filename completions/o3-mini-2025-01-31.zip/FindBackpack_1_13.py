name = "FindBackpack"

prompt = "Search all the conference rooms for my backpack and return it to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    found_room = None

    # Search each conference room for the backpack.
    for room in rooms:
        if "conference" not in room.lower():
            continue
        go_to(room)
        if is_in_room("backpack"):
            found_room = room
            break

    # Return to the starting location.
    go_to(start_loc)

    if found_room:
        say("I found your backpack in " + found_room + " and have returned with it.")
    else:
        say("I did not find your backpack in any conference room.")
"""

