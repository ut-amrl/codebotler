name = "WeatherPoll"

prompt = "Go to the main entrance. When someone shows up, ask them if they feel that it's hot out. Do this until you collect ten people's responses. Come back and tell me which percent of people think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    import time
    start_loc = get_current_location()
    go_to("main entrance")
    responses = []
    
    while len(responses) < 10:
        # Wait until someone shows up in the room
        if is_in_room("person"):
            # Ask the person for their opinion
            response = ask("person", "Do you feel that it's hot out?", ["Yes", "No"])
            responses.append(response)
        else:
            time.sleep(1)  # Wait a bit before checking again
    
    # Calculate percentage of "Yes" responses
    yes_count = responses.count("Yes")
    percent_yes = (yes_count / len(responses)) * 100
    
    go_to(start_loc)
    say(str(percent_yes) + " percent of people think it's hot out.")
"""

