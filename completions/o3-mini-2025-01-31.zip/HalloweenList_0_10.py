name = "HalloweenList"

prompt = "Go to every office, and if there is anyone there, ask if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    # Counters for each candy type.
    orders = {"chocolate": 0, "caramel": 0, "gummy": 0}
    
    # Get all rooms and filter for offices.
    rooms = get_all_rooms()
    for room in rooms:
        if "office" in room.lower():
            go_to(room)
            # Check if there is anyone in the office.
            if is_in_room("person"):
                # Ask the person for their preference.
                response = ask("person", "Would you like a chocolate, caramel, or gummy?", 
                               ["chocolate", "caramel", "gummy"])
                # Increase the count for the chosen option.
                orders[response] += 1

    # Go back to the starting location.
    go_to(start_loc)
    
    # Construct a message summarizing the orders.
    message = ("Chocolates: " + str(orders["chocolate"]) +
               ", Caramels: " + str(orders["caramel"]) +
               ", Gummies: " + str(orders["gummy"]))
    say(message)
"""

