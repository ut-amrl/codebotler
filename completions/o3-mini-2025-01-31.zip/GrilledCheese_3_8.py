name = "GrilledCheese"

prompt = "Compile the necessary ingredients for grilled cheese. Go to Zarko's office, ask him about his available items, and then report back to me which items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # The necessary ingredients for grilled cheese are bread, cheese, and butter.
    start_loc = get_current_location()
    go_to("Zarko's office")
    
    missing_items = []
    
    response = ask("Zarko", "Do you have bread?", ["Yes", "No"])
    if response == "No":
        missing_items.append("bread")
        
    response = ask("Zarko", "Do you have cheese?", ["Yes", "No"])
    if response == "No":
        missing_items.append("cheese")
        
    response = ask("Zarko", "Do you have butter?", ["Yes", "No"])
    if response == "No":
        missing_items.append("butter")
        
    go_to(start_loc)
    
    if missing_items:
        missing_str = ", ".join(missing_items)
        say("Zarko does not have: " + missing_str)
    else:
        say("Zarko has all the necessary ingredients for grilled cheese.")
"""

