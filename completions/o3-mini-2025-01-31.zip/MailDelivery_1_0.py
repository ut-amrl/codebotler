name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 1500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Step 1: Go to the mail room to pick up a mail bin.
    go_to("mail room")
    say("Picked up a mail bin.")

    # Step 2: Ask at every office if they have any mail to deliver.
    offices_with_mail = []
    all_rooms = get_all_rooms()
    # We assume that office names contain the word "office" (case-insensitive)
    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            # Ask the person in the office if they have mail to deliver.
            response = ask(room, "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                # If yes, ask them to put the mail in the bin.
                ask(room, "Please put your mail in the bin.", ["Ok"])
                offices_with_mail.append(room)

    # Step 3: Return to the mail room with the mail.
    go_to("mail room")

    # Step 4: At the mail room, announce which offices the mail came from.
    if offices_with_mail:
        message = "Mail from the following offices: " + ", ".join(offices_with_mail)
    else:
        message = "No offices had any mail to deliver."
    say(message)

    # Step 5: Put the mail bin back.
    say("The mail bin has been put back.")
"""

