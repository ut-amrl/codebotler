name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()

    # Go to the mail room and pick up the mail bin
    go_to("mail room")
    say("Picking up the mail bin.")

    rooms = get_all_rooms()
    offices_with_mail = []

    # Check each office to see if they have mail
    for room in rooms:
        if "office" in room.lower():
            go_to(room)
            response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                say("Please place your mail in the bin.")
                offices_with_mail.append(room)

    # Return to the mail room with collected mail
    go_to("mail room")

    if offices_with_mail:
        offices_list = ', '.join(offices_with_mail)
        say(f"I collected mail from the following offices: {offices_list}.")
    else:
        say("I did not collect any mail from the offices.")

    say("Putting the mail bin back.")
    
    # Return to initial location
    go_to(start_loc)
"""

