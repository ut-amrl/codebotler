name = "GrilledCheese"

prompt = "Compile the necessary ingredients for grilled cheese. Go to Zarko's office, ask him about his available items, and then report back to me which items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheese", "butter"]
    unavailable_ingredients = []

    go_to("Zarko's office")
    for item in ingredients:
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "No":
            unavailable_ingredients.append(item)

    start_loc = get_current_location()
    go_to(start_loc)

    if unavailable_ingredients:
        message = "Zarko does not have: " + ", ".join(unavailable_ingredients)
    else:
        message = "Zarko has all needed ingredients."

    say(message)
"""

