name = "GrilledCheese"

prompt = "Compile a list of ingredients for grilled cheese. Go to Zarko's office, and ask him which of them he has. Come back and tell me what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheese", "butter"]
    start_loc = get_current_location()
    go_to("Zarko's office")
    unavailable_ingredients = []
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response == "No":
            unavailable_ingredients.append(ingredient)
    go_to(start_loc)
    if unavailable_ingredients:
        missing_items = ", ".join(unavailable_ingredients)
        say("Zarko does not have: " + missing_items)
    else:
        say("Zarko has all the ingredients.")
"""

