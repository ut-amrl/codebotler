name = "MailDelivery"

prompt = "Grab a mail bin from the mail room. Go to every office, and ask if they have any mail to deliver. Ask them to put all mail in the bin if there is any. Put the mail bin back in the mail room and report which offices the mail is from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices_with_mail = []

    # Get mail bin from mail room
    go_to("mail room")
    say("I have picked up the mail bin.")

    # Visit each office
    rooms = get_all_rooms()
    for room in rooms:
        if "office" in room.lower():
            go_to(room)
            if is_in_room("person"):
                response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
                if response == "Yes":
                    say("Please put your mail in the bin.")
                    offices_with_mail.append(room)

    # Return mail bin to mail room
    go_to("mail room")
    say("I am returning the mail bin.")

    # Report offices that had mail
    go_to(start_loc)
    if offices_with_mail:
        offices_list = ", ".join(offices_with_mail)
        say("Mail collected from the following offices: " + offices_list)
    else:
        say("There was no mail to collect from any office.")
"""

