name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0

    for room in rooms:
        if "office" in room:
            go_to(room)
            if not is_in_room("person"):
                continue
            gummy = int(ask("", "How many gummy candies would you like?", ["0", "1", "2", "3", "4"]))
            caramel = int(ask("", "How many caramel candies would you like?", ["0", "1", "2", "3", "4"]))
            chocolate = int(ask("", "How many chocolate candies would you like?", ["0", "1", "2", "3", "4"]))
            total_gummy += gummy
            total_caramel += caramel
            total_chocolate += chocolate

    go_to(start_loc)
    say("We need to buy " + str(total_gummy) + " gummy candies, " +
        str(total_caramel) + " caramel candies, and " +
        str(total_chocolate) + " chocolate candies.")
"""

