name = "LunchTime"

prompt = "Visit Jill's office and ask her if she would like to go for lunch tomorrow. If yes, ask her when (offer some reasonable lunch time options). Let me know what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    
    if response == "Yes":
        time_response = ask("Jill", "What time would you prefer?", ["11:30 AM", "12:00 PM", "12:30 PM", "1:00 PM"])
        final_message = f"Jill said yes to lunch, at {time_response}."
    else:
        final_message = "Jill said no to lunch tomorrow."
    
    go_to(start_loc)
    say(final_message)
"""

