name = "GetDrink"

prompt = "Go to the lobby and ask any person there if they want iced tea, lemonade or a bottle of water. Bring whatever they asked for back from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("lobby")
    drink_choice = ask("", "Which drink would you like?", ["iced tea", "lemonade", "bottle of water"])
    go_to("kitchen")
    say("Collecting " + drink_choice)
    go_to(start_loc)
    say("Here is the " + drink_choice)
"""

