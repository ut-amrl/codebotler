name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("mail room")
    say("Picking up the mail bin.")
    offices_with_mail = []

    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" in room:
            go_to(room)
            person = room.split("'s office")[0]  # assuming office named as "Person's office"
            response = ask(person, "Do you have mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                say("Please put your mail in the bin.")
                offices_with_mail.append(room)

    go_to("mail room")
    if offices_with_mail:
        message = "I have collected mail from "
        message += ", ".join(offices_with_mail)
    else:
        message = "I did not collect mail from any offices."

    say(message)
    say("Placing the mail bin back.")
    go_to(start_loc)
"""

