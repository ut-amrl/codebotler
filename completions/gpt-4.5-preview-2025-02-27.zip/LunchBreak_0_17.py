name = "LunchBreak"

prompt = "Ask if Alice and Bob in their offices are up for lunch. If yes, tell them that we'll meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joining_for_lunch = []
    
    # Check with Alice
    go_to("Alice's office")
    response_alice = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if response_alice == "Yes":
        say("Great! We'll meet in the lobby in 5 minutes.")
        joining_for_lunch.append("Alice")

    # Check with Bob
    go_to("Bob's office")
    response_bob = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if response_bob == "Yes":
        say("Great! We'll meet in the lobby in 5 minutes.")
        joining_for_lunch.append("Bob")

    # Return and report
    go_to(start_loc)
    if joining_for_lunch:
        message = ", ".join(joining_for_lunch) + " will be joining for lunch."
    else:
        message = "No one is joining for lunch."
    say(message)
"""

