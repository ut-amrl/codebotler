name = "StaplerSupply"

prompt = "Check all printer rooms for staplers, and come back and tell me which ones do not have any staplers."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms_without_staplers = []
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "printer room" in room:
            go_to(room)
            if not is_in_room("stapler"):
                rooms_without_staplers.append(room)
    go_to(start_loc)
    if rooms_without_staplers:
        rooms_list = ", ".join(rooms_without_staplers)
        say("These printer rooms do not have staplers: " + rooms_list)
    else:
        say("All printer rooms have staplers.")
"""

