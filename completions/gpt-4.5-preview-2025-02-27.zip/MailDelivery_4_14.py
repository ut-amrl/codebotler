name = "MailDelivery"

prompt = "Take a mail bin from the mail room. For every office, ask if there is any mail to deliver and if someone says yes, ask them to put all mail in the bin. Finally find me at the mail room. Put the mail bin away, and tell me which offices had mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    offices_with_mail = []
    go_to("mail room")
    say("Taking a mail bin from the mail room.")
    
    all_rooms = get_all_rooms()
    office_rooms = [room for room in all_rooms if "office" in room.lower()]

    for office in office_rooms:
        go_to(office)
        response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
        if response == "Yes":
            say("Please put all your mail into the bin.")
            offices_with_mail.append(office)

    go_to("mail room")
    say("Putting the mail bin away.")

    user_location = get_current_location()
    if not is_in_room("user"):
        go_to("user location")

    if offices_with_mail:
        say("The following offices had mail: " + ", ".join(offices_with_mail))
    else:
        say("No offices had mail.")
"""

