name = "GetDrink"

prompt = "Ask any visitor in the lobby if they would like a bottle of water, iced tea, or lemonade. Bring what they ask for from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("lobby")
    drink = ask("visitor", "Would you like something to drink?", ["bottle of water", "iced tea", "lemonade"])
    go_to("kitchen")
    say("I am picking up " + drink + " for the visitor.")
    go_to("lobby")
    say("Here is your " + drink + ".")
    go_to(start_loc)
"""

