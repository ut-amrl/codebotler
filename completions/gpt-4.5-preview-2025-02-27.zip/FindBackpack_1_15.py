name = "FindBackpack"

prompt = "Search all the conference rooms for my backpack and return it to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    for room in rooms:
        if "conference" in room:
            go_to(room)
            if is_in_room("backpack"):
                say("I found your backpack in " + room)
                go_to(start_loc)
                say("Here is your backpack.")
                return
    go_to(start_loc)
    say("I could not find your backpack in any conference room.")
"""

