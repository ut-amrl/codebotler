name = "HalloweenList"

prompt = "Check with every occupied office to see if the occupant would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0

    for room in rooms:
        go_to(room)
        if is_in_room("person"):
            choices = ["chocolate", "caramel", "gummy"]
            response = ask("", "Which snack would you like?", choices)
            if response == "chocolate":
                chocolate_count += 1
            elif response == "caramel":
                caramel_count += 1
            elif response == "gummy":
                gummy_count += 1

    go_to(start_loc)
    say("We need to buy {} chocolates, {} caramels, and {} gummies.".format(chocolate_count, caramel_count, gummy_count))
"""

