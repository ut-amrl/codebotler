name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a beef jerky, cupcake, ham sandwich, or donut. Come back and tell me how many people preferred a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    savory_options = ["beef jerky", "ham sandwich"]
    sweet_options = ["cupcake", "donut"]
    rooms = get_all_rooms()
    savory_count = 0
    for room in rooms:
        if "office" not in room:
            continue
        go_to(room)
        if is_in_room("person"):
            choice = ask("", "Would you like beef jerky, cupcake, ham sandwich, or donut?", savory_options + sweet_options)
            if choice in savory_options:
                savory_count += 1
    go_to(start_loc)
    say(f"{savory_count} people preferred a savory option.")
"""

