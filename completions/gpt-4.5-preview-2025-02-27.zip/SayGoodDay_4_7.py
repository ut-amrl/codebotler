name = "SayGoodDay"

prompt = "Visit every lab space and when encountering an individual, tell them a Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    lab_rooms = get_all_rooms()
    for room in lab_rooms:
        if "lab" in room.lower():
            go_to(room)
            if is_in_room("person"):
                say("Good Day!")
"""

