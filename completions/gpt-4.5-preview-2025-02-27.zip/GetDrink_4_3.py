name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. If they want a bottle of water, bring it to them from the kitchen. If they want iced tea, bring it to them from the kitchen. If they want lemonade, bring it to them from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    go_to("lobby")
    choice = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["Bottle of water", "Iced tea", "Lemonade"])
    go_to("kitchen")
    if choice == "Bottle of water":
        item = "bottle of water"
    elif choice == "Iced tea":
        item = "iced tea"
    elif choice == "Lemonade":
        item = "lemonade"
    say(f"I am picking up {item} from the kitchen.")
    go_to("lobby")
    say(f"Here is your {item}.")
"""

