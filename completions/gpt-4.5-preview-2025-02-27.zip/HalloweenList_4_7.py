name = "HalloweenList"

prompt = "Go to every office with a person, and ask them if they would like a chocolate, caramel, or gummy, then come back and tell me how many of each people asked for."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0
    
    for room in rooms:
        go_to(room)
        if is_in_room("person") and "office" in room.lower():
            choice = ask("", "Which candy would you like?", ["Chocolate", "Caramel", "Gummy"])
            if choice == "Chocolate":
                chocolate_count += 1
            elif choice == "Caramel":
                caramel_count += 1
            elif choice == "Gummy":
                gummy_count += 1
    
    go_to(start_loc)
    message = (f"People requested: {chocolate_count} chocolate, "
               f"{caramel_count} caramel, and {gummy_count} gummy candies.")
    say(message)
"""

