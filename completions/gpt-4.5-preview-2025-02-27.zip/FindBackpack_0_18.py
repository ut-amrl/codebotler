name = "FindBackpack"

prompt = "Check where I left my backpack in all of the conference rooms and bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    backpack_found = False
    for room in rooms:
        if "conference room" in room:
            go_to(room)
            if is_in_room("backpack"):
                backpack_found = True
                say("Backpack found in " + room)
                break
    if backpack_found:
        say("I've picked up your backpack and I'm bringing it back.")
        go_to(start_loc)
        say("Here's your backpack.")
    else:
        go_to(start_loc)
        say("I couldn't find your backpack in any conference room.")
"""

