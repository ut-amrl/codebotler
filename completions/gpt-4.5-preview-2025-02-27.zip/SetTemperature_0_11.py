name = "SetTemperature"

prompt = "The thermostat is set to 72 degrees. Go to Arjun's office and ask him if he'd like it to be warmer or colder. Come back and tell me what temperature I should set it to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    current_loc = get_current_location()
    go_to("Arjun's office")
    preference = ask("Arjun", "The thermostat is currently set to 72 degrees. Would you prefer it warmer or colder?", ["Warmer", "Colder"])
    
    if preference == "Warmer":
        new_temp = 74
    else:
        new_temp = 70
    
    go_to(current_loc)
    say(f"Arjun would like the thermostat set to {new_temp} degrees.")
"""

