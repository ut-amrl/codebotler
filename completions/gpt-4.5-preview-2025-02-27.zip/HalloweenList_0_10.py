name = "HalloweenList"

prompt = "Go to every office, and if there is anyone there, ask if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    chocolate = 0
    caramel = 0
    gummy = 0

    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                response = ask("", "Which candy would you like?", ["Chocolate", "Caramel", "Gummy"])
                if response == "Chocolate":
                    chocolate += 1
                elif response == "Caramel":
                    caramel += 1
                elif response == "Gummy":
                    gummy += 1

    go_to(start_loc)
    summary = f"We need to buy {chocolate} chocolate, {caramel} caramel, and {gummy} gummy candies."
    say(summary)
"""

