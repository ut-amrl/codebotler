name = "HalloweenShopping"

prompt = "Visit every office. If there is a person in the office, ask the person to select 0 to 4 for each of the following categories: gummy, chocolate, or caramel. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    gummy_total = 0
    chocolate_total = 0
    caramel_total = 0
    
    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                gummy = int(ask("", "How many gummies do you want?", ["0", "1", "2", "3", "4"]))
                chocolate = int(ask("", "How many chocolates do you want?", ["0", "1", "2", "3", "4"]))
                caramel = int(ask("", "How many caramels do you want?", ["0", "1", "2", "3", "4"]))

                gummy_total += gummy
                chocolate_total += chocolate
                caramel_total += caramel

    go_to(start_loc)
    say("We need to buy " + str(gummy_total) + " gummies, " + str(chocolate_total) + " chocolates, and " + str(caramel_total) + " caramels.")
"""

