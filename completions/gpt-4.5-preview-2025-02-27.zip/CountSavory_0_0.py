name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a cupcake, ham sandwich, donut, or beef jerky. Come back and tell me how many people chose a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    savory_options = ["ham sandwich", "beef jerky"]
    sweet_options = ["cupcake", "donut"]
    savory_count = 0
    
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    
    for room in all_rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                response = ask("", "Which snack would you like?", savory_options + sweet_options)
                if response in savory_options:
                    savory_count += 1
                    
    go_to(start_loc)
    say(f"{savory_count} people chose a savory option.")
"""

