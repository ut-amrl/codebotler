name = "LunchBreak"

prompt = "Ask Alice in her office if she is up for lunch, and if yes, tell her that we will meet in the lobby in 5 minutes. Do the same for Bob. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    attendees = []

    # Check with Alice
    go_to("Alice's office")
    response_alice = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if response_alice == "Yes":
        say("Great! We'll meet in the lobby in 5 minutes.")
        attendees.append("Alice")

    # Check with Bob
    go_to("Bob's office")
    response_bob = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if response_bob == "Yes":
        say("Great! We'll meet in the lobby in 5 minutes.")
        attendees.append("Bob")

    # Return to original location
    go_to(start_loc)

    # Report who is joining
    if attendees:
        attendee_names = ", ".join(attendees)
        say("The following people are joining for lunch: " + attendee_names)
    else:
        say("No one is joining for lunch.")
"""

