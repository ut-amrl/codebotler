name = "FindBackpack"

prompt = "Go through every conference room and find my backpack, then bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    
    for room in rooms:
        if "conference room" in room.lower():
            go_to(room)
            if is_in_room("backpack"):
                say("Found your backpack in " + room)
                break
    
    go_to(start_loc)
    say("Here is your backpack.")
"""

