name = "MovieMessenger"

prompt = "Ask Sally if she wants to go to the cinema with Mark. Tell Mark what Sally said, and if yes, ask Mark whether he wants to leave at 4PM, 5PM, or 6PM. Then then go tell Sally what Mark said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    # Save the initial location
    start_loc = get_current_location()
    
    # Ask Sally if she wants to go to the cinema with Mark
    go_to("Sally's office")
    sally_response = ask("Sally", "Do you want to go to the cinema with Mark?", ["Yes", "No"])
    
    # Tell Mark Sally's response
    go_to("Mark's office")
    say("Sally said: " + sally_response)
    
    # If Sally said yes, ask Mark about the time
    if sally_response == "Yes":
        mark_response = ask("Mark", "What time do you want to leave?", ["4PM", "5PM", "6PM"])
        
        # Tell Sally Mark's chosen time
        go_to("Sally's office")
        say("Mark said he wants to leave at " + mark_response)
    
    # Return to starting location
    go_to(start_loc)
"""

