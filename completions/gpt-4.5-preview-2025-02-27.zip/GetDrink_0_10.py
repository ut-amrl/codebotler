name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. Bring what they ask for from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    go_to("lobby")
    drink_choice = ask("visitor", "Would you like a drink?", ["bottle of water", "iced tea", "lemonade"])
    go_to("kitchen")
    say("I'm picking up " + drink_choice + " for the visitor.")
    go_to("lobby")
    say("Here is your " + drink_choice + ".")
"""

