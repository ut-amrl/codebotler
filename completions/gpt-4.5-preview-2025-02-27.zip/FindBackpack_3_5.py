name = "FindBackpack"

prompt = "Go through every conference room and find my backpack, then bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    conference_rooms = [room for room in get_all_rooms() if "conference room" in room.lower()]
    for room in conference_rooms:
        go_to(room)
        if is_in_room("backpack"):
            say("I found your backpack in " + room)
            break
    else:
        say("I couldn't find your backpack in any conference room.")
        go_to(start_loc)
        return
    go_to(start_loc)
    say("I've brought your backpack back.")
"""

