name = "LunchTime"

prompt = "Ask Jill in her office whether she will be free to go for lunch tomorrow. If yes, offer her some reasonable time options to choose from, and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    response = ask("Jill", "Will you be free to go for lunch tomorrow?", ["Yes", "No"])
    if response == "Yes":
        time_choice = ask("Jill", "What time would you prefer for lunch?", ["12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM"])
        final_message = "Jill said she's free for lunch tomorrow at " + time_choice
    else:
        final_message = "Jill said she's not free for lunch tomorrow."
    go_to(start_loc)
    say(final_message)
"""

