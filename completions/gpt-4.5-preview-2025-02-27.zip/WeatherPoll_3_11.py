name = "WeatherPoll"

prompt = "Go to the main entrance. If there is no one there, wait for someone. Ask them if they feel it is hot out. Ask 10 people this same question until you have 10 replies. Finally, come back and tell me the percentage of people that think it's hot outside."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    
    hot_count = 0
    total_people = 10

    replies = 0
    while replies < total_people:
        if not is_in_room("person"):
            continue
        response = ask("", "Do you feel it is hot outside?", ["Yes", "No"])
        if response == "Yes":
            hot_count += 1
        replies += 1
    
    hot_percentage = (hot_count / total_people) * 100
    go_to(start_loc)
    say(f"{hot_percentage}% of people think it's hot outside.")
"""

