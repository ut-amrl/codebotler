name = "SayGoodDay"

prompt = "Go through all the labs, and if there's a person inside, say 'Good Day!' to them."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    current_location = get_current_location()
    all_rooms = get_all_rooms()

    for room in all_rooms:
        if "lab" in room.lower():
            go_to(room)
            if is_in_room("person"):
                say("Good Day!")

    go_to(current_location)
"""

