name = "GetDrink"

prompt = "Go to the lobby. Ask if the visitor wants: a bottle of water, iced tea, or lemonade. Go to the kitchen and bring the visitor back what they asked for."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    go_to("lobby")
    choice = ask("visitor", "What would you like to drink?", ["bottle of water", "iced tea", "lemonade"])
    go_to("kitchen")
    say(f"I need a {choice} for the visitor in the lobby.")
    go_to("lobby")
    say(f"Here is your {choice}.")
"""

