name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0

    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                caramel = ask("", "How many caramel candies would you like?", ["0", "1", "2", "3", "4"])
                chocolate = ask("", "How many chocolate candies would you like?", ["0", "1", "2", "3", "4"])
                gummy = ask("", "How many gummy candies would you like?", ["0", "1", "2", "3", "4"])

                total_caramel += int(caramel)
                total_chocolate += int(chocolate)
                total_gummy += int(gummy)

    go_to(start_loc)
    say(f"We need to buy {total_caramel} caramel, {total_chocolate} chocolate, and {total_gummy} gummy candies.")
"""

