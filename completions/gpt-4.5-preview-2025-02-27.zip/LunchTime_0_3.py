name = "LunchTime"

prompt = "Go to Jill's office and ask her if she'd like to go for lunch tomorrow. If yes, ask her at what time (offer her some reasonable options). Come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    lunch_response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    if lunch_response == "Yes":
        time_response = ask("Jill", "When would you like to go for lunch?", ["12:00 PM", "12:30 PM", "1:00 PM"])
        message = f"Jill said yes, and prefers {time_response} for lunch."
    else:
        message = "Jill said no to lunch tomorrow."
    go_to(start_loc)
    say(message)
"""

