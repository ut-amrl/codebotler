name = "LunchTime"

prompt = "Ask Jill in her office if she want to go for lunch tomorrow. If yes, give her some reasonable time options and ask her to choose a time. Finally come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    response = ask("Jill", "Do you want to go for lunch tomorrow?", ["Yes", "No"])
    if response == "Yes":
        time_choice = ask("Jill", "At what time would you like to have lunch?", ["12:00 PM", "12:30 PM", "1:00 PM"])
        final_response = "Jill said yes, and chose " + time_choice
    else:
        final_response = "Jill said no"
    go_to(start_loc)
    say(final_response)
"""

