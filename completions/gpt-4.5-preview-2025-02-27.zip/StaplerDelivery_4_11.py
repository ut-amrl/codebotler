name = "StaplerDelivery"

prompt = "Check if every printer room has a stapler. If not, put a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    original_location = get_current_location()
    rooms = get_all_rooms()
    printer_rooms_without_stapler = []

    # Check all printer rooms for staplers
    for room in rooms:
        if "printer room" in room:
            go_to(room)
            if not is_in_room("stapler"):
                printer_rooms_without_stapler.append(room)

    # Get staplers from the supply room and place them in the printer rooms without staplers
    for room in printer_rooms_without_stapler:
        go_to("supply room")
        say("Please put a stapler in my basket.")
        go_to(room)
        say("I brought a stapler for this printer room.")

    # Return to the original location
    go_to(original_location)
    say("Task completed.")
"""

