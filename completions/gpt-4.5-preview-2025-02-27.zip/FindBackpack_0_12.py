name = "FindBackpack"

prompt = "Check where I left my backpack in all of the conference rooms and bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    backpack_location = None
    
    for room in rooms:
        if "conference room" in room:
            go_to(room)
            if is_in_room("backpack"):
                backpack_location = room
                break
                
    if backpack_location:
        say("I found your backpack in " + backpack_location + ". I'll bring it back now.")
        # Assuming there is a mechanism for robot to pick up the backpack
        go_to(start_loc)
        say("Here is your backpack.")
    else:
        go_to(start_loc)
        say("I couldn't find your backpack in any conference room.")
"""

