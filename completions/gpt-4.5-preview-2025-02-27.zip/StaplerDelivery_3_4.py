name = "StaplerDelivery"

prompt = "Make sure there is a stapler in each printer room. Otherwise, bring a stapler from the supply room to each printer room that currently lacks one."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    printer_rooms = [room for room in get_all_rooms() if "printer room" in room]
    missing_stapler_rooms = []
    
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            missing_stapler_rooms.append(room)
    
    for room in missing_stapler_rooms:
        go_to("supply room")
        say("Taking a stapler for " + room)
        # Assuming someone will place the stapler into the robot's basket
        say("Please place one stapler into my basket.")
        go_to(room)
        say("I have brought a stapler for this printer room.")
    
    say("All printer rooms now have staplers.")
"""

