name = "WeatherPoll"

prompt = "Go wait for someone at the main entrance. Ask them if they feel it is hot out, then wait for the next person and ask the same question. Do this until you have ten responses, then come back and report the percentage of people who think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    hot_count = 0
    total_people = 10
    for i in range(total_people):
        # Wait for a person to arrive
        while not is_in_room("person"):
            time.sleep(1)
        response = ask("", "Do you feel it's hot out?", ["Yes", "No"])
        if response == "Yes":
            hot_count += 1
        # Wait for the person to leave before waiting for the next
        while is_in_room("person"):
            time.sleep(1)
    percentage_hot = (hot_count / total_people) * 100
    go_to(start_loc)
    say(f"{percentage_hot}% of people think it is hot out.")
"""

