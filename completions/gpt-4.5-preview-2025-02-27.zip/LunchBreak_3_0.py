name = "LunchBreak"

prompt = "Ask Alice and Bob if they are up for lunch. If they say yes, tell them that we will meet in the lobby in five minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    participants = []

    # Check with Alice
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("Great! Let's meet in the lobby in five minutes.")
        participants.append("Alice")

    # Check with Bob
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("Great! Let's meet in the lobby in five minutes.")
        participants.append("Bob")

    go_to(start_loc)

    if participants:
        joined = ", ".join(participants)
        say(f"The following people are joining for lunch: {joined}")
    else:
        say("Unfortunately, no one is joining for lunch.")
"""

