name = "LunchBreak"

prompt = "Ask Alice and Bob if they are up for lunch. If they say yes, tell them that we will meet in the lobby in five minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    people = ["Alice", "Bob"]
    joining = []
    for person in people:
        go_to(person + "'s office")
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            say("Great! We'll meet in the lobby in five minutes.")
            joining.append(person)
    go_to(start_loc)
    if joining:
        joined_people = ", ".join(joining)
        say(f"The following people are joining for lunch: {joined_people}.")
    else:
        say("No one is joining for lunch.")
"""

