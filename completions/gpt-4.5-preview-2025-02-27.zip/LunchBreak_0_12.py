name = "LunchBreak"

prompt = "Ask if Alice and Bob in their offices are up for lunch. If yes, tell them that we'll meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joining = []

    # Check with Alice
    go_to("Alice's office")
    response_alice = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if response_alice == "Yes":
        joining.append("Alice")
        say("Great! We'll meet in the lobby in 5 minutes.")

    # Check with Bob
    go_to("Bob's office")
    response_bob = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if response_bob == "Yes":
        joining.append("Bob")
        say("Great! We'll meet in the lobby in 5 minutes.")

    # Return to starting point
    go_to(start_loc)

    # Inform me who is joining
    if joining:
        people_joining = ", ".join(joining)
        say("The following people are joining for lunch: " + people_joining)
    else:
        say("No one else is joining for lunch.")
"""

