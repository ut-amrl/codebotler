name = "StaplerSupply"

prompt = "Tell me the name of every printer room that does not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    no_stapler_rooms = []

    for room in rooms:
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                no_stapler_rooms.append(room)

    go_to(start_loc)
    
    if no_stapler_rooms:
        message = "Printer rooms without a stapler are: " + ", ".join(no_stapler_rooms)
    else:
        message = "All printer rooms have a stapler."
    
    say(message)
"""

