name = "MovieMessenger"

prompt = "Ask Sally in her office if she wants to go to the cinema with Mark. Go to Mark's office and tell him Sally's answer. If Sally says yes, ask Mark whether he wants to leave at 4PM, 5PM, or 6PM - then go tell Sally what time Mark is leaving."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    go_to("Sally's office")
    response = ask("Sally", "Do you want to go to the cinema with Mark?", ["Yes", "No"])
    
    go_to("Mark's office")
    say("Sally said: " + response)
    
    if response == "Yes":
        time_response = ask("Mark", "What time would you like to leave?", ["4PM", "5PM", "6PM"])
        go_to("Sally's office")
        say("Mark wants to leave at " + time_response)
    else:
        say("No further action needed.")
"""

