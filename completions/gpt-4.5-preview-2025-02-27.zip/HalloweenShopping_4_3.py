name = "HalloweenShopping"

prompt = "Go to every office and skip any office without a person in there. Otherwise, ask the person in the office to decide on how many, from zero to four, of the following they'd like: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy. "

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    offices = [room for room in get_all_rooms() if "office" in room]

    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0

    for office in offices:
        go_to(office)
        if is_in_room("person"):
            gummy = ask("", "How many gummy would you like?", ["0", "1", "2", "3", "4"])
            caramel = ask("", "How many caramel would you like?", ["0", "1", "2", "3", "4"])
            chocolate = ask("", "How many chocolate would you like?", ["0", "1", "2", "3", "4"])
            total_gummy += int(gummy)
            total_caramel += int(caramel)
            total_chocolate += int(chocolate)

    go_to(start_location)
    say(f"We need to buy {total_gummy} gummy, {total_caramel} caramel, and {total_chocolate} chocolate.")
"""

