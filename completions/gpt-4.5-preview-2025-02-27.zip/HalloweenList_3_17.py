name = "HalloweenList"

prompt = "Find every occupied office and ask their occupants whether they would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    rooms = get_all_rooms()
    chocolate = 0
    caramel = 0
    gummy = 0
    
    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                choice = ask("", "What candy would you like?", ["chocolate", "caramel", "gummy"])
                if choice == "chocolate":
                    chocolate += 1
                elif choice == "caramel":
                    caramel += 1
                elif choice == "gummy":
                    gummy += 1
    
    go_to(start_location)
    say(f"We need to buy {chocolate} chocolate, {caramel} caramel, and {gummy} gummy candies.")
"""

