name = "WeatherPoll"

prompt = "Go wait for someone at the main entrance. Ask them if they feel it is hot out, then wait for the next person and ask the same question. Do this until you have ten responses, then come back and report the percentage of people who think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    hot_count = 0
    total_responses = 10

    for response_number in range(total_responses):
        while not is_in_room("person"):
            pass  # waiting for someone to arrive
        response = ask("", "Do you feel it is hot out?", ["Yes", "No"])
        if response == "Yes":
            hot_count += 1
        say("Thank you for your response. Have a nice day!")
        while is_in_room("person"):
            pass  # waiting for person to leave before next interaction

    hot_percentage = (hot_count / total_responses) * 100
    go_to(start_loc)
    say(f"{hot_percentage}% of people think it is hot outside.")
"""

