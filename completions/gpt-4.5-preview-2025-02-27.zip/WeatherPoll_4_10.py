name = "WeatherPoll"

prompt = "Go to the main entrance, and if there is no one there, wait for someone to show up. Ask them if they feel it is hot out. Wait for the next person and ask the same question again. Do this 10 times. Come back and report the percentage of people who think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    go_to("main entrance")
    
    hot_count = 0
    total_people = 10
    
    for i in range(total_people):
        while not is_in_room("person"):
            time.sleep(1)
        response = ask("", "Do you feel it is hot out?", ["Yes", "No"])
        if response == "Yes":
            hot_count += 1
        while is_in_room("person"):
            time.sleep(1)
    
    percentage = (hot_count / total_people) * 100
    go_to(start_location)
    say(f"{percentage}% of people think it's hot out.")
"""

