name = "StaplerDelivery"

prompt = "Make sure there is a stapler in each printer room. Otherwise, bring a stapler from the supply room to each printer room that currently lacks one."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    supply_loc = "supply room"
    initial_loc = get_current_location()
    rooms = get_all_rooms()
    printer_rooms_needing_stapler = []

    for room in rooms:
        if "printer room" in room:
            go_to(room)
            if not is_in_room("stapler"):
                printer_rooms_needing_stapler.append(room)

    for room in printer_rooms_needing_stapler:
        go_to(supply_loc)
        say("Please place a stapler in my basket.")
        go_to(room)
        say("I have brought a stapler to this printer room.")

    go_to(initial_loc)
    say("Task is completed.")
"""

