name = "StaplerDelivery"

prompt = "Check if there is a stapler in every printer room. For each visited room without a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    printer_rooms = [room for room in get_all_rooms() if "printer room" in room]

    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            go_to("supply room")
            say("Picking up a stapler for delivery.")
            go_to(room)
            say("Delivered a stapler to " + room)

    say("Task completed. All printer rooms now have staplers.")
"""

