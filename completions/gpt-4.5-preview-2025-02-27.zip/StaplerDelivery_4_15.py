name = "StaplerDelivery"

prompt = "Check if every printer room has a stapler. If not, put a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    printer_rooms = [room for room in get_all_rooms() if "printer room" in room]
    rooms_needing_stapler = []
    
    # Check each printer room
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            rooms_needing_stapler.append(room)

    # Deliver staplers to rooms that need them
    for room in rooms_needing_stapler:
        go_to("supply room")
        say("Please provide me with a stapler for " + room)
        go_to(room)
        say("Delivered stapler to " + room)

    say("Task completed: all printer rooms now have staplers.")
"""

