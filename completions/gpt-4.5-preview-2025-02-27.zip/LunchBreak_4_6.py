name = "LunchBreak"

prompt = "Go to Alice's office and ask her if she is free for lunch. If she says yes, tell her that we will meet in the lobby in five minutes. Do the same for Bob. Come back and tell me who will join for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joining = []

    # Check with Alice
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you free for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("Great! We will meet in the lobby in five minutes.")
        joining.append("Alice")

    # Check with Bob
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you free for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("Great! We will meet in the lobby in five minutes.")
        joining.append("Bob")

    # Return and report
    go_to(start_loc)
    if joining:
        joined_list = " and ".join(joining)
        say(joined_list + " will join for lunch.")
    else:
        say("Neither Alice nor Bob will join for lunch.")
"""

