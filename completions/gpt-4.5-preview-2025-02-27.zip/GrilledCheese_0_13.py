name = "GrilledCheese"

prompt = "Compile a list of ingredients for grilled cheese. Go to Zarko's office, and ask him which of them he has. Come back and tell me what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheddar cheese", "butter"]
    go_to("Zarko's office")
    unavailable_ingredients = []
    for item in ingredients:
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "No":
            unavailable_ingredients.append(item)
    start_location = get_current_location()
    go_to(start_location)
    if unavailable_ingredients:
        say("Zarko does not have: " + ", ".join(unavailable_ingredients))
    else:
        say("Zarko has all ingredients for grilled cheese.")
"""

