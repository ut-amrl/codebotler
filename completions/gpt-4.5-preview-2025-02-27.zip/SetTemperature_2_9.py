name = "SetTemperature"

prompt = "The thermostat is currently set to 72 degrees. Go ask if Arjun thinks his office should be colder or warmer. Come back and tell me what temperature in degrees I should change the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Arjun's office")
    response = ask("Arjun", "Should your office be colder or warmer?", ["Colder", "Warmer"])
    if response == "Colder":
        new_temp = 71
    else:
        new_temp = 73
    go_to(start_loc)
    say("You should set the thermostat to " + str(new_temp) + " degrees.")
"""

