name = "GetDrink"

prompt = "Ask any visitor in the lobby if they would like a bottle of water, iced tea, or lemonade. Bring what they ask for from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("lobby")
    visitor_choice = ask("visitor", "Would you like a beverage?", ["bottle of water", "iced tea", "lemonade"])
    go_to("kitchen")
    say("Please place " + visitor_choice + " in my basket.")
    go_to("lobby")
    say("Here is your " + visitor_choice)
    go_to(start_loc)
    say("Task completed.")
"""

