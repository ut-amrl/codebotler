name = "StaplerSupply"

prompt = "Check every printer room for a stapler, and come back and tell me which ones do not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    printer_rooms = [room for room in get_all_rooms() if "printer room" in room]
    rooms_without_stapler = []

    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            rooms_without_stapler.append(room)

    go_to(start_loc)

    if len(rooms_without_stapler) == 0:
        say("All printer rooms have a stapler.")
    else:
        missing_rooms = ", ".join(rooms_without_stapler)
        say("These printer rooms do not have a stapler: " + missing_rooms)
"""

