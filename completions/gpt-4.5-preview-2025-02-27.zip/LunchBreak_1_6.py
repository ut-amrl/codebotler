name = "LunchBreak"

prompt = "Ask Alice in her office if she is up for lunch, and if yes, tell her that we will meet in the lobby in 5 minutes. Do the same for Bob. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joining = []

    go_to("Alice's office")
    response_alice = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if response_alice == "Yes":
        say("Great! We will meet in the lobby in 5 minutes.")
        joining.append("Alice")

    go_to("Bob's office")
    response_bob = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if response_bob == "Yes":
        say("Great! We will meet in the lobby in 5 minutes.")
        joining.append("Bob")

    go_to(start_loc)

    if joining:
        participants = ", ".join(joining)
        say(f"{participants} will be joining for lunch.")
    else:
        say("No one will be joining for lunch.")
"""

