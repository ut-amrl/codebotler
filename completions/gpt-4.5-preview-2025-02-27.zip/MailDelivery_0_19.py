name = "MailDelivery"

prompt = "Pick up a mail bin from the mail room. Go to every office and ask if they have any mail they'd like delivered. If so, ask them to put it in the mail bin. Finally, meet me in the mail room with all the mail. Place the mail bin back and tell me which offices they are from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    go_to("mail room")
    say("I am picking up the mail bin.")

    offices = get_all_rooms()
    mail_collected_from = []

    for room in offices:
        if "office" in room:
            go_to(room)
            response = ask("", "Do you have any mail you'd like delivered?", ["Yes", "No"])
            if response == "Yes":
                say("Please put your mail in the mail bin.")
                mail_collected_from.append(room)
    
    go_to("mail room")
    say("I have placed the mail bin back.")
    
    go_to(start_location)
    if mail_collected_from:
        offices_list = ", ".join(mail_collected_from)
        say("I collected mail from the following offices: " + offices_list)
    else:
        say("No offices had mail to deliver.")
"""

