name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a cupcake, ham sandwich, donut, or beef jerky. Come back and tell me how many people chose a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices = [room for room in get_all_rooms() if "office" in room]
    savory_options = ["ham sandwich", "beef jerky"]
    savory_count = 0
    
    for office in offices:
        go_to(office)
        if is_in_room("person"):
            response = ask("", "What would you like?", ["cupcake", "ham sandwich", "donut", "beef jerky"])
            if response in savory_options:
                savory_count += 1
                
    go_to(start_loc)
    say(f"{savory_count} people chose a savory option.")
"""

