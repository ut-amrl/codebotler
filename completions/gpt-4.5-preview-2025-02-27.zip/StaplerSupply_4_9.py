name = "StaplerSupply"

prompt = "Tell me the name of every printer room that does not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    starting_location = get_current_location()
    rooms = get_all_rooms()
    rooms_without_stapler = []

    for room in rooms:
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                rooms_without_stapler.append(room)

    go_to(starting_location)

    if rooms_without_stapler:
        message = "Printer rooms without staplers: " + ", ".join(rooms_without_stapler)
    else:
        message = "All printer rooms have staplers."

    say(message)
"""

