name = "StaplerSupply"

prompt = "Go find all printer rooms that do not have a stapler. Come back and tell me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    printer_rooms = [room for room in get_all_rooms() if "printer room" in room.lower()]
    rooms_without_stapler = []

    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            rooms_without_stapler.append(room)

    go_to(start_location)

    if rooms_without_stapler:
        message = "These printer rooms do not have a stapler: " + ", ".join(rooms_without_stapler)
    else:
        message = "All printer rooms have a stapler."
    
    say(message)
"""

