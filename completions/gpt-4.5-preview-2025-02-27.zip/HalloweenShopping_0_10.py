name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()

    chocolate_total = 0
    caramel_total = 0
    gummy_total = 0

    all_rooms = get_all_rooms()
    offices = [room for room in all_rooms if "office" in room.lower()]

    for office in offices:
        go_to(office)
        if is_in_room("person"):
            chocolate = ask("", "How many chocolates would you like?", ["0", "1", "2", "3", "4"])
            caramel = ask("", "How many caramels would you like?", ["0", "1", "2", "3", "4"])
            gummy = ask("", "How many gummies would you like?", ["0", "1", "2", "3", "4"])

            chocolate_total += int(chocolate)
            caramel_total += int(caramel)
            gummy_total += int(gummy)

    go_to(start_location)
    say("We need to buy " + str(chocolate_total) + " chocolates, " +
        str(caramel_total) + " caramels, and " + str(gummy_total) + " gummies.")
"""

