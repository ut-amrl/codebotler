name = "StaplerDelivery"

prompt = "Check if every printer room has a stapler. If not, put a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    initial_location = get_current_location()
    all_rooms = get_all_rooms()
    rooms_missing_stapler = []

    # Check every printer room for a stapler
    for room in all_rooms:
        if "printer room" in room:
            go_to(room)
            if not is_in_room("stapler"):
                rooms_missing_stapler.append(room)

    # If any printer rooms are missing staplers, retrieve from the supply room and deliver
    for room in rooms_missing_stapler:
        # Go to supply room to collect a stapler
        go_to("supply room")
        say("Please put a stapler into my basket.")
        # Go to the printer room to deliver stapler
        go_to(room)
        say("I've delivered the stapler to this printer room.")

    go_to(initial_location)
    say("Task completed: All printer rooms now have staplers.")
"""

