name = "SayGoodDay"

prompt = "Visit each lab and if someone is present, greet them with a pleasant Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    rooms = get_all_rooms()
    for room in rooms:
        if "lab" in room.lower():
            go_to(room)
            if is_in_room("person"):
                say("Good Day!")
"""

