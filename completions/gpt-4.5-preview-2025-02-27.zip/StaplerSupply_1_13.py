name = "StaplerSupply"

prompt = "Go to every printer room and check to see if there is a stapler. Come back and tell me which printer rooms do not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    missing_stapler_rooms = []
    for room in rooms:
        if "printer room" in room:
            go_to(room)
            if not is_in_room("stapler"):
                missing_stapler_rooms.append(room)

    go_to(start_loc)
    if missing_stapler_rooms:
        rooms_list = ", ".join(missing_stapler_rooms)
        say("The following printer rooms do not have a stapler: " + rooms_list)
    else:
        say("All printer rooms have a stapler.")
"""

