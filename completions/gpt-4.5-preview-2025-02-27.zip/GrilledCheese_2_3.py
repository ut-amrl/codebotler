name = "GrilledCheese"

prompt = "Put together a compilation of grilled cheese ingredients. Head to Zarko's office, inquire about his available ingredients, and then update me on what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheese", "butter"]
    go_to("Zarko's office")
    
    missing_ingredients = []
    for ingredient in ingredients:
        has_ingredient = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if has_ingredient == "No":
            missing_ingredients.append(ingredient)
    
    start_loc = get_current_location()
    go_to(start_loc)
    
    if missing_ingredients:
        missing_items_str = ", ".join(missing_ingredients)
        say(f"Zarko is missing the following ingredients: {missing_items_str}.")
    else:
        say("Zarko has all the grilled cheese ingredients.")
"""

