name = "MailDelivery"

prompt = "Grab a mail bin from the mail room. Go to every office, and ask if they have any mail to deliver. Ask them to put all mail in the bin if there is any. Put the mail bin back in the mail room and report which offices the mail is from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    mail_bin_location = "mail room"
    go_to(mail_bin_location)
    say("I have picked up the mail bin.")

    rooms = get_all_rooms()
    offices_with_mail = []

    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
                if response == "Yes":
                    say("Please put all mail in the bin.")
                    offices_with_mail.append(room)

    go_to(mail_bin_location)
    say("I have returned the mail bin to the mail room.")

    go_to(start_loc)

    if offices_with_mail:
        offices_str = ", ".join(offices_with_mail)
        say(f"The mail collected is from: {offices_str}.")
    else:
        say("No mail was collected from any offices.")
"""

