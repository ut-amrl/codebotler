name = "WeatherPoll"

prompt = "Go wait for someone at the main entrance. Ask them if they feel it is hot out, then wait for the next person and ask the same question. Do this until you have ten responses, then come back and report the percentage of people who think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    responses = []
    while len(responses) < 10:
        if is_in_room("person"):
            answer = ask("", "Do you feel it is hot out?", ["Yes", "No"])
            responses.append(answer)
            say("Thank you for your response.")
        else:
            time.sleep(1)
    hot_count = responses.count("Yes")
    percentage_hot = (hot_count / 10) * 100
    go_to(start_loc)
    say(f"{percentage_hot}% of people think it is hot out.")
"""

