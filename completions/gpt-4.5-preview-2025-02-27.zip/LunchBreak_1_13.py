name = "LunchBreak"

prompt = "Ask Alice in her office if she is up for lunch, and if yes, tell her that we will meet in the lobby in 5 minutes. Do the same for Bob. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    attendees = []

    # Check with Alice
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("Great! We'll meet in the lobby in 5 minutes.")
        attendees.append("Alice")

    # Check with Bob
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("Great! We'll meet in the lobby in 5 minutes.")
        attendees.append("Bob")

    go_to(start_loc)

    if attendees:
        participants = ", ".join(attendees)
        message = f"{participants} will join for lunch."
    else:
        message = "No one is joining for lunch."
    say(message)
"""

