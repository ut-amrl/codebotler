name = "GrilledCheese"

prompt = "Compile a list of ingredients for grilled cheese. Go to Zarko's office, and ask him which of them he has. Come back and tell me what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheddar cheese", "butter"]
    missing_ingredients = []

    start_loc = get_current_location()
    go_to("Zarko's office")

    for item in ingredients:
        answer = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if answer == "No":
            missing_ingredients.append(item)

    go_to(start_loc)

    if missing_ingredients:
        say("Zarko does not have: " + ", ".join(missing_ingredients))
    else:
        say("Zarko has all the ingredients for grilled cheese.")
"""

