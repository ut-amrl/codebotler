name = "HalloweenList"

prompt = "Check with every occupied office to see if the occupant would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0
    
    for room in rooms:
        go_to(room)
        if is_in_room("person"):
            occupant_choice = ask("", "Which candy would you like?", ["chocolate", "caramel", "gummy"])
            if occupant_choice == "chocolate":
                chocolate_count += 1
            elif occupant_choice == "caramel":
                caramel_count += 1
            elif occupant_choice == "gummy":
                gummy_count += 1
    
    go_to(start_loc)
    say(f"We need to buy {chocolate_count} chocolates, {caramel_count} caramels, and {gummy_count} gummies.")
"""

