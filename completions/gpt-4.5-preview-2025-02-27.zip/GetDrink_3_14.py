name = "GetDrink"

prompt = "Go to the lobby and ask any person there if they want iced tea, lemonade or a bottle of water. Bring whatever they asked for back from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("lobby")
    
    while not is_in_room("person"):
        time.sleep(1)  # Wait until someone arrives in the lobby
    
    choice = ask("", "Would you like iced tea, lemonade, or a bottle of water?", ["iced tea", "lemonade", "bottle of water"])
    
    go_to("kitchen")
    if is_in_room(choice):
        say(f"I am picking up {choice}.")
    else:
        say(f"{choice} is not available in the kitchen.")
    
    go_to(start_loc)
    say(f"I have brought {choice} back from the kitchen.")
"""

