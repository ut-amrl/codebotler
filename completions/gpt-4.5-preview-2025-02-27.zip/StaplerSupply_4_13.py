name = "StaplerSupply"

prompt = "Tell me the name of every printer room that does not have a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    printer_rooms_no_stapler = []
    for room in all_rooms:
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                printer_rooms_no_stapler.append(room)
    go_to(start_loc)
    if printer_rooms_no_stapler:
        message = "Printer rooms without staplers are: " + ", ".join(printer_rooms_no_stapler)
    else:
        message = "All printer rooms have staplers."
    say(message)
"""

