name = "LunchBreak"

prompt = "Ask if Alice and Bob in their offices are up for lunch. If yes, tell them that we'll meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joining = []
    
    # Check with Alice
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("Great! We'll meet in the lobby in 5 minutes.")
        joining.append("Alice")
    
    # Check with Bob
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("Great! We'll meet in the lobby in 5 minutes.")
        joining.append("Bob")
        
    # Return to starting location
    go_to(start_loc)
    
    if joining:
        joined_people = ", ".join(joining)
        say(f"{joined_people} will be joining for lunch.")
    else:
        say("No one is joining for lunch.")
"""

