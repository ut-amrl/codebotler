name = "MailDelivery"

prompt = "Find a mail bin in the mail room and carry it with you. Collect mail from every office by asking if there is any mail they'd like delivered. If yes, ask them to put it in the bin. Return the bin to the mail room and say which offices sent mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices_with_mail = []
    
    # Go to mail room to get the mail bin
    go_to("mail room")
    if not is_in_room("mail bin"):
        say("No mail bin found in mail room")
        return
    say("I have picked up the mail bin.")

    # Check each office for outgoing mail
    rooms = get_all_rooms()
    for room in rooms:
        if "office" in room.lower():
            go_to(room)
            if is_in_room("person"):
                response = ask("", "Do you have any mail you'd like delivered?", ["Yes", "No"])
                if response == "Yes":
                    say("Please put your mail in the bin.")
                    offices_with_mail.append(room)

    # Return mail bin to mail room
    go_to("mail room")
    say("I have returned the mail bin.")

    # Report which offices sent mail
    if offices_with_mail:
        offices_list = ", ".join(offices_with_mail)
        say("The following offices sent mail: " + offices_list)
    else:
        say("No offices had mail to send.")

    go_to(start_loc)
"""

