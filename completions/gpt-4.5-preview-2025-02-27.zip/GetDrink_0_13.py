name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. Bring what they ask for from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    go_to("lobby")
    choice = ask("visitor", "Would you like a bottle of water, iced tea, or lemonade?", ["water", "iced tea", "lemonade"])
    go_to("kitchen")
    if is_in_room(choice):
        say(f"I will pick up the {choice}.")
    else:
        say(f"Sorry, there is no {choice} in the kitchen.")
        return
    go_to("lobby")
    say(f"Here is your {choice}.")
"""

