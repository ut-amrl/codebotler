name = "StaplerDelivery"

prompt = "Check if every printer room has a stapler. If not, put a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    original_location = get_current_location()
    rooms = get_all_rooms()
    rooms_needing_stapler = []

    for room in rooms:
        if "printer room" in room:
            go_to(room)
            if not is_in_room("stapler"):
                rooms_needing_stapler.append(room)

    for room in rooms_needing_stapler:
        go_to("supply room")
        say("Please place a stapler in my basket.")
        go_to(room)
        say("Please take the stapler from my basket and place it here.")

    go_to(original_location)
    say("Task completed.")
"""

