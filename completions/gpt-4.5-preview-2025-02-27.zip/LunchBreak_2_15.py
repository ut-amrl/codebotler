name = "LunchBreak"

prompt = "Go to Alice's and Bob's offices and ask each of them if they are up for lunch. If they say yes, tell them that we will meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joining = []

    offices = {"Alice": "Alice's office", "Bob": "Bob's office"}
    for person, office in offices.items():
        go_to(office)
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            say("Great! We'll meet in the lobby in 5 minutes.")
            joining.append(person)

    go_to(start_loc)
    
    if joining:
        participants = ", ".join(joining)
        say(participants + " will join for lunch.")
    else:
        say("Nobody is joining for lunch.")
"""

