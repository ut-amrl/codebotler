name = "GetDrink"

prompt = "Go to the lobby and ask any person there if they want iced tea, lemonade or a bottle of water. Bring whatever they asked for back from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("lobby")

    # Wait until a person appears in the lobby
    while not is_in_room("person"):
        pass

    # Ask the person what drink they would like
    drink_choice = ask("", "Which drink would you like?", ["iced tea", "lemonade", "bottle of water"])

    # Go to the kitchen to get the selected drink
    go_to("kitchen")
    say("Retrieving " + drink_choice)

    # Bring the drink back to the starting location
    go_to(start_loc)
    say("I have brought the " + drink_choice)
"""

