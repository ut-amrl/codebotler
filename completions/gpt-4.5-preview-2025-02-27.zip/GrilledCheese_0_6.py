name = "GrilledCheese"

prompt = "Compile a list of ingredients for grilled cheese. Go to Zarko's office, and ask him which of them he has. Come back and tell me what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheese", "butter"]
    go_to("Zarko's office")
    missing_ingredients = []
    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(ingredient)
    start_loc = get_current_location()
    go_to(start_loc)
    if missing_ingredients:
        missing_items = ", ".join(missing_ingredients)
        say(f"Zarko does not have: {missing_items}")
    else:
        say("Zarko has all the ingredients.")
"""

