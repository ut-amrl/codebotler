name = "LunchBreak"

prompt = "Go to Alice's office and ask her if she is free for lunch. If she says yes, tell her that we will meet in the lobby in five minutes. Do the same for Bob. Come back and tell me who will join for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    attendees = []

    go_to("Alice's office")
    alice_response = ask("Alice", "Are you free for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("We will meet in the lobby in five minutes.")
        attendees.append("Alice")

    go_to("Bob's office")
    bob_response = ask("Bob", "Are you free for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("We will meet in the lobby in five minutes.")
        attendees.append("Bob")

    go_to(start_loc)

    if attendees:
        say("The following people will join for lunch: " + ", ".join(attendees))
    else:
        say("No one is available to join for lunch.")
"""

