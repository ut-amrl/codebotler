name = "MailDelivery"

prompt = "Grab a mail bin from the mail room. Go to every office, and ask if they have any mail to deliver. Ask them to put all mail in the bin if there is any. Put the mail bin back in the mail room and report which offices the mail is from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices_with_mail = []
    
    # Go to mail room to pick up mail bin
    go_to("mail room")
    say("Picking up the mail bin.")
    
    # Check each office
    rooms = get_all_rooms()
    for room in rooms:
        if "office" in room:
            go_to(room)
            response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                say("Please place all mail in the bin.")
                offices_with_mail.append(room)
    
    # Return mail bin
    go_to("mail room")
    say("Returning the mail bin.")
    
    # Report offices with mail
    go_to(start_loc)
    if offices_with_mail:
        say("The offices with mail are: " + ", ".join(offices_with_mail))
    else:
        say("No offices had mail to deliver.")
"""

