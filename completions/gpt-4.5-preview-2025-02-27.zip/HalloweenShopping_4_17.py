name = "HalloweenShopping"

prompt = "Go to every office and skip any office without a person in there. Otherwise, ask the person in the office to decide on how many, from zero to four, of the following they'd like: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy. "

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices = get_all_rooms()

    gummy_count = 0
    caramel_count = 0
    chocolate_count = 0

    for office in offices:
        if "office" not in office:
            continue
        go_to(office)
        if not is_in_room("person"):
            continue
        gummy = int(ask("", "How many gummies would you like?", ["0", "1", "2", "3", "4"]))
        caramel = int(ask("", "How many caramels would you like?", ["0", "1", "2", "3", "4"]))
        chocolate = int(ask("", "How many chocolates would you like?", ["0", "1", "2", "3", "4"]))
        
        gummy_count += gummy
        caramel_count += caramel
        chocolate_count += chocolate
    
    go_to(start_loc)
    say(f"We need to buy {gummy_count} gummies, {caramel_count} caramels, and {chocolate_count} chocolates.")
"""

