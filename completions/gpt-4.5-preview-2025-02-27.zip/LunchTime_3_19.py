name = "LunchTime"

prompt = "Ask Jill in her office whether she will be free to go for lunch tomorrow. If yes, offer her some reasonable time options to choose from, and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    response = ask("Jill", "Will you be free to go for lunch tomorrow?", ["Yes", "No"])
    if response == "Yes":
        time_response = ask("Jill", "Great! What time would you prefer?", ["11:30 AM", "12:00 PM", "12:30 PM", "1:00 PM"])
        final_response = f"Jill is available for lunch tomorrow at {time_response}."
    else:
        final_response = "Jill is not available for lunch tomorrow."
    go_to(start_loc)
    say(final_response)
"""

