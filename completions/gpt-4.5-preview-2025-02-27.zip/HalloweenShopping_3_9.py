name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    
    gummy_total = 0
    caramel_total = 0
    chocolate_total = 0
    
    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                gummy_response = int(ask("", "How many gummies would you like?", ["0", "1", "2", "3", "4"]))
                caramel_response = int(ask("", "How many caramels would you like?", ["0", "1", "2", "3", "4"]))
                chocolate_response = int(ask("", "How many chocolates would you like?", ["0", "1", "2", "3", "4"]))
                
                gummy_total += gummy_response
                caramel_total += caramel_response
                chocolate_total += chocolate_response
                
    go_to(start_loc)
    say(f"We need to buy {gummy_total} gummies, {caramel_total} caramels, and {chocolate_total} chocolates.")
"""

