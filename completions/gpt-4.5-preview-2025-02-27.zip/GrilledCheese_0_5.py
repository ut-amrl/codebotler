name = "GrilledCheese"

prompt = "Compile a list of ingredients for grilled cheese. Go to Zarko's office, and ask him which of them he has. Come back and tell me what he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheddar cheese", "butter"]
    start_loc = get_current_location()
    go_to("Zarko's office")
    has_ingredients = []
    missing_ingredients = []

    for item in ingredients:
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "Yes":
            has_ingredients.append(item)
        else:
            missing_ingredients.append(item)

    go_to(start_loc)

    if missing_ingredients:
        missing_list = ", ".join(missing_ingredients)
        say(f"Zarko does not have: {missing_list}")
    else:
        say("Zarko has all the ingredients for grilled cheese.")
"""

