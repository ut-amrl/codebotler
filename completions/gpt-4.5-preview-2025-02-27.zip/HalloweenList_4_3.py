name = "HalloweenList"

prompt = "Go to every office with a person, and ask them if they would like a chocolate, caramel, or gummy, then come back and tell me how many of each people asked for."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    chocolate = 0
    caramel = 0
    gummy = 0

    for room in rooms:
        go_to(room)
        if is_in_room("person") and "office" in room:
            choice = ask("", "What candy would you like?", ["chocolate", "caramel", "gummy"])
            if choice == "chocolate":
                chocolate += 1
            elif choice == "caramel":
                caramel += 1
            elif choice == "gummy":
                gummy += 1

    go_to(start_loc)
    summary = (f"People requested {chocolate} chocolates, "
               f"{caramel} caramels, and {gummy} gummies.")
    say(summary)
"""

