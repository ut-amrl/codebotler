name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    chocolate_total = 0
    caramel_total = 0
    gummy_total = 0

    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                chocolate_response = int(ask("", "How many chocolates would you like?", ["0", "1", "2", "3", "4"]))
                caramel_response = int(ask("", "How many caramels would you like?", ["0", "1", "2", "3", "4"]))
                gummy_response = int(ask("", "How many gummies would you like?", ["0", "1", "2", "3", "4"]))

                chocolate_total += chocolate_response
                caramel_total += caramel_response
                gummy_total += gummy_response

    go_to(start_loc)
    say(f"We need to buy {chocolate_total} chocolates, {caramel_total} caramels, and {gummy_total} gummies.")
"""

