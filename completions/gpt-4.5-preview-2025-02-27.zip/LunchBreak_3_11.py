name = "LunchBreak"

prompt = "Ask Alice and Bob if they are up for lunch. If they say yes, tell them that we will meet in the lobby in five minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    joining = []

    go_to("Alice's office")
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("Great! We'll meet in the lobby in five minutes.")
        joining.append("Alice")

    go_to("Bob's office")
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("Great! We'll meet in the lobby in five minutes.")
        joining.append("Bob")

    go_to(start_location)
    if joining:
        participants = ", ".join(joining)
        say(participants + " will join us for lunch.")
    else:
        say("No one is joining us for lunch.")
"""

