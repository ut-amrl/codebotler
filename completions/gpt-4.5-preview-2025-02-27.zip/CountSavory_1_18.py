name = "CountSavory"

prompt = "Visit all offices. If anyone is present; ask them to choose from the options of cupcake, ham sandwich, donut, or beef jerky. Let me know how many people selected a savory option when you return."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    savory_options = ["ham sandwich", "beef jerky"]
    food_options = ["cupcake", "ham sandwich", "donut", "beef jerky"]
    savory_count = 0
    start_location = get_current_location()
    
    rooms = get_all_rooms()
    
    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                choice = ask("", "Please select one of the following:", food_options)
                if choice in savory_options:
                    savory_count += 1
    
    go_to(start_location)
    say(f"{savory_count} people selected a savory option.")
"""

