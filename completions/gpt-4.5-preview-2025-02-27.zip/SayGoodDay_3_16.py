name = "SayGoodDay"

prompt = "Head to each lab and in case there's a person present, bid them a Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    labs = [room for room in get_all_rooms() if "lab" in room.lower()]
    for lab in labs:
        go_to(lab)
        if is_in_room("person"):
            say("Good Day!")
"""

