name = "LunchBreak"

prompt = "Ask Alice and Bob if they are up for lunch. If they say yes, tell them that we will meet in the lobby in five minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    attendees = []
    for person in ["Alice", "Bob"]:
        go_to(person + "'s office")
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            say("We will meet in the lobby in five minutes.")
            attendees.append(person)
    go_to(start_loc)
    if attendees:
        say("The following people are joining for lunch: " + ", ".join(attendees))
    else:
        say("No one is joining for lunch.")
"""

