name = "FindBackpack"

prompt = "Look in all of the conference rooms to search for my backpack and then bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    rooms = get_all_rooms()
    for room in rooms:
        if "conference room" in room:
            go_to(room)
            if is_in_room("backpack"):
                say("I found your backpack in " + room)
                say("I am bringing it back to you now.")
                go_to(start_location)
                return
    go_to(start_location)
    say("I couldn't find your backpack in any of the conference rooms.")
"""

