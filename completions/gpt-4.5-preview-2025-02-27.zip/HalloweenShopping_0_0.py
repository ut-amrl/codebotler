name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices = [room for room in get_all_rooms() if "office" in room]
    
    total_chocolate = 0
    total_caramel = 0
    total_gummy = 0
    
    for office in offices:
        go_to(office)
        if is_in_room("person"):
            chocolate_num = ask("", "How many chocolates would you like?", ["0", "1", "2", "3", "4"])
            caramel_num = ask("", "How many caramels would you like?", ["0", "1", "2", "3", "4"])
            gummy_num = ask("", "How many gummies would you like?", ["0", "1", "2", "3", "4"])
            
            total_chocolate += int(chocolate_num)
            total_caramel += int(caramel_num)
            total_gummy += int(gummy_num)
            
    go_to(start_loc)
    say(f"We need to buy {total_chocolate} chocolates, {total_caramel} caramels, and {total_gummy} gummies.")
"""

