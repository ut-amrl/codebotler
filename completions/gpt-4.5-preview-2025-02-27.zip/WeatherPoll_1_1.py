name = "WeatherPoll"

prompt = "Go to the main entrance. When someone shows up, ask them if they feel that it's hot out. Do this until you collect ten people's responses. Come back and tell me which percent of people think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    responses = []
    while len(responses) < 10:
        if is_in_room("person"):
            answer = ask("", "Do you feel that it's hot out?", ["Yes", "No"])
            responses.append(answer)
        else:
            time.sleep(1)
    hot_count = responses.count("Yes")
    hot_percentage = hot_count * 10
    go_to(start_loc)
    say(f"{hot_percentage}% of people said it's hot out.")
"""

