name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    caramel_total = 0
    chocolate_total = 0
    gummy_total = 0

    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                caramel = int(ask("", "How many caramels would you like?", ["0", "1", "2", "3", "4"]))
                chocolate = int(ask("", "How many chocolates would you like?", ["0", "1", "2", "3", "4"]))
                gummy = int(ask("", "How many gummies would you like?", ["0", "1", "2", "3", "4"]))
                caramel_total += caramel
                chocolate_total += chocolate
                gummy_total += gummy

    go_to(start_loc)
    say(f"We need to buy {caramel_total} caramels, {chocolate_total} chocolates, and {gummy_total} gummies.")
"""

