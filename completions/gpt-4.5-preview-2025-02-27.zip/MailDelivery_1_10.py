name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    mail_collected_from = []
    go_to("mail room")
    say("Picking up the mail bin.")
    
    rooms = get_all_rooms()
    for room in rooms:
        if "office" in room:
            go_to(room)
            response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                say("Please put the mail in the bin.")
                mail_collected_from.append(room)
                
    go_to("mail room")
    if mail_collected_from:
        offices = ", ".join(mail_collected_from)
        say("Collected mail from: " + offices)
    else:
        say("No mail was collected from any office.")

    say("Putting the mail bin back.")
    say("Task completed.")
"""

