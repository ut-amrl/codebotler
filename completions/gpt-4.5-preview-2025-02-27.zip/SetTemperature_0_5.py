name = "SetTemperature"

prompt = "The thermostat is set to 72 degrees. Go to Arjun's office and ask him if he'd like it to be warmer or colder. Come back and tell me what temperature I should set it to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    current_temp = 72
    go_to("Arjun's office")
    preference = ask("Arjun", "Would you like it warmer or colder?", ["Warmer", "Colder"])
    if preference == "Warmer":
        desired_temp = current_temp + 2
    else:
        desired_temp = current_temp - 2
    go_to(start_loc)
    say(f"Arjun would like the thermostat set to {desired_temp} degrees.")
"""

