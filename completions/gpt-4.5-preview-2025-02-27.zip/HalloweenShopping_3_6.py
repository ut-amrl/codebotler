name = "HalloweenShopping"

prompt = "Go to each office. If no person is in the office, skip this office. Otherwise, ask the person in the office to whether they'd like 0,1,2,3, or 4 for each of the following: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices = [room for room in get_all_rooms() if "office" in room]
    total_gummy = 0
    total_caramel = 0
    total_chocolate = 0

    for office in offices:
        go_to(office)
        if is_in_room("person"):
            gummy_count = int(ask("", "How many gummies would you like?", ["0", "1", "2", "3", "4"]))
            caramel_count = int(ask("", "How many caramels would you like?", ["0", "1", "2", "3", "4"]))
            chocolate_count = int(ask("", "How many chocolates would you like?", ["0", "1", "2", "3", "4"]))
            
            total_gummy += gummy_count
            total_caramel += caramel_count
            total_chocolate += chocolate_count

    go_to(start_loc)
    say(f"We need to buy {total_gummy} gummies, {total_caramel} caramels, and {total_chocolate} chocolates.")
"""

