name = "GrilledCheese"

prompt = "Create a list of ingredients needed to make grilled cheese. Visit Zarko's office and inquire which of them he possesses. Return and inform me of the items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheddar cheese", "butter"]
    missing_ingredients = []

    start_loc = get_current_location()
    go_to("Zarko's office")

    for ingredient in ingredients:
        response = ask("Zarko", f"Do you have {ingredient}?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(ingredient)

    go_to(start_loc)

    if missing_ingredients:
        missing_items = ", ".join(missing_ingredients)
        say("Zarko is missing the following ingredients: " + missing_items)
    else:
        say("Zarko has all the ingredients for grilled cheese.")
"""

