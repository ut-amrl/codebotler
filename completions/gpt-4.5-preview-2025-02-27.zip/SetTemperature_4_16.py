name = "SetTemperature"

prompt = "The thermostat is set to 72 degrees. Go to Arjun's office and ask if he would like the temperature to be set to a warmer or colder value. Return and tell me what temperature in degrees I should set the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Arjun's office")
    preference = ask("Arjun", "The thermostat is currently set to 72 degrees. Would you like it warmer or colder?", ["Warmer", "Colder"])
    if preference == "Warmer":
        new_temperature = "74"
    else:
        new_temperature = "70"
    go_to(start_loc)
    say("You should set the thermostat to " + new_temperature + " degrees.")
"""

