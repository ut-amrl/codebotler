name = "LunchBreak"

prompt = "Go to Alice's and Bob's offices and ask each of them if they are up for lunch. If they say yes, tell them that we will meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    participants = []
    
    for person in ["Alice", "Bob"]:
        go_to(f"{person}'s office")
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            say("Great! We will meet in the lobby in 5 minutes.")
            participants.append(person)
    
    go_to(start_loc)
    
    if participants:
        participant_names = ', '.join(participants)
        say(f"The following people are joining for lunch: {participant_names}.")
    else:
        say("No one is joining for lunch.")
"""

