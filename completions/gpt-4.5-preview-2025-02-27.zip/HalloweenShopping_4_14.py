name = "HalloweenShopping"

prompt = "Go to every office and skip any office without a person in there. Otherwise, ask the person in the office to decide on how many, from zero to four, of the following they'd like: gummy, caramel, or chocolate. Return to me and say how many of each we need to buy. "

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices = get_all_rooms()

    gummy = 0
    caramel = 0
    chocolate = 0

    for office in offices:
        if "office" not in office:
            continue
        go_to(office)
        if not is_in_room("person"):
            continue

        gummy_response = ask("", "How many gummy would you like?", ["0", "1", "2", "3", "4"])
        caramel_response = ask("", "How many caramel would you like?", ["0", "1", "2", "3", "4"])
        chocolate_response = ask("", "How many chocolate would you like?", ["0", "1", "2", "3", "4"])

        gummy += int(gummy_response)
        caramel += int(caramel_response)
        chocolate += int(chocolate_response)

    go_to(start_loc)
    summary = f"We need to buy {gummy} gummy, {caramel} caramel, and {chocolate} chocolate."
    say(summary)
"""

