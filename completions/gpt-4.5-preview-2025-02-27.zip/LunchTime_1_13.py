name = "LunchTime"

prompt = "Go to Jill's office and ask her whether she's free to go for lunch tomorrow. If yes, ask her when (give her some reasonable times), and come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    response = ask("Jill", "Are you free to go for lunch tomorrow?", ["Yes", "No"])
    if response == "Yes":
        time = ask("Jill", "What time would you prefer for lunch tomorrow?", ["12:00pm", "12:30pm", "1:00pm", "1:30pm"])
        message = f"Jill is free for lunch tomorrow at {time}."
    else:
        message = "Jill is not free to go for lunch tomorrow."
    go_to(start_loc)
    say(message)
"""

