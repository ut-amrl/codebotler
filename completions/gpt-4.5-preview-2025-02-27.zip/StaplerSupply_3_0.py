name = "StaplerSupply"

prompt = "Check all printer rooms for staplers, and come back and tell me which ones do not have any staplers."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    rooms = get_all_rooms()
    printer_rooms_without_staplers = []

    for room in rooms:
        if "printer room" in room:
            go_to(room)
            if not is_in_room("stapler"):
                printer_rooms_without_staplers.append(room)

    go_to(start_location)

    if printer_rooms_without_staplers:
        rooms_list = ", ".join(printer_rooms_without_staplers)
        say(f"The following printer rooms do not have staplers: {rooms_list}")
    else:
        say("All printer rooms have staplers.")
"""

