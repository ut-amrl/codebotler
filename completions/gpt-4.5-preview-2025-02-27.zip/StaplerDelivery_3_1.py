name = "StaplerDelivery"

prompt = "Make sure there is a stapler in each printer room. Otherwise, bring a stapler from the supply room to each printer room that currently lacks one."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    printer_rooms = [room for room in get_all_rooms() if "printer room" in room]
    rooms_missing_stapler = []

    # Check each printer room for a stapler
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            rooms_missing_stapler.append(room)

    # Bring stapler from supply room to each room missing a stapler
    for room in rooms_missing_stapler:
        go_to("supply room")
        say("Please provide a stapler for " + room)
        go_to(room)
        say("I've brought a stapler for this printer room.")

    go_to(start_loc)
    say("Task completed: All printer rooms now have staplers.")
"""

