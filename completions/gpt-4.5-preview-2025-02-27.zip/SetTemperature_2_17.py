name = "SetTemperature"

prompt = "The thermostat is currently set to 72 degrees. Go ask if Arjun thinks his office should be colder or warmer. Come back and tell me what temperature in degrees I should change the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    current_location = get_current_location()
    go_to("Arjun's office")
    response = ask("Arjun", "The thermostat is currently set to 72 degrees. Should your office be warmer or colder?", ["Warmer", "Colder", "It's fine"])
    new_temp = 72
    if response == "Warmer":
        new_temp += 2
    elif response == "Colder":
        new_temp -= 2
    go_to(current_location)
    if response == "It's fine":
        say("Arjun said the temperature is fine at 72 degrees. No adjustment is needed.")
    else:
        say(f"Arjun would like the thermostat set to {new_temp} degrees.")
"""

