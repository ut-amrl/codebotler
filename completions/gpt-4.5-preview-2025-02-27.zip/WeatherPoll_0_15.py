name = "WeatherPoll"

prompt = "Go to the main entrance, and wait for someone to show up. Ask them if they feel it is hot out. Repeat this until you have 10 responses, and then come back and tell me what percent of people think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    
    hot_count = 0
    total_asked = 0
    
    while total_asked < 10:
        if is_in_room("person"):
            response = ask("", "Do you feel it is hot outside?", ["Yes", "No"])
            if response == "Yes":
                hot_count += 1
            total_asked += 1
    
    percentage = (hot_count / 10) * 100
    go_to(start_loc)
    say(f"{percentage}% of people think it is hot outside.")
"""

