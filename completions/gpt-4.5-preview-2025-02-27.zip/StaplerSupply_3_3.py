name = "StaplerSupply"

prompt = "Check all printer rooms for staplers, and come back and tell me which ones do not have any staplers."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    no_stapler_rooms = []

    for room in rooms:
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                no_stapler_rooms.append(room)

    go_to(start_loc)
    if no_stapler_rooms:
        message = "These printer rooms have no staplers: " + ", ".join(no_stapler_rooms)
    else:
        message = "All printer rooms have staplers."
    say(message)
"""

