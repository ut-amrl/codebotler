name = "SayGoodDay"

prompt = "Visit each lab and if someone is present, greet them with a pleasant Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    labs = get_all_rooms()
    start_loc = get_current_location()
    for lab in labs:
        if "lab" in lab.lower():
            go_to(lab)
            if is_in_room("person"):
                say("Good Day!")
    go_to(start_loc)
    say("Task completed.")
"""

