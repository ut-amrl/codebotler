name = "CountSavory"

prompt = "Go through each office; if someone is there, ask about their preference among cupcake, donut, beef jerky, or ham sandwich. Report the number of individuals who opted for a savory item after returning."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    savory_items = ["beef jerky", "ham sandwich"]
    sweet_items = ["cupcake", "donut"]
    savory_count = 0

    offices = get_all_rooms()
    
    for office in offices:
        if "office" in office:
            go_to(office)
            if is_in_room("person"):
                choice = ask("", "Which snack would you prefer?", savory_items + sweet_items)
                if choice in savory_items:
                    savory_count += 1
    
    go_to(start_loc)
    say(f"{savory_count} individuals opted for a savory snack.")
"""

