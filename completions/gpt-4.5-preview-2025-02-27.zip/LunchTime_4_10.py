name = "LunchTime"

prompt = "Ask Jill in her office if she want to go for lunch tomorrow. If yes, give her some reasonable time options and ask her to choose a time. Finally come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    go_to("Jill's office")
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    
    if response == "Yes":
        time_chosen = ask("Jill", "Please choose a preferred time for lunch tomorrow:", ["12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM"])
        message = f"Jill said she would like to go for lunch tomorrow at {time_chosen}."
    else:
        message = "Jill said she wouldn't like to go for lunch tomorrow."
    
    go_to(start_location)
    say(message)
"""

