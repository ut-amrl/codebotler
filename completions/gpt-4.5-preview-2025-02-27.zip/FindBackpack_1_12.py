name = "FindBackpack"

prompt = "Search all the conference rooms for my backpack and return it to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    conference_rooms = [room for room in get_all_rooms() if "conference room" in room.lower()]
    backpack_found = False
    
    for room in conference_rooms:
        go_to(room)
        if is_in_room("backpack"):
            backpack_found = True
            say("I found your backpack in " + room)
            break
    
    if not backpack_found:
        say("I checked all conference rooms but couldn't find your backpack.")
    else:
        say("I'm bringing your backpack to you now.")
    
    go_to(start_loc)
    if backpack_found:
        say("Here is your backpack.")
"""

