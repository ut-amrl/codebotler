name = "MailDelivery"

prompt = "Find a mail bin in the mail room and carry it with you. Collect mail from every office by asking if there is any mail they'd like delivered. If yes, ask them to put it in the bin. Return the bin to the mail room and say which offices sent mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("mail room")
    if not is_in_room("mail bin"):
        say("No mail bin in the mail room.")
        return
    offices_with_mail = []
    all_rooms = get_all_rooms()
    for room in all_rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                response = ask("", "Do you have mail you'd like delivered?", ["Yes", "No"])
                if response == "Yes":
                    say("Please put your mail in the bin.")
                    offices_with_mail.append(room)
    go_to("mail room")
    if offices_with_mail:
        mail_rooms = ", ".join(offices_with_mail)
        say(f"The following offices sent mail: {mail_rooms}.")
    else:
        say("No offices sent mail.")
    go_to(start_loc)
"""

