name = "MailDelivery"

prompt = "Take a mail bin from the mail room. For every office, ask if there is any mail to deliver and if someone says yes, ask them to put all mail in the bin. Finally find me at the mail room. Put the mail bin away, and tell me which offices had mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    go_to("mail room")
    say("Picking up the mail bin.")
    offices_with_mail = []
    all_rooms = get_all_rooms()
    
    for room in all_rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
                if response == "Yes":
                    say("Please place all mail in the bin.")
                    offices_with_mail.append(room)

    go_to("mail room")
    say("Putting the mail bin away.")
    if offices_with_mail:
        offices_list = ", ".join(offices_with_mail)
        say(f"The following offices had mail: {offices_list}.")
    else:
        say("No offices had mail today.")
"""

