name = "StaplerDelivery"

prompt = "Make sure there is a stapler in each printer room. Otherwise, bring a stapler from the supply room to each printer room that currently lacks one."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    printer_rooms_without_stapler = []

    # Check each printer room for stapler
    for room in rooms:
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                printer_rooms_without_stapler.append(room)

    # Get staplers from supply room and deliver to rooms without stapler
    for room in printer_rooms_without_stapler:
        go_to("supply room")
        say("Please place a stapler in my basket for " + room)
        go_to(room)
        say("I've brought a stapler for this room.")

    go_to(start_loc)
    say("Task is completed.")
"""

