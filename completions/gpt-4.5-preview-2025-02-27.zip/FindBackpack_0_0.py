name = "FindBackpack"

prompt = "Check where I left my backpack in all of the conference rooms and bring it back to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    backpack_location = None
    
    for room in rooms:
        if "conference room" in room:
            go_to(room)
            if is_in_room("backpack"):
                backpack_location = room
                break
        
    if backpack_location:
        say(f"Found your backpack in {backpack_location}.")
        say("Picking it up now.")
        # Assuming robot picks up backpack automatically
        go_to(start_loc)
        say("Here's your backpack.")
    else:
        go_to(start_loc)
        say("Couldn't find your backpack in any of the conference rooms.")
"""

