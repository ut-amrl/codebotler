name = "StaplerDelivery"

prompt = "Check every printer room for a stapler, and deliver a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    printer_rooms = [room for room in get_all_rooms() if "printer room" in room]
    rooms_needing_stapler = []
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            rooms_needing_stapler.append(room)
    
    for room in rooms_needing_stapler:
        go_to("supply room")
        say("I need a stapler for " + room)
        go_to(room)
        say("I have delivered a stapler to this room")
    
    say("All printer rooms now have staplers.")
"""

