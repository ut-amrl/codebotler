name = "MovieMessenger"

prompt = "Ask Sally if she wants to go to the cinema with Mark. Tell Mark what Sally said, and if yes, ask Mark whether he wants to leave at 4PM, 5PM, or 6PM. If Sally said yes, go tell Sally what time Mark is leaving."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    go_to("Sally's office")
    sally_response = ask("Sally", "Do you want to go to the cinema with Mark?", ["Yes", "No"])
    
    go_to("Mark's office")
    say("Sally said: " + sally_response)
    
    if sally_response == "Yes":
        mark_time = ask("Mark", "What time do you want to leave?", ["4PM", "5PM", "6PM"])
        go_to("Sally's office")
        say("Mark wants to leave at " + mark_time)
    
    say("Task completed.")
"""

