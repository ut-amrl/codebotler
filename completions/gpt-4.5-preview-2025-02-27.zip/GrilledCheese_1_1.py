name = "GrilledCheese"

prompt = "Create a list of ingredients needed to make grilled cheese. Visit Zarko's office and inquire which of them he possesses. Return and inform me of the items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheese", "butter"]
    go_to("Zarko's office")
    unavailable_ingredients = []
    for item in ingredients:
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "No":
            unavailable_ingredients.append(item)
    start_loc = get_current_location()
    go_to(start_loc)
    if unavailable_ingredients:
        missing_items = ", ".join(unavailable_ingredients)
        say(f"Zarko does not have: {missing_items}")
    else:
        say("Zarko has all the ingredients.")
"""

