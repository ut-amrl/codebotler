name = "CountSavory"

prompt = "Go through each office; if someone is there, ask about their preference among cupcake, donut, beef jerky, or ham sandwich. Report the number of individuals who opted for a savory item after returning."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    savory_options = ["beef jerky", "ham sandwich"]
    sweet_options = ["cupcake", "donut"]
    all_options = savory_options + sweet_options
    
    savory_count = 0
    
    rooms = get_all_rooms()
    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                choice = ask("", "Which snack do you prefer?", all_options)
                if choice in savory_options:
                    savory_count += 1
    
    go_to(start_loc)
    say(f"{savory_count} individual(s) opted for a savory snack.")
"""

