name = "CountSavory"

prompt = "Go to every office, and if there is someone there, ask them whether they'd like a cupcake, ham sandwich, donut, or beef jerky. Come back and tell me how many people chose a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    savory_choices = ["ham sandwich", "beef jerky"]
    count_savory = 0
    rooms = get_all_rooms()

    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                choice = ask("", "Would you like a cupcake, ham sandwich, donut, or beef jerky?",
                             ["cupcake", "ham sandwich", "donut", "beef jerky"])
                if choice in savory_choices:
                    count_savory += 1

    go_to(start_loc)
    say(f"{count_savory} people chose a savory option.")
"""

