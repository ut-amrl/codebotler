name = "LunchTime"

prompt = "Ask Jill in her office if she want to go for lunch tomorrow. If yes, give her some reasonable time options and ask her to choose a time. Finally come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    wants_lunch = ask("Jill", "Do you want to go for lunch tomorrow?", ["Yes", "No"])
    if wants_lunch == "Yes":
        time_chosen = ask("Jill", "Great! What time would you prefer?", ["12:00 PM", "12:30 PM", "1:00 PM"])
        message = "Jill wants to go for lunch at " + time_chosen + " tomorrow."
    else:
        message = "Jill does not want to go for lunch tomorrow."
    go_to(start_loc)
    say(message)
"""

