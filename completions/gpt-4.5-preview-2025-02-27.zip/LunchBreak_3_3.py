name = "LunchBreak"

prompt = "Ask Alice and Bob if they are up for lunch. If they say yes, tell them that we will meet in the lobby in five minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    attendees = []
    
    go_to("Alice's office")
    response_alice = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if response_alice == "Yes":
        say("Great! We will meet in the lobby in five minutes.")
        attendees.append("Alice")
    
    go_to("Bob's office")
    response_bob = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if response_bob == "Yes":
        say("Great! We will meet in the lobby in five minutes.")
        attendees.append("Bob")
    
    go_to(start_loc)
    
    if attendees:
        attendee_list = ", ".join(attendees)
        say(f"{attendee_list} will be joining for lunch.")
    else:
        say("No one will be joining for lunch.")
"""

