name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    
    caramel_total, chocolate_total, gummy_total = 0, 0, 0
    
    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                caramel = ask("", "How many caramel candies would you like?", ["0", "1", "2", "3", "4"])
                chocolate = ask("", "How many chocolate candies would you like?", ["0", "1", "2", "3", "4"])
                gummy = ask("", "How many gummy candies would you like?", ["0", "1", "2", "3", "4"])
                
                caramel_total += int(caramel)
                chocolate_total += int(chocolate)
                gummy_total += int(gummy)
    
    go_to(start_loc)
    say("We need to buy {} caramel, {} chocolate, and {} gummy candies in total.".format(caramel_total, chocolate_total, gummy_total))
"""

