name = "GrilledCheese"

prompt = "Compile the necessary ingredients for grilled cheese. Go to Zarko's office, ask him about his available items, and then report back to me which items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheese", "butter"]
    go_to("Zarko's office")
    missing_items = []
    for item in ingredients:
        answer = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if answer == "No":
            missing_items.append(item)
    start_location = get_current_location()
    go_to(start_location)
    if missing_items:
        say("Zarko is missing: " + ", ".join(missing_items))
    else:
        say("Zarko has all the ingredients for grilled cheese.")
"""

