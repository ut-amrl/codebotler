name = "StaplerDelivery"

prompt = "Check if every printer room has a stapler. If not, put a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    initial_location = get_current_location()
    rooms = get_all_rooms()
    printer_rooms_without_staplers = []

    for room in rooms:
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                printer_rooms_without_staplers.append(room)

    for room in printer_rooms_without_staplers:
        go_to("supply room")
        say("Picking up a stapler for " + room)
        go_to(room)
        say("Delivered stapler to " + room)

    go_to(initial_location)
    say("Finished checking and resupplying staplers.")
"""

