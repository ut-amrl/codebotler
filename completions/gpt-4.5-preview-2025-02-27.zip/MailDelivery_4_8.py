name = "MailDelivery"

prompt = "Take a mail bin from the mail room. For every office, ask if there is any mail to deliver and if someone says yes, ask them to put all mail in the bin. Finally find me at the mail room. Put the mail bin away, and tell me which offices had mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    offices_with_mail = []
    go_to("mail room")
    say("Picking up mail bin.")

    rooms = get_all_rooms()
    for room in rooms:
        if "office" in room.lower():
            go_to(room)
            people_in_room = is_in_room("person")
            if people_in_room:
                response = ask("", "Is there mail to deliver from this office?", ["Yes", "No"])
                if response == "Yes":
                    say("Please put all the mail in the bin.")
                    offices_with_mail.append(room)

    go_to("mail room")
    say("Putting away the mail bin.")

    user_location = get_current_location()
    if user_location != "mail room":
        go_to(user_location)

    if offices_with_mail:
        say("The following offices had mail: " + ", ".join(offices_with_mail))
    else:
        say("There was no mail to collect from any office.")
"""

