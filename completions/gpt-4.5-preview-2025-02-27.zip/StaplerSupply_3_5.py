name = "StaplerSupply"

prompt = "Check all printer rooms for staplers, and come back and tell me which ones do not have any staplers."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    initial_location = get_current_location()
    rooms = get_all_rooms()
    rooms_without_staplers = []

    for room in rooms:
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                rooms_without_staplers.append(room)

    go_to(initial_location)

    if rooms_without_staplers:
        message = "The following printer rooms have no staplers: " + ", ".join(rooms_without_staplers)
    else:
        message = "All printer rooms have staplers."

    say(message)
"""

