name = "MailDelivery"

prompt = "Grab a mail bin from the mail room. Go to every office, and ask if they have any mail to deliver. Ask them to put all mail in the bin if there is any. Put the mail bin back in the mail room and report which offices the mail is from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("mail room")
    say("Grabbing a mail bin from the mail room.")

    offices_with_mail = []
    all_rooms = get_all_rooms()

    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            if is_in_room("person"):
                has_mail = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
                if has_mail == "Yes":
                    say("Please put all mail in the bin.")
                    offices_with_mail.append(room)

    go_to("mail room")
    say("Placing the mail bin back in the mail room.")

    go_to(start_loc)
    
    if offices_with_mail:
        office_names = ", ".join(offices_with_mail)
        say("Mail was collected from the following offices: " + office_names)
    else:
        say("No mail was collected from any office.")
"""

