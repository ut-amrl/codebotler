name = "MailDelivery"

prompt = "Go to the mail room to pick a mail bin. Ask at every office if they have any mail to deliver. If they reply yes, ask them to put the mail in the bin. Return to the mail room with the mail. Tell me at the mail room which offices these mail are from and put the mail bin back."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("mail room")
    say("Picking up the mail bin.")
    offices_with_mail = []
    rooms = get_all_rooms()
    
    for room in rooms:
        if "office" in room.lower():
            go_to(room)
            person_response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
            if person_response == "Yes":
                say("Please put the mail in the bin.")
                offices_with_mail.append(room)

    go_to("mail room")
    if offices_with_mail:
        say("I have collected mail from the following offices: " + ", ".join(offices_with_mail))
    else:
        say("No offices had mail for delivery.")
    
    say("Putting the mail bin back.")
    go_to(start_loc)
    say("Task completed.")
"""

