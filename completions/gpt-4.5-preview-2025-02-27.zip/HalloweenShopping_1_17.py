name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices = [room for room in get_all_rooms() if "office" in room]

    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0

    for office in offices:
        go_to(office)
        if is_in_room("person"):
            caramel = int(ask("", "How many caramels would you like?", ["0", "1", "2", "3", "4"]))
            chocolate = int(ask("", "How many chocolates would you like?", ["0", "1", "2", "3", "4"]))
            gummy = int(ask("", "How many gummies would you like?", ["0", "1", "2", "3", "4"]))

            total_caramel += caramel
            total_chocolate += chocolate
            total_gummy += gummy

    go_to(start_loc)
    summary_message = f"We need to buy {total_caramel} caramels, {total_chocolate} chocolates, and {total_gummy} gummies."
    say(summary_message)
"""

