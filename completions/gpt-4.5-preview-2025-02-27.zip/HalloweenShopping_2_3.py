name = "HalloweenShopping"

prompt = "Visit every office. If there is a person in the office, ask the person to select 0 to 4 for each of the following categories: gummy, chocolate, or caramel. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    total_gummy = 0
    total_chocolate = 0
    total_caramel = 0
    
    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                gummy = int(ask("", "How many gummy candies do you want?", ["0", "1", "2", "3", "4"]))
                chocolate = int(ask("", "How many chocolate candies do you want?", ["0", "1", "2", "3", "4"]))
                caramel = int(ask("", "How many caramel candies do you want?", ["0", "1", "2", "3", "4"]))
                total_gummy += gummy
                total_chocolate += chocolate
                total_caramel += caramel

    go_to(start_loc)
    say(f"We need to buy {total_gummy} gummy candies, {total_chocolate} chocolate candies, and {total_caramel} caramel candies.")
"""

