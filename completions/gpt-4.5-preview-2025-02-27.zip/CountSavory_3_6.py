name = "CountSavory"

prompt = "Go visit each office. If there is a person in the office, inquire about their liking for cupcake, ham sandwich, beef jerky, or donut. Come back and tell me of the count of people who went for a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices = get_all_rooms()
    savory_count = 0
    savory_options = ["ham sandwich", "beef jerky"]
    all_options = ["cupcake", "ham sandwich", "beef jerky", "donut"]

    for office in offices:
        if "office" not in office:
            continue
        go_to(office)
        if is_in_room("person"):
            choice = ask("person", "Which snack would you prefer?", all_options)
            if choice in savory_options:
                savory_count += 1

    go_to(start_loc)
    say(f"{savory_count} people preferred a savory option.")
"""

