name = "MailDelivery"

prompt = "Take a mail bin from the mail room. For every office, ask if there is any mail to deliver and if someone says yes, ask them to put all mail in the bin. Finally find me at the mail room. Put the mail bin away, and tell me which offices had mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    mail_pickup_offices = []
    go_to("mail room")
    say("Picking up the mail bin.")

    offices = [room for room in get_all_rooms() if "office" in room.lower()]

    for office in offices:
        go_to(office)
        if is_in_room("person"):
            has_mail = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
            if has_mail == "Yes":
                say("Please place your mail in the bin.")
                mail_pickup_offices.append(office)

    go_to("mail room")
    say("Putting the mail bin away.")

    if mail_pickup_offices:
        offices_with_mail = ", ".join(mail_pickup_offices)
        say("The following offices had mail: " + offices_with_mail)
    else:
        say("No offices had mail today.")

    say("Task completed.")
"""

