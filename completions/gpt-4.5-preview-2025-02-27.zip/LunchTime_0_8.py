name = "LunchTime"

prompt = "Go to Jill's office and ask her if she'd like to go for lunch tomorrow. If yes, ask her at what time (offer her some reasonable options). Come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    if response == "Yes":
        time_response = ask("Jill", "What time would you prefer?", ["12:00 pm", "12:30 pm", "1:00 pm"])
        final_response = "Jill said yes, and prefers " + time_response
    else:
        final_response = "Jill said no to lunch tomorrow."
    go_to(start_loc)
    say(final_response)
"""

