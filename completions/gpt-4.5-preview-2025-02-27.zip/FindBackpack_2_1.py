name = "FindBackpack"

prompt = "Please find my backpack in each conference room and then bring it to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    rooms = get_all_rooms()
    backpack_found = False
    
    for room in rooms:
        if "conference room" in room:
            go_to(room)
            if is_in_room("backpack"):
                backpack_found = True
                say("I found the backpack in " + room + ".")
                break

    if not backpack_found:
        go_to(start_location)
        say("I could not find your backpack in any conference room.")
    else:
        go_to(start_location)
        say("Here is your backpack.")
"""

