name = "MailDelivery"

prompt = "Grab a mail bin from the mail room. Go to every office, and ask if they have any mail to deliver. Ask them to put all mail in the bin if there is any. Put the mail bin back in the mail room and report which offices the mail is from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    mail_collected_from = []

    go_to("mail room")
    say("I am picking up a mail bin.")

    rooms = get_all_rooms()
    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
                if response == "Yes":
                    say("Please put all mail into the mail bin.")
                    mail_collected_from.append(room)

    go_to("mail room")
    say("I am returning the mail bin here.")

    go_to(start_loc)

    if mail_collected_from:
        message = "Mail was collected from: " + ", ".join(mail_collected_from)
    else:
        message = "No mail was collected from any office."

    say(message)
"""

