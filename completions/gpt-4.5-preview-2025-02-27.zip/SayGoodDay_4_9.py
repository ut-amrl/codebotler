name = "SayGoodDay"

prompt = "Visit every lab space and when encountering an individual, tell them a Good Day!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    lab_rooms = [room for room in rooms if "lab" in room.lower()]
    for lab in lab_rooms:
        go_to(lab)
        if is_in_room("person"):
            say("Good Day!")
    go_to(start_loc)
    say("Task is completed.")
"""

