name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices = [room for room in get_all_rooms() if "office" in room]
    
    total_chocolate = 0
    total_caramel = 0
    total_gummy = 0
    
    for office in offices:
        go_to(office)
        if is_in_room("person"):
            chocolate = int(ask("", "How many chocolates would you like?", ["0", "1", "2", "3", "4"]))
            caramel = int(ask("", "How many caramels would you like?", ["0", "1", "2", "3", "4"]))
            gummy = int(ask("", "How many gummies would you like?", ["0", "1", "2", "3", "4"]))
            
            total_chocolate += chocolate
            total_caramel += caramel
            total_gummy += gummy
    
    go_to(start_loc)
    message = (
        f"In total, we need to buy {total_chocolate} chocolates, "
        f"{total_caramel} caramels, and {total_gummy} gummies."
    )
    say(message)
"""

