name = "CountSavory"

prompt = "Go through each office; if someone is there, ask about their preference among cupcake, donut, beef jerky, or ham sandwich. Report the number of individuals who opted for a savory item after returning."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    offices = [room for room in get_all_rooms() if "office" in room]
    savory_items = {"beef jerky", "ham sandwich"}
    savory_count = 0
    for office in offices:
        go_to(office)
        if is_in_room("person"):
            preference = ask("", "Which snack would you prefer?", ["cupcake", "donut", "beef jerky", "ham sandwich"])
            if preference in savory_items:
                savory_count += 1
    go_to(start_loc)
    say(f"{savory_count} individual(s) opted for a savory item.")
"""

