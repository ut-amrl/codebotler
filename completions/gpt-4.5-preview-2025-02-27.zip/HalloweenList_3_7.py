name = "HalloweenList"

prompt = "Find every occupied office and ask their occupants whether they would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()

    chocolate_count = 0
    caramel_count = 0
    gummy_count = 0

    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                choice = ask("", "Would you like chocolate, caramel, or gummy?", ["chocolate", "caramel", "gummy"])
                if choice == "chocolate":
                    chocolate_count += 1
                elif choice == "caramel":
                    caramel_count += 1
                elif choice == "gummy":
                    gummy_count += 1
                    
    go_to(start_loc)
    say("We need to buy " + str(chocolate_count) + " chocolates, " + str(caramel_count) + " caramels, and " + str(gummy_count) + " gummies.")
"""

