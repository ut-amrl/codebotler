name = "CountSavory"

prompt = "Visit all offices. If anyone is present; ask them to choose from the options of cupcake, ham sandwich, donut, or beef jerky. Let me know how many people selected a savory option when you return."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    savory_options = ["ham sandwich", "beef jerky"]
    savory_count = 0
    start_loc = get_current_location()
    office_rooms = [room for room in get_all_rooms() if "office" in room.lower()]
    
    for office in office_rooms:
        go_to(office)
        if is_in_room("person"):
            choice = ask("person", "Please choose an option:", ["cupcake", "ham sandwich", "donut", "beef jerky"])
            if choice in savory_options:
                savory_count += 1
    
    go_to(start_loc)
    say(f"{savory_count} people selected a savory option.")
"""

