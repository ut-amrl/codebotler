name = "SetTemperature"

prompt = "The thermostat is currently set to 72 degrees. Go ask if Arjun thinks his office should be colder or warmer. Come back and tell me what temperature in degrees I should change the thermostat to."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Arjun's office")
    preference = ask("Arjun", "Do you think your office should be colder or warmer?", ["Colder", "Warmer"])
    if preference == "Colder":
        temp_change = ask("Arjun", "By how many degrees colder?", ["1", "2", "3", "4", "5"])
        new_temp = 72 - int(temp_change)
    else:
        temp_change = ask("Arjun", "By how many degrees warmer?", ["1", "2", "3", "4", "5"])
        new_temp = 72 + int(temp_change)
    go_to(start_loc)
    say(f"You should set the thermostat to {new_temp} degrees.")
"""

