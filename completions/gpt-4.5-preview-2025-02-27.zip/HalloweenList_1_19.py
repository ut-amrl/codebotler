name = "HalloweenList"

prompt = "Go to every office, and if there is a person there, ask them if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    offices = get_all_rooms()
    chocolates = 0
    caramels = 0
    gummies = 0
    
    for office in offices:
        if "office" in office:
            go_to(office)
            if is_in_room("person"):
                response = ask("", "Which candy would you like?", ["Chocolate", "Caramel", "Gummy"])
                if response == "Chocolate":
                    chocolates += 1
                elif response == "Caramel":
                    caramels += 1
                elif response == "Gummy":
                    gummies += 1
                    
    go_to(start_location)
    say(f"We need to buy {chocolates} chocolates, {caramels} caramels, and {gummies} gummies.")
"""

