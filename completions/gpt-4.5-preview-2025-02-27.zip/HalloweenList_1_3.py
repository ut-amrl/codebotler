name = "HalloweenList"

prompt = "Go to every office, and if there is a person there, ask them if they'd like a chocolate, caramel, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    chocolate = 0
    caramel = 0
    gummy = 0

    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                response = ask("", "Which candy would you like?", ["chocolate", "caramel", "gummy"])
                if response == "chocolate":
                    chocolate += 1
                elif response == "caramel":
                    caramel += 1
                elif response == "gummy":
                    gummy += 1

    go_to(start_loc)
    say(f"We need to buy {chocolate} chocolates, {caramel} caramels, and {gummy} gummies.")
"""

