name = "StaplerDelivery"

prompt = "Check if there is a stapler in every printer room. For each visited room without a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    printer_rooms_without_staplers = []

    # Check printer rooms for staplers
    for room in rooms:
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                printer_rooms_without_staplers.append(room)

    # Deliver staplers where needed
    for room in printer_rooms_without_staplers:
        go_to("supply room")
        say("I need a stapler for " + room)
        go_to(room)
        say("Delivered stapler to " + room)

    go_to(start_loc)
    say("All printer rooms now have staplers.")
"""

