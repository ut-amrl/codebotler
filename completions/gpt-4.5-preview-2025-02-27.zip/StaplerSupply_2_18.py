name = "StaplerSupply"

prompt = "Go find all printer rooms that do not have a stapler. Come back and tell me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    printer_rooms_without_stapler = []

    for room in rooms:
        if "printer room" in room.lower():
            go_to(room)
            if not is_in_room("stapler"):
                printer_rooms_without_stapler.append(room)

    go_to(start_loc)

    if printer_rooms_without_stapler:
        message = "Printer rooms without stapler: " + ", ".join(printer_rooms_without_stapler)
    else:
        message = "All printer rooms have staplers."

    say(message)
"""

