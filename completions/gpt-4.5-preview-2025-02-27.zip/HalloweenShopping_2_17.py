name = "HalloweenShopping"

prompt = "Visit every office. If there is a person in the office, ask the person to select 0 to 4 for each of the following categories: gummy, chocolate, or caramel. Return to me and say how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    offices = [room for room in get_all_rooms() if "office" in room]
    
    total_gummy = 0
    total_chocolate = 0
    total_caramel = 0

    for office in offices:
        go_to(office)
        if is_in_room("person"):
            gummy = int(ask("", "How many gummy would you like?", ["0", "1", "2", "3", "4"]))
            chocolate = int(ask("", "How many chocolate would you like?", ["0", "1", "2", "3", "4"]))
            caramel = int(ask("", "How many caramel would you like?", ["0", "1", "2", "3", "4"]))

            total_gummy += gummy
            total_chocolate += chocolate
            total_caramel += caramel
            
    go_to(start_location)

    say(f"We need to buy {total_gummy} gummy, {total_chocolate} chocolate, and {total_caramel} caramel.")
"""

