name = "LunchBreak"

prompt = "Go to Alice's office and ask her if she is free for lunch. If she says yes, tell her that we will meet in the lobby in five minutes. Do the same for Bob. Come back and tell me who will join for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    attendees = []
    for person in ["Alice", "Bob"]:
        go_to(person + "'s office")
        response = ask(person, "Are you free for lunch?", ["Yes", "No"])
        if response == "Yes":
            say("Great! We'll meet in the lobby in five minutes.")
            attendees.append(person)
    go_to(start_location)
    if attendees:
        say("The following people will join for lunch: " + ", ".join(attendees))
    else:
        say("Nobody is available to join for lunch.")
"""

