name = "LunchBreak"

prompt = "Ask if Alice and Bob in their offices are up for lunch. If yes, tell them that we'll meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    people = {"Alice": "Alice's office", "Bob": "Bob's office"}
    joining = []
    
    for person, office in people.items():
        go_to(office)
        response = ask(person, "Are you up for lunch?", ["Yes", "No"])
        if response == "Yes":
            say("We'll meet in the lobby in 5 minutes.")
            joining.append(person)
    
    go_to(start_loc)
    if joining:
        say("Joining for lunch: " + ", ".join(joining))
    else:
        say("No one is joining for lunch.")
"""

