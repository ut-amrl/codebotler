name = "MailDelivery"

prompt = "Take a mail bin from the mail room. For every office, ask if there is any mail to deliver and if someone says yes, ask them to put all mail in the bin. Finally find me at the mail room. Put the mail bin away, and tell me which offices had mail."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    mail_picked_up_from = []
    go_to("mail room")
    say("Picking up the mail bin.")
    all_rooms = get_all_rooms()
    offices = [room for room in all_rooms if "office" in room.lower()]
    for office in offices:
        go_to(office)
        if is_in_room("person"):
            response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
            if response == "Yes":
                say("Please put all mail in the bin.")
                mail_picked_up_from.append(office)
    go_to("mail room")
    say("Putting the mail bin away.")
    user_location = get_current_location()
    if not mail_picked_up_from:
        message = "There was no mail to collect from any office."
    else:
        office_list = ", ".join(mail_picked_up_from)
        message = f"I picked up mail from the following offices: {office_list}."
    say(message)
"""

