name = "GetDrink"

prompt = "Go to the lobby and ask any person there if they want iced tea, lemonade or a bottle of water. Bring whatever they asked for back from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("lobby")
    while not is_in_room("person"):
        pass  # wait until someone arrives
    choice = ask("", "Would you like iced tea, lemonade, or a bottle of water?", ["iced tea", "lemonade", "bottle of water"])
    go_to("kitchen")
    say("Picking up " + choice)
    go_to(start_loc)
    say("I have brought you " + choice)
"""

