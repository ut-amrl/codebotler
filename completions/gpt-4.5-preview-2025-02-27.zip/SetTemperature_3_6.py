name = "SetTemperature"

prompt = "Go to Arjun's office and ask him if he would like his office to be warmer or colder. The thermostat says the temperature in the office is currently 72 degrees. Come back and tell me what temperature I should reset it to based on Arjun's preferences."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Arjun's office")
    preference = ask("Arjun", "Would you like your office to be warmer or colder?", ["Warmer", "Colder", "No change"])
    
    current_temperature = 72
    if preference == "Warmer":
        new_temperature = current_temperature + 2
    elif preference == "Colder":
        new_temperature = current_temperature - 2
    else:
        new_temperature = current_temperature
    
    go_to(start_loc)
    say(f"Arjun would like the office temperature set to {new_temperature} degrees.")
"""

