name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    rooms = get_all_rooms()
    total_caramel = 0
    total_chocolate = 0
    total_gummy = 0
    quantities = ["0", "1", "2", "3", "4"]
    
    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                caramel = int(ask("", "How many caramel would you like?", quantities))
                chocolate = int(ask("", "How many chocolate would you like?", quantities))
                gummy = int(ask("", "How many gummy would you like?", quantities))
                total_caramel += caramel
                total_chocolate += chocolate
                total_gummy += gummy
    
    go_to(start_location)
    message = f"We need to buy {total_caramel} caramel, {total_chocolate} chocolate, and {total_gummy} gummy."
    say(message)
"""

