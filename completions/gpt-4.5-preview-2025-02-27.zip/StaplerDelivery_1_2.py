name = "StaplerDelivery"

prompt = "Go to every printer room and check if there is a stapler. For each visited room that does not have a stapler, deliver a stapler from the supply room to that room."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    printer_rooms = [room for room in get_all_rooms() if "printer room" in room]
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            go_to("supply room")
            say("I am picking up a stapler for " + room)
            go_to(room)
            say("I have delivered a stapler to " + room)
    say("The task has been completed.")
"""

