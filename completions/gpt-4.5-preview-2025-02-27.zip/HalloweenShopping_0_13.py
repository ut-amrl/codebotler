name = "HalloweenShopping"

prompt = "Go to every office, and if there is anyone there, ask them how many from 0 to 4 of the following treats they'd like: chocolate, caramel, and gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    chocolates_needed = 0
    caramels_needed = 0
    gummies_needed = 0

    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                chocolates = int(ask("", "How many chocolates would you like?", ["0", "1", "2", "3", "4"]))
                caramels = int(ask("", "How many caramels would you like?", ["0", "1", "2", "3", "4"]))
                gummies = int(ask("", "How many gummies would you like?", ["0", "1", "2", "3", "4"]))
                chocolates_needed += chocolates
                caramels_needed += caramels
                gummies_needed += gummies

    go_to(start_loc)
    say(f"We need to buy {chocolates_needed} chocolates, {caramels_needed} caramels, and {gummies_needed} gummies.")
"""

