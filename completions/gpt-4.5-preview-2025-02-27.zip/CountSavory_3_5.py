name = "CountSavory"

prompt = "Go visit each office. If there is a person in the office, inquire about their liking for cupcake, ham sandwich, beef jerky, or donut. Come back and tell me of the count of people who went for a savory option."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    savory_options = ["ham sandwich", "beef jerky"]
    savory_count = 0
    start_loc = get_current_location()
    rooms = get_all_rooms()

    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                response = ask(
                    "",
                    "Which snack would you prefer?",
                    ["cupcake", "ham sandwich", "beef jerky", "donut"]
                )
                if response in savory_options:
                    savory_count += 1

    go_to(start_loc)
    say(f"{savory_count} people chose a savory snack option.")
"""

