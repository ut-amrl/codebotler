name = "MailDelivery"

prompt = "Pick up a mail bin from the mail room. Go to every office and ask if they have any mail they'd like delivered. If so, ask them to put it in the mail bin. Finally, meet me in the mail room with all the mail. Place the mail bin back and tell me which offices they are from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("mail room")
    say("Picking up a mail bin.")
    offices = [room for room in get_all_rooms() if "office" in room]
    offices_with_mail = []
    for office in offices:
        go_to(office)
        if is_in_room("person"):
            response = ask("", "Do you have any mail you'd like me to deliver?", ["Yes", "No"])
            if response == "Yes":
                say("Please put the mail into the mail bin.")
                offices_with_mail.append(office)
    go_to("mail room")
    say("Placing the mail bin back.")
    go_to(start_loc)
    if offices_with_mail:
        offices_list = ", ".join(offices_with_mail)
        say("I've collected mail from the following offices: " + offices_list)
    else:
        say("No offices had mail to be delivered.")
"""

