name = "FindBackpack"

prompt = "Search all the conference rooms for my backpack and return it to me."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    my_location = get_current_location()
    rooms = get_all_rooms()

    for room in rooms:
        if "conference room" in room:
            go_to(room)
            if is_in_room("backpack"):
                say("I found your backpack in " + room)
                break
    else:
        say("I could not find your backpack in any conference room.")
        go_to(my_location)
        return

    go_to(my_location)
    say("Here is your backpack.")
"""

