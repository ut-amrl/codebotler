name = "WeatherPoll"

prompt = "Go wait for someone at the main entrance. Ask them if they feel it is hot out, then wait for the next person and ask the same question. Do this until you have ten responses, then come back and report the percentage of people who think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """
"""

