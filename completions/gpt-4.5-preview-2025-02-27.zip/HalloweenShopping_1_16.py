name = "HalloweenShopping"

prompt = "For each office, check if there is anyone there. If there is, ask the person to choose how many (0-4) of each of the following they'd like: caramel, chocolate, or gummy. Come back and tell me how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    rooms = get_all_rooms()
    caramel_needed = 0
    chocolate_needed = 0
    gummy_needed = 0

    for room in rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                caramel = int(ask("", "How many caramels would you like?", ["0", "1", "2", "3", "4"]))
                chocolate = int(ask("", "How many chocolates would you like?", ["0", "1", "2", "3", "4"]))
                gummy = int(ask("", "How many gummies would you like?", ["0", "1", "2", "3", "4"]))

                caramel_needed += caramel
                chocolate_needed += chocolate
                gummy_needed += gummy

    go_to(start_loc)
    summary = f"We need to buy {caramel_needed} caramel(s), {chocolate_needed} chocolate(s), and {gummy_needed} gummy candy(ies)."
    say(summary)
"""

