name = "GetDrink"

prompt = "Go to the lobby, and ask if the visitor would like a bottle of water, iced tea, or lemonade. If they want a bottle of water, bring it to them from the kitchen. If they want iced tea, bring it to them from the kitchen. If they want lemonade, bring it to them from the kitchen."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    go_to("lobby")
    choice = ask("visitor", "Would you like a beverage?", ["bottle of water", "iced tea", "lemonade"])
    go_to("kitchen")
    if choice == "bottle of water":
        say("I am picking up a bottle of water.")
    elif choice == "iced tea":
        say("I am picking up iced tea.")
    elif choice == "lemonade":
        say("I am picking up lemonade.")
    go_to("lobby")
    say("Here is your " + choice)
"""

