name = "LunchBreak"

prompt = "Go to Alice's and Bob's offices and ask each of them if they are up for lunch. If they say yes, tell them that we will meet in the lobby in 5 minutes. Come back and tell me who all are joining for lunch."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    joining_for_lunch = []
    
    # Check with Alice
    go_to("Alice's office")
    alice_response = ask("Alice", "Are you up for lunch?", ["Yes", "No"])
    if alice_response == "Yes":
        say("Great, we'll meet in the lobby in 5 minutes.")
        joining_for_lunch.append("Alice")
    
    # Check with Bob
    go_to("Bob's office")
    bob_response = ask("Bob", "Are you up for lunch?", ["Yes", "No"])
    if bob_response == "Yes":
        say("Great, we'll meet in the lobby in 5 minutes.")
        joining_for_lunch.append("Bob")
    
    # Return and report who is joining
    go_to(start_loc)
    
    if joining_for_lunch:
        say("The following people are joining for lunch: " + ", ".join(joining_for_lunch))
    else:
        say("No one is joining for lunch.")
"""

