name = "GrilledCheese"

prompt = "Put together a list of grilled cheese ingredients. Head to Zarko's office and inquire about his available ingredients. Return and inform me of what he is missing."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheese", "butter"]
    missing_ingredients = []

    go_to("Zarko's office")
    for item in ingredients:
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "No":
            missing_ingredients.append(item)

    start_loc = get_current_location()
    go_to(start_loc)

    if len(missing_ingredients) == 0:
        say("Zarko has all the ingredients for grilled cheese.")
    else:
        missing_list = ", ".join(missing_ingredients)
        say("Zarko is missing these ingredients for grilled cheese: " + missing_list)
"""

