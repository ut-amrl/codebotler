name = "LunchTime"

prompt = "Go to Jill's office and ask her if she'd like to go for lunch tomorrow. If yes, ask her at what time (offer her some reasonable options). Come back and tell me what she said."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Jill's office")
    response = ask("Jill", "Would you like to go for lunch tomorrow?", ["Yes", "No"])
    if response == "Yes":
        time_choice = ask("Jill", "What time would you like to go?", ["12:00", "12:30", "1:00", "1:30"])
        final_message = "Jill said yes to lunch at " + time_choice + "."
    else:
        final_message = "Jill said no to lunch."
    go_to(start_loc)
    say(final_message)
"""

