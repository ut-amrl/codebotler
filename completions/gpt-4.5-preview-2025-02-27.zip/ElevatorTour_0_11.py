name = "ElevatorTour"

prompt = "Go to the elevator. Wait until someone shows up and ask them if they are here for the tour. If yes, welcome them to the university, tell them to follow you, and take them to the main conference room. If not, wait for the next person. When you get to the conference room, say you have arrived at the conference room and also say enjoy your visit here!"

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    go_to("elevator")
    while True:
        if is_in_room("person"):
            response = ask("person", "Are you here for the tour?", ["Yes", "No"])
            if response == "Yes":
                say("Welcome to the university!")
                say("Please follow me.")
                go_to("main conference room")
                say("We have arrived at the conference room.")
                say("Enjoy your visit here!")
                break
"""

