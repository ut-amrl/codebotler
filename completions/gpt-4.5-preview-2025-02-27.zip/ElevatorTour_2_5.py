name = "ElevatorTour"

prompt = "Go to the elevator and wait for someone to arrive. Inquire if they are here for the tour, and if they say yes, welcome them to the university and tell them to follow you. Then take them to the main conference room. If they say no, wait for someone else. When you get to the conference room, announce your arrival at the conference room and wish them an enjoyable visit."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    go_to("elevator")
    while True:
        if is_in_room("person"):
            response = ask("person", "Hello! Are you here for the tour?", ["Yes", "No"])
            if response == "Yes":
                say("Welcome to the university! Please follow me.")
                break
        time.sleep(1)

    go_to("main conference room")
    say("We have arrived at the conference room. Enjoy your visit!")
"""

