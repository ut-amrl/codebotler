name = "SetTemperature"

prompt = "Ask Arjun in his office if he would like it to be warmer or colder. The thermostat is currently set to 72 degrees. Come back and tell me what temperature I should set the thermostat to based on what Arjun says."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("Arjun's office")
    preference = ask("Arjun", "Would you like it warmer or colder?", ["warmer", "colder"])
    current_temp = 72
    if preference == "warmer":
        new_temp = current_temp + 2
    else:
        new_temp = current_temp - 2
    go_to(start_loc)
    say(f"Arjun wants it {preference}. You should set the thermostat to {new_temp} degrees.")
"""

