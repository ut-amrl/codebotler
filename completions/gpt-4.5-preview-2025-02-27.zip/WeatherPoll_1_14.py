name = "WeatherPoll"

prompt = "Go to the main entrance. When someone shows up, ask them if they feel that it's hot out. Do this until you collect ten people's responses. Come back and tell me which percent of people think it's hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_location = get_current_location()
    go_to("main entrance")
    hot_count = 0
    total_count = 10

    for i in range(total_count):
        while not is_in_room("person"):
            pass  # Wait until someone shows up
        
        response = ask("", "Do you feel that it's hot out?", ["Yes", "No"])
        if response == "Yes":
            hot_count += 1
        
        say("Thank you.")
        
        # Wait for the person to leave before asking the next person
        while is_in_room("person"):
            pass

    percentage_hot = (hot_count / total_count) * 100
    go_to(start_location)
    say(f"{percentage_hot}% of people think it's hot out.")
"""

