name = "MailDelivery"

prompt = "Pick up a mail bin from the mail room. Go to every office and ask if they have any mail they'd like delivered. If so, ask them to put it in the mail bin. Finally, meet me in the mail room with all the mail. Place the mail bin back and tell me which offices they are from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("mail room")
    say("Picking up the mail bin.")

    offices_with_mail = []
    all_rooms = get_all_rooms()

    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            response = ask("", "Do you have any mail you'd like delivered?", ["Yes", "No"])
            if response == "Yes":
                say("Please place the mail in the mail bin.")
                offices_with_mail.append(room)

    go_to("mail room")
    say("Placing the mail bin back.")
    
    if offices_with_mail:
        offices = ", ".join(offices_with_mail)
        say("Mail was collected from: " + offices)
    else:
        say("No mail was collected from any office.")
    
    go_to(start_loc)
"""

