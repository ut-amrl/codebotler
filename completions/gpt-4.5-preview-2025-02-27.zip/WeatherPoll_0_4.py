name = "WeatherPoll"

prompt = "Go to the main entrance, and wait for someone to show up. Ask them if they feel it is hot out. Repeat this until you have 10 responses, and then come back and tell me what percent of people think it is hot out."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    go_to("main entrance")
    hot_answers = 0
    total_responses = 10

    for i in range(total_responses):
        while not is_in_room("person"):
            time.sleep(1)
        response = ask("", "Do you feel it is hot out?", ["Yes", "No"])
        if response == "Yes":
            hot_answers += 1
        while is_in_room("person"):
            time.sleep(1)

    percentage_hot = (hot_answers / total_responses) * 100
    go_to(start_loc)
    say(f"{percentage_hot}% of people think it is hot out.")
"""

