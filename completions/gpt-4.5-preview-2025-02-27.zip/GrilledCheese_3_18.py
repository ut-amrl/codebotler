name = "GrilledCheese"

prompt = "Compile the necessary ingredients for grilled cheese. Go to Zarko's office, ask him about his available items, and then report back to me which items he does not have."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    ingredients = ["bread", "cheese", "butter"]
    go_to("Zarko's office")
    missing_items = []
    for item in ingredients:
        response = ask("Zarko", f"Do you have {item}?", ["Yes", "No"])
        if response == "No":
            missing_items.append(item)
    start_loc = get_current_location()
    go_to(start_loc)
    if missing_items:
        message = "Zarko does not have: " + ", ".join(missing_items)
    else:
        message = "Zarko has all the ingredients."
    say(message)
"""

