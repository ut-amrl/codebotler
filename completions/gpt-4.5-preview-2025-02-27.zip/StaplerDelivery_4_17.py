name = "StaplerDelivery"

prompt = "Check if every printer room has a stapler. If not, put a stapler from the supply room to every printer room without a stapler."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    printer_rooms = [room for room in get_all_rooms() if "printer room" in room]
    rooms_without_stapler = []
    
    # Check printer rooms for staplers
    for room in printer_rooms:
        go_to(room)
        if not is_in_room("stapler"):
            rooms_without_stapler.append(room)
    
    # For each room that lacks a stapler, get one from supply room
    for room in rooms_without_stapler:
        go_to("supply room")
        say("Please provide a stapler for " + room)
        go_to(room)
        say("I've placed a stapler here.")
    
    say("All printer rooms now have a stapler.")
"""

