name = "MailDelivery"

prompt = "Grab a mail bin from the mail room. Go to every office, and ask if they have any mail to deliver. Ask them to put all mail in the bin if there is any. Put the mail bin back in the mail room and report which offices the mail is from."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    mail_collected_from = []

    go_to("mail room")
    say("I have picked up the mail bin.")

    all_rooms = get_all_rooms()

    for room in all_rooms:
        if "office" in room.lower():
            go_to(room)
            if is_in_room("person"):
                response = ask("", "Do you have any mail to deliver?", ["Yes", "No"])
                if response == "Yes":
                    say("Please place your mail into the bin.")
                    mail_collected_from.append(room)

    go_to("mail room")
    say("I have returned the mail bin.")

    if mail_collected_from:
        offices = ", ".join(mail_collected_from)
        say("The mail collected is from the following offices: " + offices)
    else:
        say("No mail was collected from any office.")

    go_to(start_loc)
    say("Task is completed.")
"""

