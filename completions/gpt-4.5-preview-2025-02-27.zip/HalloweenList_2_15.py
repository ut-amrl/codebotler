name = "HalloweenList"

prompt = "Check with every occupied office to see if the occupant would like a chocolate, caramel, or gummy. Let me know how many of each we need to buy."

completion_settings = {
    "temperature": 0.2,
    "top_p": 0.95,
    "max_tokens": 2500,
    "prompt_prefix": "",
    "stop_sequences": [
        "\n#",
        "\nclass",
        "```"
    ]
}

completion = """def task_program():
    start_loc = get_current_location()
    all_rooms = get_all_rooms()
    chocolate = 0
    caramel = 0
    gummy = 0

    for room in all_rooms:
        if "office" in room:
            go_to(room)
            if is_in_room("person"):
                response = ask("", "Which candy would you like?", ["Chocolate", "Caramel", "Gummy", "None"])
                if response == "Chocolate":
                    chocolate += 1
                elif response == "Caramel":
                    caramel += 1
                elif response == "Gummy":
                    gummy += 1

    go_to(start_loc)
    say(f"We need to buy {chocolate} chocolate, {caramel} caramel, and {gummy} gummy candies.")
"""

